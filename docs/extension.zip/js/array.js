!(function () {
  "use strict";
  var t = "undefined" != typeof window ? window : void 0,
    i = "undefined" != typeof globalThis ? globalThis : t,
    e = Array.prototype,
    r = e.forEach,
    s = e.indexOf,
    n = null == i ? void 0 : i.navigator,
    o = null == i ? void 0 : i.document,
    a = null == i ? void 0 : i.location,
    l = null == i ? void 0 : i.fetch,
    h =
      null != i &&
      i.XMLHttpRequest &&
      "withCredentials" in new i.XMLHttpRequest()
        ? i.XMLHttpRequest
        : void 0,
    u = null == i ? void 0 : i.AbortController,
    d = null == n ? void 0 : n.userAgent,
    v = null != t ? t : {},
    c = { DEBUG: !1, LIB_VERSION: "1.261.0" };
  function f() {
    return (
      (f = Object.assign
        ? Object.assign.bind()
        : function (t) {
            for (var i = 1; i < arguments.length; i++) {
              var e = arguments[i];
              for (var r in e) ({}).hasOwnProperty.call(e, r) && (t[r] = e[r]);
            }
            return t;
          }),
      f.apply(null, arguments)
    );
  }
  function p(t, i) {
    if (null == t) return {};
    var e = {};
    for (var r in t)
      if ({}.hasOwnProperty.call(t, r)) {
        if (-1 !== i.indexOf(r)) continue;
        e[r] = t[r];
      }
    return e;
  }
  var g = [
    "$snapshot",
    "$pageview",
    "$pageleave",
    "$set",
    "survey dismissed",
    "survey sent",
    "survey shown",
    "$identify",
    "$groupidentify",
    "$create_alias",
    "$$client_ingestion_warning",
    "$web_experiment_applied",
    "$feature_enrollment_update",
    "$feature_flag_called",
  ];
  function _(t, i) {
    return -1 !== t.indexOf(i);
  }
  var m = function (t) {
      return t.trim();
    },
    b = function (t) {
      return t.replace(/^\$/, "");
    };
  var y = Array.isArray,
    w = Object.prototype,
    S = w.hasOwnProperty,
    $ = w.toString,
    x =
      y ||
      function (t) {
        return "[object Array]" === $.call(t);
      },
    k = (t) => "function" == typeof t,
    E = (t) => t === Object(t) && !x(t),
    I = (t) => {
      if (E(t)) {
        for (var i in t) if (S.call(t, i)) return !1;
        return !0;
      }
      return !1;
    },
    P = (t) => void 0 === t,
    R = (t) => "[object String]" == $.call(t),
    T = (t) => R(t) && 0 === t.trim().length,
    C = (t) => null === t,
    M = (t) => P(t) || C(t),
    F = (t) => "[object Number]" == $.call(t),
    O = (t) => "[object Boolean]" === $.call(t),
    A = (t) => t instanceof FormData,
    D = (t) => _(g, t),
    j = [!0, "true", 1, "1", "yes"],
    L = (t) => _(j, t),
    N = [!1, "false", 0, "0", "no"];
  function z(t, i, e, r, s) {
    return (
      i > e && (r.warn("min cannot be greater than max."), (i = e)),
      F(t)
        ? t > e
          ? (r.warn(
              " cannot be  greater than max: " +
                e +
                ". Using max value instead.",
            ),
            e)
          : t < i
            ? (r.warn(
                " cannot be less than min: " + i + ". Using min value instead.",
              ),
              i)
            : t
        : (r.warn(
            " must be a number. using max or fallback. max: " +
              e +
              ", fallback: " +
              s,
          ),
          z(s || e, i, e, r))
    );
  }
  class U {
    stop() {
      this.t && (clearInterval(this.t), (this.t = void 0));
    }
    constructor(t) {
      ((this.i = t),
        (this.o = {}),
        (this.h = () => {
          Object.keys(this.o).forEach((t) => {
            var i = this.m(t) + this.S;
            i >= this.$ ? delete this.o[t] : this.k(t, i);
          });
        }),
        (this.m = (t) => this.o[String(t)]),
        (this.k = (t, i) => {
          this.o[String(t)] = i;
        }),
        (this.consumeRateLimit = (t) => {
          var i,
            e = null != (i = this.m(t)) ? i : this.$;
          if (0 === (e = Math.max(e - 1, 0))) return !0;
          this.k(t, e);
          var r,
            s = 0 === e;
          s && (null == (r = this.I) || r.call(this, t));
          return s;
        }),
        (this.I = this.i.I),
        (this.$ = z(this.i.bucketSize, 0, 100, this.i.P)),
        (this.S = z(this.i.refillRate, 0, this.$, this.i.P)),
        (this.R = z(this.i.refillInterval, 0, 864e5, this.i.P)),
        (this.t = setInterval(() => {
          this.h();
        }, this.R)));
    }
  }
  var B = (i) => {
      var e = {
        T: function (e) {
          if (t && (c.DEBUG || v.POSTHOG_DEBUG) && !P(t.console) && t.console) {
            for (
              var r =
                  ("__rrweb_original__" in t.console[e])
                    ? t.console[e].__rrweb_original__
                    : t.console[e],
                s = arguments.length,
                n = new Array(s > 1 ? s - 1 : 0),
                o = 1;
              o < s;
              o++
            )
              n[o - 1] = arguments[o];
            r(i, ...n);
          }
        },
        info: function () {
          for (var t = arguments.length, i = new Array(t), r = 0; r < t; r++)
            i[r] = arguments[r];
          e.T("log", ...i);
        },
        warn: function () {
          for (var t = arguments.length, i = new Array(t), r = 0; r < t; r++)
            i[r] = arguments[r];
          e.T("warn", ...i);
        },
        error: function () {
          for (var t = arguments.length, i = new Array(t), r = 0; r < t; r++)
            i[r] = arguments[r];
          e.T("error", ...i);
        },
        critical: function () {
          for (var t = arguments.length, e = new Array(t), r = 0; r < t; r++)
            e[r] = arguments[r];
          console.error(i, ...e);
        },
        uninitializedWarning: (t) => {
          e.error("You must initialize PostHog before calling " + t);
        },
        createLogger: (t) => B(i + " " + t),
      };
      return e;
    },
    q = B("[PostHog.js]"),
    H = q.createLogger,
    W = H("[ExternalScriptsLoader]"),
    G = (t, i, e) => {
      if (t.config.disable_external_dependency_loading)
        return (
          W.warn(
            i + " was requested but loading of external scripts is disabled.",
          ),
          e("Loading of external scripts is disabled")
        );
      var r = null == o ? void 0 : o.querySelectorAll("script");
      if (r) for (var s = 0; s < r.length; s++) if (r[s].src === i) return e();
      var n = () => {
        if (!o) return e("document not found");
        var r = o.createElement("script");
        if (
          ((r.type = "text/javascript"),
          (r.crossOrigin = "anonymous"),
          (r.src = i),
          (r.onload = (t) => e(void 0, t)),
          (r.onerror = (t) => e(t)),
          t.config.prepare_external_dependency_script &&
            (r = t.config.prepare_external_dependency_script(r)),
          !r)
        )
          return e("prepare_external_dependency_script returned null");
        var s,
          n = o.querySelectorAll("body > script");
        n.length > 0
          ? null == (s = n[0].parentNode) || s.insertBefore(r, n[0])
          : o.body.appendChild(r);
      };
      null != o && o.body
        ? n()
        : null == o || o.addEventListener("DOMContentLoaded", n);
    };
  ((v.__PosthogExtensions__ = v.__PosthogExtensions__ || {}),
    (v.__PosthogExtensions__.loadExternalDependency = (t, i, e) => {
      var r = "/static/" + i + ".js?v=" + t.version;
      if (
        ("remote-config" === i &&
          (r = "/array/" + t.config.token + "/config.js"),
        "toolbar" === i)
      ) {
        var s = 3e5;
        r = r + "&t=" + Math.floor(Date.now() / s) * s;
      }
      var n = t.requestRouter.endpointFor("assets", r);
      G(t, n, e);
    }),
    (v.__PosthogExtensions__.loadSiteApp = (t, i, e) => {
      var r = t.requestRouter.endpointFor("api", i);
      G(t, r, e);
    }));
  var J = {};
  function V(t, i, e) {
    if (x(t))
      if (r && t.forEach === r) t.forEach(i, e);
      else if ("length" in t && t.length === +t.length)
        for (var s = 0, n = t.length; s < n; s++)
          if (s in t && i.call(e, t[s], s) === J) return;
  }
  function K(t, i, e) {
    if (!M(t)) {
      if (x(t)) return V(t, i, e);
      if (A(t)) {
        for (var r of t.entries()) if (i.call(e, r[1], r[0]) === J) return;
      } else
        for (var s in t) if (S.call(t, s) && i.call(e, t[s], s) === J) return;
    }
  }
  var Y = function (t) {
      for (
        var i = arguments.length, e = new Array(i > 1 ? i - 1 : 0), r = 1;
        r < i;
        r++
      )
        e[r - 1] = arguments[r];
      return (
        V(e, function (i) {
          for (var e in i) void 0 !== i[e] && (t[e] = i[e]);
        }),
        t
      );
    },
    X = function (t) {
      for (
        var i = arguments.length, e = new Array(i > 1 ? i - 1 : 0), r = 1;
        r < i;
        r++
      )
        e[r - 1] = arguments[r];
      return (
        V(e, function (i) {
          V(i, function (i) {
            t.push(i);
          });
        }),
        t
      );
    };
  function Q(t) {
    for (var i = Object.keys(t), e = i.length, r = new Array(e); e--; )
      r[e] = [i[e], t[i[e]]];
    return r;
  }
  var Z = function (t) {
      try {
        return t();
      } catch (t) {
        return;
      }
    },
    tt = function (t) {
      return function () {
        try {
          for (var i = arguments.length, e = new Array(i), r = 0; r < i; r++)
            e[r] = arguments[r];
          return t.apply(this, e);
        } catch (t) {
          (q.critical(
            "Implementation error. Please turn on debug mode and open a ticket on https://app.posthog.com/home#panel=support%3Asupport%3A.",
          ),
            q.critical(t));
        }
      };
    },
    it = function (t) {
      var i = {};
      return (
        K(t, function (t, e) {
          ((R(t) && t.length > 0) || F(t)) && (i[e] = t);
        }),
        i
      );
    };
  function et(t, i) {
    return (
      (e = t),
      (r = (t) => (R(t) && !C(i) ? t.slice(0, i) : t)),
      (s = new Set()),
      (function t(i, e) {
        return i !== Object(i)
          ? r
            ? r(i, e)
            : i
          : s.has(i)
            ? void 0
            : (s.add(i),
              x(i)
                ? ((n = []),
                  V(i, (i) => {
                    n.push(t(i));
                  }))
                : ((n = {}),
                  K(i, (i, e) => {
                    s.has(i) || (n[e] = t(i, e));
                  })),
              n);
        var n;
      })(e)
    );
    var e, r, s;
  }
  var rt = ["herokuapp.com", "vercel.app", "netlify.app"];
  function st(t) {
    var i = null == t ? void 0 : t.hostname;
    if (!R(i)) return !1;
    var e = i.split(".").slice(-2).join(".");
    for (var r of rt) if (e === r) return !1;
    return !0;
  }
  function nt(t, i) {
    for (var e = 0; e < t.length; e++) if (i(t[e])) return t[e];
  }
  function ot(t, i, e, r) {
    var { capture: s = !1, passive: n = !0 } = null != r ? r : {};
    null == t || t.addEventListener(i, e, { capture: s, passive: n });
  }
  var at = "$people_distinct_id",
    lt = "__alias",
    ht = "__timers",
    ut = "$autocapture_disabled_server_side",
    dt = "$heatmaps_enabled_server_side",
    vt = "$exception_capture_enabled_server_side",
    ct = "$error_tracking_suppression_rules",
    ft = "$error_tracking_capture_extension_exceptions",
    pt = "$web_vitals_enabled_server_side",
    gt = "$dead_clicks_enabled_server_side",
    _t = "$web_vitals_allowed_metrics",
    mt = "$session_recording_enabled_server_side",
    bt = "$console_log_recording_enabled_server_side",
    yt = "$session_recording_network_payload_capture",
    wt = "$session_recording_masking",
    St = "$session_recording_canvas_recording",
    $t = "$replay_sample_rate",
    xt = "$replay_minimum_duration",
    kt = "$replay_script_config",
    Et = "$sesid",
    It = "$session_is_sampled",
    Pt = "$session_recording_url_trigger_activated_session",
    Rt = "$session_recording_event_trigger_activated_session",
    Tt = "$enabled_feature_flags",
    Ct = "$early_access_features",
    Mt = "$feature_flag_details",
    Ft = "$stored_person_properties",
    Ot = "$stored_group_properties",
    At = "$surveys",
    Dt = "$surveys_activated",
    jt = "$flag_call_reported",
    Lt = "$user_state",
    Nt = "$client_session_props",
    zt = "$capture_rate_limit",
    Ut = "$initial_campaign_params",
    Bt = "$initial_referrer_info",
    qt = "$initial_person_info",
    Ht = "$epp",
    Wt = "__POSTHOG_TOOLBAR__",
    Gt = "$posthog_cookieless",
    Jt = [
      at,
      lt,
      "__cmpns",
      ht,
      mt,
      dt,
      Et,
      Tt,
      ct,
      Lt,
      Ct,
      Mt,
      Ot,
      Ft,
      At,
      jt,
      Nt,
      zt,
      Ut,
      Bt,
      Ht,
      qt,
    ];
  function Vt(t) {
    return (
      t instanceof Element &&
      (t.id === Wt ||
        !(null == t.closest || !t.closest(".toolbar-global-fade-container")))
    );
  }
  function Kt(t) {
    return !!t && 1 === t.nodeType;
  }
  function Yt(t, i) {
    return !!t && !!t.tagName && t.tagName.toLowerCase() === i.toLowerCase();
  }
  function Xt(t) {
    return !!t && 3 === t.nodeType;
  }
  function Qt(t) {
    return !!t && 11 === t.nodeType;
  }
  function Zt(t) {
    return t ? m(t).split(/\s+/) : [];
  }
  function ti(i) {
    var e = null == t ? void 0 : t.location.href;
    return !!(e && i && i.some((t) => e.match(t)));
  }
  function ii(t) {
    var i = "";
    switch (typeof t.className) {
      case "string":
        i = t.className;
        break;
      case "object":
        i =
          (t.className && "baseVal" in t.className
            ? t.className.baseVal
            : null) ||
          t.getAttribute("class") ||
          "";
        break;
      default:
        i = "";
    }
    return Zt(i);
  }
  function ei(t) {
    return M(t)
      ? null
      : m(t)
          .split(/(\s+)/)
          .filter((t) => gi(t))
          .join("")
          .replace(/[\r\n]/g, " ")
          .replace(/[ ]+/g, " ")
          .substring(0, 255);
  }
  function ri(t) {
    var i = "";
    return (
      li(t) &&
        !hi(t) &&
        t.childNodes &&
        t.childNodes.length &&
        K(t.childNodes, function (t) {
          var e;
          Xt(t) &&
            t.textContent &&
            (i += null !== (e = ei(t.textContent)) && void 0 !== e ? e : "");
        }),
      m(i)
    );
  }
  function si(t) {
    return P(t.target)
      ? t.srcElement || null
      : null != (i = t.target) && i.shadowRoot
        ? t.composedPath()[0] || null
        : t.target || null;
    var i;
  }
  var ni = ["a", "button", "form", "input", "select", "textarea", "label"];
  function oi(t) {
    var i = t.parentNode;
    return !(!i || !Kt(i)) && i;
  }
  function ai(i, e, r, s, n) {
    var o, a, l;
    if ((void 0 === r && (r = void 0), !t || !i || Yt(i, "html") || !Kt(i)))
      return !1;
    if (null != (o = r) && o.url_allowlist && !ti(r.url_allowlist)) return !1;
    if (null != (a = r) && a.url_ignorelist && ti(r.url_ignorelist)) return !1;
    if (null != (l = r) && l.dom_event_allowlist) {
      var h = r.dom_event_allowlist;
      if (h && !h.some((t) => e.type === t)) return !1;
    }
    for (var u = !1, d = [i], v = !0, c = i; c.parentNode && !Yt(c, "body"); )
      if (Qt(c.parentNode))
        (d.push(c.parentNode.host), (c = c.parentNode.host));
      else {
        if (!(v = oi(c))) break;
        if (s || ni.indexOf(v.tagName.toLowerCase()) > -1) u = !0;
        else {
          var f = t.getComputedStyle(v);
          f && "pointer" === f.getPropertyValue("cursor") && (u = !0);
        }
        (d.push(v), (c = v));
      }
    if (
      !(function (t, i) {
        var e = null == i ? void 0 : i.element_allowlist;
        if (P(e)) return !0;
        var r,
          s = function (t) {
            if (e.some((i) => t.tagName.toLowerCase() === i)) return { v: !0 };
          };
        for (var n of t) if ((r = s(n))) return r.v;
        return !1;
      })(d, r)
    )
      return !1;
    if (
      !(function (t, i) {
        var e = null == i ? void 0 : i.css_selector_allowlist;
        if (P(e)) return !0;
        var r,
          s = function (t) {
            if (e.some((i) => t.matches(i))) return { v: !0 };
          };
        for (var n of t) if ((r = s(n))) return r.v;
        return !1;
      })(d, r)
    )
      return !1;
    var p = t.getComputedStyle(i);
    if (p && "pointer" === p.getPropertyValue("cursor") && "click" === e.type)
      return !0;
    var g = i.tagName.toLowerCase();
    switch (g) {
      case "html":
        return !1;
      case "form":
        return (n || ["submit"]).indexOf(e.type) >= 0;
      case "input":
      case "select":
      case "textarea":
        return (n || ["change", "click"]).indexOf(e.type) >= 0;
      default:
        return u
          ? (n || ["click"]).indexOf(e.type) >= 0
          : (n || ["click"]).indexOf(e.type) >= 0 &&
              (ni.indexOf(g) > -1 ||
                "true" === i.getAttribute("contenteditable"));
    }
  }
  function li(t) {
    for (var i = t; i.parentNode && !Yt(i, "body"); i = i.parentNode) {
      var e = ii(i);
      if (_(e, "ph-sensitive") || _(e, "ph-no-capture")) return !1;
    }
    if (_(ii(t), "ph-include")) return !0;
    var r = t.type || "";
    if (R(r))
      switch (r.toLowerCase()) {
        case "hidden":
        case "password":
          return !1;
      }
    var s = t.name || t.id || "";
    if (R(s)) {
      if (
        /^cc|cardnum|ccnum|creditcard|csc|cvc|cvv|exp|pass|pwd|routing|seccode|securitycode|securitynum|socialsec|socsec|ssn/i.test(
          s.replace(/[^a-zA-Z0-9]/g, ""),
        )
      )
        return !1;
    }
    return !0;
  }
  function hi(t) {
    return !!(
      (Yt(t, "input") &&
        !["button", "checkbox", "submit", "reset"].includes(t.type)) ||
      Yt(t, "select") ||
      Yt(t, "textarea") ||
      "true" === t.getAttribute("contenteditable")
    );
  }
  var ui =
      "(4[0-9]{12}(?:[0-9]{3})?)|(5[1-5][0-9]{14})|(6(?:011|5[0-9]{2})[0-9]{12})|(3[47][0-9]{13})|(3(?:0[0-5]|[68][0-9])[0-9]{11})|((?:2131|1800|35[0-9]{3})[0-9]{11})",
    di = new RegExp("^(?:" + ui + ")$"),
    vi = new RegExp(ui),
    ci = "\\d{3}-?\\d{2}-?\\d{4}",
    fi = new RegExp("^(" + ci + ")$"),
    pi = new RegExp("(" + ci + ")");
  function gi(t, i) {
    if ((void 0 === i && (i = !0), M(t))) return !1;
    if (R(t)) {
      if (((t = m(t)), (i ? di : vi).test((t || "").replace(/[- ]/g, ""))))
        return !1;
      if ((i ? fi : pi).test(t)) return !1;
    }
    return !0;
  }
  function _i(t) {
    var i = ri(t);
    return gi((i = (i + " " + mi(t)).trim())) ? i : "";
  }
  function mi(t) {
    var i = "";
    return (
      t &&
        t.childNodes &&
        t.childNodes.length &&
        K(t.childNodes, function (t) {
          var e;
          if (
            t &&
            "span" === (null == (e = t.tagName) ? void 0 : e.toLowerCase())
          )
            try {
              var r = ri(t);
              ((i = (i + " " + r).trim()),
                t.childNodes &&
                  t.childNodes.length &&
                  (i = (i + " " + mi(t)).trim()));
            } catch (t) {
              q.error("[AutoCapture]", t);
            }
        }),
      i
    );
  }
  function bi(t) {
    return (function (t) {
      var i = t.map((t) => {
        var i,
          e,
          r = "";
        if ((t.tag_name && (r += t.tag_name), t.attr_class))
          for (var s of (t.attr_class.sort(), t.attr_class))
            r += "." + s.replace(/"/g, "");
        var n = f(
            {},
            t.text ? { text: t.text } : {},
            {
              "nth-child": null !== (i = t.nth_child) && void 0 !== i ? i : 0,
              "nth-of-type":
                null !== (e = t.nth_of_type) && void 0 !== e ? e : 0,
            },
            t.href ? { href: t.href } : {},
            t.attr_id ? { attr_id: t.attr_id } : {},
            t.attributes,
          ),
          o = {};
        return (
          Q(n)
            .sort((t, i) => {
              var [e] = t,
                [r] = i;
              return e.localeCompare(r);
            })
            .forEach((t) => {
              var [i, e] = t;
              return (o[yi(i.toString())] = yi(e.toString()));
            }),
          (r += ":"),
          (r += Q(o)
            .map((t) => {
              var [i, e] = t;
              return i + '="' + e + '"';
            })
            .join(""))
        );
      });
      return i.join(";");
    })(
      (function (t) {
        return t.map((t) => {
          var i,
            e,
            r = {
              text: null == (i = t.$el_text) ? void 0 : i.slice(0, 400),
              tag_name: t.tag_name,
              href: null == (e = t.attr__href) ? void 0 : e.slice(0, 2048),
              attr_class: wi(t),
              attr_id: t.attr__id,
              nth_child: t.nth_child,
              nth_of_type: t.nth_of_type,
              attributes: {},
            };
          return (
            Q(t)
              .filter((t) => {
                var [i] = t;
                return 0 === i.indexOf("attr__");
              })
              .forEach((t) => {
                var [i, e] = t;
                return (r.attributes[i] = e);
              }),
            r
          );
        });
      })(t),
    );
  }
  function yi(t) {
    return t.replace(/"|\\"/g, '\\"');
  }
  function wi(t) {
    var i = t.attr__class;
    return i ? (x(i) ? i : Zt(i)) : void 0;
  }
  class Si {
    constructor() {
      this.clicks = [];
    }
    isRageClick(t, i, e) {
      var r = this.clicks[this.clicks.length - 1];
      if (
        r &&
        Math.abs(t - r.x) + Math.abs(i - r.y) < 30 &&
        e - r.timestamp < 1e3
      ) {
        if (
          (this.clicks.push({ x: t, y: i, timestamp: e }),
          3 === this.clicks.length)
        )
          return !0;
      } else this.clicks = [{ x: t, y: i, timestamp: e }];
      return !1;
    }
  }
  var $i = "$copy_autocapture",
    xi = (function (t) {
      return ((t.GZipJS = "gzip-js"), (t.Base64 = "base64"), t);
    })({}),
    ki = ["fatal", "error", "warning", "log", "info", "debug"],
    Ei = ["localhost", "127.0.0.1"],
    Ii = (t) => {
      var i = null == o ? void 0 : o.createElement("a");
      return P(i) ? null : ((i.href = t), i);
    },
    Pi = function (t, i) {
      var e, r;
      void 0 === i && (i = "&");
      var s = [];
      return (
        K(t, function (t, i) {
          P(t) ||
            P(i) ||
            "undefined" === i ||
            ((e = encodeURIComponent(
              ((t) => t instanceof File)(t) ? t.name : t.toString(),
            )),
            (r = encodeURIComponent(i)),
            (s[s.length] = r + "=" + e));
        }),
        s.join(i)
      );
    },
    Ri = function (t, i) {
      for (
        var e,
          r = ((t.split("#")[0] || "").split(/\?(.*)/)[1] || "")
            .replace(/^\?+/g, "")
            .split("&"),
          s = 0;
        s < r.length;
        s++
      ) {
        var n = r[s].split("=");
        if (n[0] === i) {
          e = n;
          break;
        }
      }
      if (!x(e) || e.length < 2) return "";
      var o = e[1];
      try {
        o = decodeURIComponent(o);
      } catch (t) {
        q.error("Skipping decoding for malformed query param: " + o);
      }
      return o.replace(/\+/g, " ");
    },
    Ti = function (t, i, e) {
      if (!t || !i || !i.length) return t;
      for (
        var r = t.split("#"),
          s = r[0] || "",
          n = r[1],
          o = s.split("?"),
          a = o[1],
          l = o[0],
          h = (a || "").split("&"),
          u = [],
          d = 0;
        d < h.length;
        d++
      ) {
        var v = h[d].split("=");
        x(v) && (i.includes(v[0]) ? u.push(v[0] + "=" + e) : u.push(h[d]));
      }
      var c = l;
      return (
        null != a && (c += "?" + u.join("&")),
        null != n && (c += "#" + n),
        c
      );
    },
    Ci = function (t, i) {
      var e = t.match(new RegExp(i + "=([^&]*)"));
      return e ? e[1] : null;
    },
    Mi = H("[AutoCapture]");
  function Fi(t, i) {
    return i.length > t ? i.slice(0, t) + "..." : i;
  }
  function Oi(t) {
    if (t.previousElementSibling) return t.previousElementSibling;
    var i = t;
    do {
      i = i.previousSibling;
    } while (i && !Kt(i));
    return i;
  }
  function Ai(t, i, e, r) {
    var s = t.tagName.toLowerCase(),
      n = { tag_name: s };
    ni.indexOf(s) > -1 &&
      !e &&
      ("a" === s.toLowerCase() || "button" === s.toLowerCase()
        ? (n.$el_text = Fi(1024, _i(t)))
        : (n.$el_text = Fi(1024, ri(t))));
    var o = ii(t);
    (o.length > 0 &&
      (n.classes = o.filter(function (t) {
        return "" !== t;
      })),
      K(t.attributes, function (e) {
        var s;
        if (
          (!hi(t) ||
            -1 !== ["name", "id", "class", "aria-label"].indexOf(e.name)) &&
          (null == r || !r.includes(e.name)) &&
          !i &&
          gi(e.value) &&
          ((s = e.name),
          !R(s) ||
            ("_ngcontent" !== s.substring(0, 10) &&
              "_nghost" !== s.substring(0, 7)))
        ) {
          var o = e.value;
          ("class" === e.name && (o = Zt(o).join(" ")),
            (n["attr__" + e.name] = Fi(1024, o)));
        }
      }));
    for (var a = 1, l = 1, h = t; (h = Oi(h)); )
      (a++, h.tagName === t.tagName && l++);
    return ((n.nth_child = a), (n.nth_of_type = l), n);
  }
  function Di(i, e) {
    for (
      var r,
        s,
        {
          e: n,
          maskAllElementAttributes: o,
          maskAllText: a,
          elementAttributeIgnoreList: l,
          elementsChainAsString: h,
        } = e,
        u = [i],
        d = i;
      d.parentNode && !Yt(d, "body");

    )
      Qt(d.parentNode)
        ? (u.push(d.parentNode.host), (d = d.parentNode.host))
        : (u.push(d.parentNode), (d = d.parentNode));
    var v,
      c = [],
      f = {},
      p = !1,
      g = !1;
    if (
      (K(u, (t) => {
        var i = li(t);
        ("a" === t.tagName.toLowerCase() &&
          ((p = t.getAttribute("href")), (p = i && p && gi(p) && p)),
          _(ii(t), "ph-no-capture") && (g = !0),
          c.push(Ai(t, o, a, l)));
        var e = (function (t) {
          if (!li(t)) return {};
          var i = {};
          return (
            K(t.attributes, function (t) {
              if (t.name && 0 === t.name.indexOf("data-ph-capture-attribute")) {
                var e = t.name.replace("data-ph-capture-attribute-", ""),
                  r = t.value;
                e && r && gi(r) && (i[e] = r);
              }
            }),
            i
          );
        })(t);
        Y(f, e);
      }),
      g)
    )
      return { props: {}, explicitNoCapture: g };
    if (
      (a ||
        ("a" === i.tagName.toLowerCase() || "button" === i.tagName.toLowerCase()
          ? (c[0].$el_text = _i(i))
          : (c[0].$el_text = ri(i))),
      p)
    ) {
      var m, b;
      c[0].attr__href = p;
      var y = null == (m = Ii(p)) ? void 0 : m.host,
        w = null == t || null == (b = t.location) ? void 0 : b.host;
      y && w && y !== w && (v = p);
    }
    return {
      props: Y(
        { $event_type: n.type, $ce_version: 1 },
        h ? {} : { $elements: c },
        { $elements_chain: bi(c) },
        null != (r = c[0]) && r.$el_text
          ? { $el_text: null == (s = c[0]) ? void 0 : s.$el_text }
          : {},
        v && "click" === n.type ? { $external_click_url: v } : {},
        f,
      ),
    };
  }
  class ji {
    constructor(t) {
      ((this.C = !1),
        (this.M = null),
        (this.rageclicks = new Si()),
        (this.F = !1),
        (this.instance = t),
        (this.O = null));
    }
    get A() {
      var t,
        i,
        e = E(this.instance.config.autocapture)
          ? this.instance.config.autocapture
          : {};
      return (
        (e.url_allowlist =
          null == (t = e.url_allowlist) ? void 0 : t.map((t) => new RegExp(t))),
        (e.url_ignorelist =
          null == (i = e.url_ignorelist)
            ? void 0
            : i.map((t) => new RegExp(t))),
        e
      );
    }
    D() {
      if (this.isBrowserSupported()) {
        if (t && o) {
          var i = (i) => {
            i = i || (null == t ? void 0 : t.event);
            try {
              this.j(i);
            } catch (t) {
              Mi.error("Failed to capture event", t);
            }
          };
          if (
            (ot(o, "submit", i, { capture: !0 }),
            ot(o, "change", i, { capture: !0 }),
            ot(o, "click", i, { capture: !0 }),
            this.A.capture_copied_text)
          ) {
            var e = (i) => {
              ((i = i || (null == t ? void 0 : t.event)), this.j(i, $i));
            };
            (ot(o, "copy", e, { capture: !0 }),
              ot(o, "cut", e, { capture: !0 }));
          }
        }
      } else
        Mi.info(
          "Disabling Automatic Event Collection because this browser is not supported",
        );
    }
    startIfEnabled() {
      this.isEnabled && !this.C && (this.D(), (this.C = !0));
    }
    onRemoteConfig(t) {
      (t.elementsChainAsString && (this.F = t.elementsChainAsString),
        this.instance.persistence &&
          this.instance.persistence.register({ [ut]: !!t.autocapture_opt_out }),
        (this.M = !!t.autocapture_opt_out),
        this.startIfEnabled());
    }
    setElementSelectors(t) {
      this.O = t;
    }
    getElementSelectors(t) {
      var i,
        e = [];
      return (
        null == (i = this.O) ||
          i.forEach((i) => {
            var r = null == o ? void 0 : o.querySelectorAll(i);
            null == r ||
              r.forEach((r) => {
                t === r && e.push(i);
              });
          }),
        e
      );
    }
    get isEnabled() {
      var t,
        i,
        e = null == (t = this.instance.persistence) ? void 0 : t.props[ut],
        r = this.M;
      if (C(r) && !O(e) && !this.instance.L()) return !1;
      var s = null !== (i = this.M) && void 0 !== i ? i : !!e;
      return !!this.instance.config.autocapture && !s;
    }
    j(i, e) {
      if ((void 0 === e && (e = "$autocapture"), this.isEnabled)) {
        var r,
          s = si(i);
        if (
          (Xt(s) && (s = s.parentNode || null),
          "$autocapture" === e && "click" === i.type && i instanceof MouseEvent)
        )
          this.instance.config.rageclick &&
            null != (r = this.rageclicks) &&
            r.isRageClick(i.clientX, i.clientY, new Date().getTime()) &&
            this.j(i, "$rageclick");
        var n = e === $i;
        if (s && ai(s, i, this.A, n, n ? ["copy", "cut"] : void 0)) {
          var { props: o, explicitNoCapture: a } = Di(s, {
            e: i,
            maskAllElementAttributes:
              this.instance.config.mask_all_element_attributes,
            maskAllText: this.instance.config.mask_all_text,
            elementAttributeIgnoreList: this.A.element_attribute_ignorelist,
            elementsChainAsString: this.F,
          });
          if (a) return !1;
          var l = this.getElementSelectors(s);
          if ((l && l.length > 0 && (o.$element_selectors = l), e === $i)) {
            var h,
              u = ei(
                null == t || null == (h = t.getSelection())
                  ? void 0
                  : h.toString(),
              ),
              d = i.type || "clipboard";
            if (!u) return !1;
            ((o.$selected_content = u), (o.$copy_type = d));
          }
          return (this.instance.capture(e, o), !0);
        }
      }
    }
    isBrowserSupported() {
      return k(null == o ? void 0 : o.querySelectorAll);
    }
  }
  (Math.trunc ||
    (Math.trunc = function (t) {
      return t < 0 ? Math.ceil(t) : Math.floor(t);
    }),
    Number.isInteger ||
      (Number.isInteger = function (t) {
        return F(t) && isFinite(t) && Math.floor(t) === t;
      }));
  var Li = "0123456789abcdef";
  class Ni {
    constructor(t) {
      if (((this.bytes = t), 16 !== t.length))
        throw new TypeError("not 128-bit length");
    }
    static fromFieldsV7(t, i, e, r) {
      if (
        !Number.isInteger(t) ||
        !Number.isInteger(i) ||
        !Number.isInteger(e) ||
        !Number.isInteger(r) ||
        t < 0 ||
        i < 0 ||
        e < 0 ||
        r < 0 ||
        t > 0xffffffffffff ||
        i > 4095 ||
        e > 1073741823 ||
        r > 4294967295
      )
        throw new RangeError("invalid field value");
      var s = new Uint8Array(16);
      return (
        (s[0] = t / Math.pow(2, 40)),
        (s[1] = t / Math.pow(2, 32)),
        (s[2] = t / Math.pow(2, 24)),
        (s[3] = t / Math.pow(2, 16)),
        (s[4] = t / Math.pow(2, 8)),
        (s[5] = t),
        (s[6] = 112 | (i >>> 8)),
        (s[7] = i),
        (s[8] = 128 | (e >>> 24)),
        (s[9] = e >>> 16),
        (s[10] = e >>> 8),
        (s[11] = e),
        (s[12] = r >>> 24),
        (s[13] = r >>> 16),
        (s[14] = r >>> 8),
        (s[15] = r),
        new Ni(s)
      );
    }
    toString() {
      for (var t = "", i = 0; i < this.bytes.length; i++)
        ((t =
          t + Li.charAt(this.bytes[i] >>> 4) + Li.charAt(15 & this.bytes[i])),
          (3 !== i && 5 !== i && 7 !== i && 9 !== i) || (t += "-"));
      if (36 !== t.length) throw new Error("Invalid UUIDv7 was generated");
      return t;
    }
    clone() {
      return new Ni(this.bytes.slice(0));
    }
    equals(t) {
      return 0 === this.compareTo(t);
    }
    compareTo(t) {
      for (var i = 0; i < 16; i++) {
        var e = this.bytes[i] - t.bytes[i];
        if (0 !== e) return Math.sign(e);
      }
      return 0;
    }
  }
  class zi {
    constructor() {
      ((this.N = 0), (this.U = 0), (this.B = new qi()));
    }
    generate() {
      var t = this.generateOrAbort();
      if (P(t)) {
        this.N = 0;
        var i = this.generateOrAbort();
        if (P(i))
          throw new Error("Could not generate UUID after timestamp reset");
        return i;
      }
      return t;
    }
    generateOrAbort() {
      var t = Date.now();
      if (t > this.N) ((this.N = t), this.q());
      else {
        if (!(t + 1e4 > this.N)) return;
        (this.U++, this.U > 4398046511103 && (this.N++, this.q()));
      }
      return Ni.fromFieldsV7(
        this.N,
        Math.trunc(this.U / Math.pow(2, 30)),
        this.U & (Math.pow(2, 30) - 1),
        this.B.nextUint32(),
      );
    }
    q() {
      this.U = 1024 * this.B.nextUint32() + (1023 & this.B.nextUint32());
    }
  }
  var Ui,
    Bi = (t) => {
      if ("undefined" != typeof UUIDV7_DENY_WEAK_RNG && UUIDV7_DENY_WEAK_RNG)
        throw new Error("no cryptographically strong RNG available");
      for (var i = 0; i < t.length; i++)
        t[i] =
          65536 * Math.trunc(65536 * Math.random()) +
          Math.trunc(65536 * Math.random());
      return t;
    };
  t &&
    !P(t.crypto) &&
    crypto.getRandomValues &&
    (Bi = (t) => crypto.getRandomValues(t));
  class qi {
    constructor() {
      ((this.H = new Uint32Array(8)), (this.W = 1 / 0));
    }
    nextUint32() {
      return (
        this.W >= this.H.length && (Bi(this.H), (this.W = 0)),
        this.H[this.W++]
      );
    }
  }
  var Hi = () => Wi().toString(),
    Wi = () => (Ui || (Ui = new zi())).generate(),
    Gi = "";
  var Ji = /[a-z0-9][a-z0-9-]+\.[a-z]{2,}$/i;
  function Vi(t, i) {
    if (i) {
      var e = (function (t, i) {
        if ((void 0 === i && (i = o), Gi)) return Gi;
        if (!i) return "";
        if (["localhost", "127.0.0.1"].includes(t)) return "";
        for (
          var e = t.split("."),
            r = Math.min(e.length, 8),
            s = "dmn_chk_" + Hi();
          !Gi && r--;

        ) {
          var n = e.slice(r).join("."),
            a = s + "=1;domain=." + n + ";path=/";
          ((i.cookie = a + ";max-age=3"),
            i.cookie.includes(s) && ((i.cookie = a + ";max-age=0"), (Gi = n)));
        }
        return Gi;
      })(t);
      if (!e) {
        var r = ((t) => {
          var i = t.match(Ji);
          return i ? i[0] : "";
        })(t);
        (r !== e &&
          q.info("Warning: cookie subdomain discovery mismatch", r, e),
          (e = r));
      }
      return e ? "; domain=." + e : "";
    }
    return "";
  }
  var Ki = {
      G: () => !!o,
      J: function (t) {
        q.error("cookieStore error: " + t);
      },
      V: function (t) {
        if (o) {
          try {
            for (
              var i = t + "=",
                e = o.cookie.split(";").filter((t) => t.length),
                r = 0;
              r < e.length;
              r++
            ) {
              for (var s = e[r]; " " == s.charAt(0); )
                s = s.substring(1, s.length);
              if (0 === s.indexOf(i))
                return decodeURIComponent(s.substring(i.length, s.length));
            }
          } catch (t) {}
          return null;
        }
      },
      K: function (t) {
        var i;
        try {
          i = JSON.parse(Ki.V(t)) || {};
        } catch (t) {}
        return i;
      },
      Y: function (t, i, e, r, s) {
        if (o)
          try {
            var n = "",
              a = "",
              l = Vi(o.location.hostname, r);
            if (e) {
              var h = new Date();
              (h.setTime(h.getTime() + 24 * e * 60 * 60 * 1e3),
                (n = "; expires=" + h.toUTCString()));
            }
            s && (a = "; secure");
            var u =
              t +
              "=" +
              encodeURIComponent(JSON.stringify(i)) +
              n +
              "; SameSite=Lax; path=/" +
              l +
              a;
            return (
              u.length > 3686.4 &&
                q.warn("cookieStore warning: large cookie, len=" + u.length),
              (o.cookie = u),
              u
            );
          } catch (t) {
            return;
          }
      },
      X: function (t, i) {
        if (null != o && o.cookie)
          try {
            Ki.Y(t, "", -1, i);
          } catch (t) {
            return;
          }
      },
    },
    Yi = null,
    Xi = {
      G: function () {
        if (!C(Yi)) return Yi;
        var i = !0;
        if (P(t)) i = !1;
        else
          try {
            var e = "__mplssupport__";
            (Xi.Y(e, "xyz"), '"xyz"' !== Xi.V(e) && (i = !1), Xi.X(e));
          } catch (t) {
            i = !1;
          }
        return (
          i ||
            q.error("localStorage unsupported; falling back to cookie store"),
          (Yi = i),
          i
        );
      },
      J: function (t) {
        q.error("localStorage error: " + t);
      },
      V: function (i) {
        try {
          return null == t ? void 0 : t.localStorage.getItem(i);
        } catch (t) {
          Xi.J(t);
        }
        return null;
      },
      K: function (t) {
        try {
          return JSON.parse(Xi.V(t)) || {};
        } catch (t) {}
        return null;
      },
      Y: function (i, e) {
        try {
          null == t || t.localStorage.setItem(i, JSON.stringify(e));
        } catch (t) {
          Xi.J(t);
        }
      },
      X: function (i) {
        try {
          null == t || t.localStorage.removeItem(i);
        } catch (t) {
          Xi.J(t);
        }
      },
    },
    Qi = ["distinct_id", Et, It, Ht, qt],
    Zi = f({}, Xi, {
      K: function (t) {
        try {
          var i = {};
          try {
            i = Ki.K(t) || {};
          } catch (t) {}
          var e = Y(i, JSON.parse(Xi.V(t) || "{}"));
          return (Xi.Y(t, e), e);
        } catch (t) {}
        return null;
      },
      Y: function (t, i, e, r, s, n) {
        try {
          Xi.Y(t, i, void 0, void 0, n);
          var o = {};
          (Qi.forEach((t) => {
            i[t] && (o[t] = i[t]);
          }),
            Object.keys(o).length && Ki.Y(t, o, e, r, s, n));
        } catch (t) {
          Xi.J(t);
        }
      },
      X: function (i, e) {
        try {
          (null == t || t.localStorage.removeItem(i), Ki.X(i, e));
        } catch (t) {
          Xi.J(t);
        }
      },
    }),
    te = {},
    ie = {
      G: function () {
        return !0;
      },
      J: function (t) {
        q.error("memoryStorage error: " + t);
      },
      V: function (t) {
        return te[t] || null;
      },
      K: function (t) {
        return te[t] || null;
      },
      Y: function (t, i) {
        te[t] = i;
      },
      X: function (t) {
        delete te[t];
      },
    },
    ee = null,
    re = {
      G: function () {
        if (!C(ee)) return ee;
        if (((ee = !0), P(t))) ee = !1;
        else
          try {
            var i = "__support__";
            (re.Y(i, "xyz"), '"xyz"' !== re.V(i) && (ee = !1), re.X(i));
          } catch (t) {
            ee = !1;
          }
        return ee;
      },
      J: function (t) {
        q.error("sessionStorage error: ", t);
      },
      V: function (i) {
        try {
          return null == t ? void 0 : t.sessionStorage.getItem(i);
        } catch (t) {
          re.J(t);
        }
        return null;
      },
      K: function (t) {
        try {
          return JSON.parse(re.V(t)) || null;
        } catch (t) {}
        return null;
      },
      Y: function (i, e) {
        try {
          null == t || t.sessionStorage.setItem(i, JSON.stringify(e));
        } catch (t) {
          re.J(t);
        }
      },
      X: function (i) {
        try {
          null == t || t.sessionStorage.removeItem(i);
        } catch (t) {
          re.J(t);
        }
      },
    },
    se = (function (t) {
      return (
        (t[(t.PENDING = -1)] = "PENDING"),
        (t[(t.DENIED = 0)] = "DENIED"),
        (t[(t.GRANTED = 1)] = "GRANTED"),
        t
      );
    })({});
  class ne {
    constructor(t) {
      this._instance = t;
    }
    get A() {
      return this._instance.config;
    }
    get consent() {
      return this.Z() ? se.DENIED : this.tt;
    }
    isOptedOut() {
      return (
        "always" === this.A.cookieless_mode ||
        this.consent === se.DENIED ||
        (this.consent === se.PENDING &&
          (this.A.opt_out_capturing_by_default ||
            "on_reject" === this.A.cookieless_mode))
      );
    }
    isOptedIn() {
      return !this.isOptedOut();
    }
    isExplicitlyOptedOut() {
      return this.consent === se.DENIED;
    }
    optInOut(t) {
      this.it.Y(
        this.et,
        t ? 1 : 0,
        this.A.cookie_expiration,
        this.A.cross_subdomain_cookie,
        this.A.secure_cookie,
      );
    }
    reset() {
      this.it.X(this.et, this.A.cross_subdomain_cookie);
    }
    get et() {
      var {
        token: t,
        opt_out_capturing_cookie_prefix: i,
        consent_persistence_name: e,
      } = this._instance.config;
      return e || (i ? i + t : "__ph_opt_in_out_" + t);
    }
    get tt() {
      var t = this.it.V(this.et);
      return L(t) ? se.GRANTED : _(N, t) ? se.DENIED : se.PENDING;
    }
    get it() {
      if (!this.rt) {
        var t = this.A.opt_out_capturing_persistence_type;
        this.rt = "localStorage" === t ? Xi : Ki;
        var i = "localStorage" === t ? Ki : Xi;
        i.V(this.et) &&
          (this.rt.V(this.et) || this.optInOut(L(i.V(this.et))),
          i.X(this.et, this.A.cross_subdomain_cookie));
      }
      return this.rt;
    }
    Z() {
      return (
        !!this.A.respect_dnt &&
        !!nt(
          [
            null == n ? void 0 : n.doNotTrack,
            null == n ? void 0 : n.msDoNotTrack,
            v.doNotTrack,
          ],
          (t) => L(t),
        )
      );
    }
  }
  var oe = H("[Dead Clicks]"),
    ae = () => !0,
    le = (t) => {
      var i,
        e = !(null == (i = t.instance.persistence) || !i.get_property(gt)),
        r = t.instance.config.capture_dead_clicks;
      return O(r) ? r : e;
    };
  class he {
    get lazyLoadedDeadClicksAutocapture() {
      return this.st;
    }
    constructor(t, i, e) {
      ((this.instance = t),
        (this.isEnabled = i),
        (this.onCapture = e),
        this.startIfEnabled());
    }
    onRemoteConfig(t) {
      (this.instance.persistence &&
        this.instance.persistence.register({
          [gt]: null == t ? void 0 : t.captureDeadClicks,
        }),
        this.startIfEnabled());
    }
    startIfEnabled() {
      this.isEnabled(this) &&
        this.nt(() => {
          this.ot();
        });
    }
    nt(t) {
      var i, e;
      (null != (i = v.__PosthogExtensions__) &&
        i.initDeadClicksAutocapture &&
        t(),
        null == (e = v.__PosthogExtensions__) ||
          null == e.loadExternalDependency ||
          e.loadExternalDependency(
            this.instance,
            "dead-clicks-autocapture",
            (i) => {
              i ? oe.error("failed to load script", i) : t();
            },
          ));
    }
    ot() {
      var t;
      if (o) {
        if (
          !this.st &&
          null != (t = v.__PosthogExtensions__) &&
          t.initDeadClicksAutocapture
        ) {
          var i = E(this.instance.config.capture_dead_clicks)
            ? this.instance.config.capture_dead_clicks
            : {};
          ((i.__onCapture = this.onCapture),
            (this.st = v.__PosthogExtensions__.initDeadClicksAutocapture(
              this.instance,
              i,
            )),
            this.st.start(o),
            oe.info("starting..."));
        }
      } else oe.error("`document` not found. Cannot start.");
    }
    stop() {
      this.st && (this.st.stop(), (this.st = void 0), oe.info("stopping..."));
    }
  }
  var ue = H("[ExceptionAutocapture]");
  class de {
    constructor(i) {
      var e, r, s;
      ((this.lt = () => {
        var i;
        if (
          t &&
          this.isEnabled &&
          null != (i = v.__PosthogExtensions__) &&
          i.errorWrappingFunctions
        ) {
          var e = v.__PosthogExtensions__.errorWrappingFunctions.wrapOnError,
            r =
              v.__PosthogExtensions__.errorWrappingFunctions
                .wrapUnhandledRejection,
            s = v.__PosthogExtensions__.errorWrappingFunctions.wrapConsoleError;
          try {
            (!this.ht &&
              this.A.capture_unhandled_errors &&
              (this.ht = e(this.captureException.bind(this))),
              !this.ut &&
                this.A.capture_unhandled_rejections &&
                (this.ut = r(this.captureException.bind(this))),
              !this.dt &&
                this.A.capture_console_errors &&
                (this.dt = s(this.captureException.bind(this))));
          } catch (t) {
            (ue.error("failed to start", t), this.vt());
          }
        }
      }),
        (this._instance = i),
        (this.ct = !(null == (e = this._instance.persistence) || !e.props[vt])),
        (this.A = this.ft()),
        (this.gt = new U({
          refillRate:
            null !==
              (r =
                this._instance.config.error_tracking
                  .__exceptionRateLimiterRefillRate) && void 0 !== r
              ? r
              : 1,
          bucketSize:
            null !==
              (s =
                this._instance.config.error_tracking
                  .__exceptionRateLimiterBucketSize) && void 0 !== s
              ? s
              : 10,
          refillInterval: 1e4,
          P: ue,
        })),
        this.startIfEnabled());
    }
    ft() {
      var t = this._instance.config.capture_exceptions,
        i = {
          capture_unhandled_errors: !1,
          capture_unhandled_rejections: !1,
          capture_console_errors: !1,
        };
      return (
        E(t)
          ? (i = f({}, i, t))
          : (P(t) ? this.ct : t) &&
            (i = f({}, i, {
              capture_unhandled_errors: !0,
              capture_unhandled_rejections: !0,
            })),
        i
      );
    }
    get isEnabled() {
      return (
        this.A.capture_console_errors ||
        this.A.capture_unhandled_errors ||
        this.A.capture_unhandled_rejections
      );
    }
    startIfEnabled() {
      this.isEnabled && (ue.info("enabled"), this.nt(this.lt));
    }
    nt(t) {
      var i, e;
      (null != (i = v.__PosthogExtensions__) && i.errorWrappingFunctions && t(),
        null == (e = v.__PosthogExtensions__) ||
          null == e.loadExternalDependency ||
          e.loadExternalDependency(
            this._instance,
            "exception-autocapture",
            (i) => {
              if (i) return ue.error("failed to load script", i);
              t();
            },
          ));
    }
    vt() {
      var t, i, e;
      (null == (t = this.ht) || t.call(this),
        (this.ht = void 0),
        null == (i = this.ut) || i.call(this),
        (this.ut = void 0),
        null == (e = this.dt) || e.call(this),
        (this.dt = void 0));
    }
    onRemoteConfig(t) {
      var i = t.autocaptureExceptions;
      ((this.ct = !!i || !1),
        (this.A = this.ft()),
        this._instance.persistence &&
          this._instance.persistence.register({ [vt]: this.ct }),
        this.startIfEnabled());
    }
    captureException(t) {
      var i,
        e = this._instance.requestRouter.endpointFor("ui");
      t.$exception_personURL =
        e +
        "/project/" +
        this._instance.config.token +
        "/person/" +
        this._instance.get_distinct_id();
      var r =
        null !== (i = t.$exception_list[0].type) && void 0 !== i
          ? i
          : "Exception";
      this.gt.consumeRateLimit(r)
        ? ue.info(
            "Skipping exception capture because of client rate limiting.",
            { exception: t.$exception_list[0].type },
          )
        : this._instance.exceptions.sendExceptionEvent(t);
    }
  }
  function ve(t) {
    return !P(Event) && ce(t, Event);
  }
  function ce(t, i) {
    try {
      return t instanceof i;
    } catch (t) {
      return !1;
    }
  }
  function fe(t) {
    switch (Object.prototype.toString.call(t)) {
      case "[object Error]":
      case "[object Exception]":
      case "[object DOMException]":
      case "[object DOMError]":
        return !0;
      default:
        return ce(t, Error);
    }
  }
  function pe(t, i) {
    return Object.prototype.toString.call(t) === "[object " + i + "]";
  }
  function ge(t) {
    return pe(t, "DOMError");
  }
  var _e = /\(error: (.*)\)/,
    me = 50,
    be = "?";
  function ye(t, i, e, r) {
    var s = {
      platform: "web:javascript",
      filename: t,
      function: "<anonymous>" === i ? be : i,
      in_app: !0,
    };
    return (P(e) || (s.lineno = e), P(r) || (s.colno = r), s);
  }
  var we = /^\s*at (\S+?)(?::(\d+))(?::(\d+))\s*$/i,
    Se =
      /^\s*at (?:(.+?\)(?: \[.+\])?|.*?) ?\((?:address at )?)?(?:async )?((?:<anonymous>|[-a-z]+:|.*bundle|\/)?.*?)(?::(\d+))?(?::(\d+))?\)?\s*$/i,
    $e = /\((\S*)(?::(\d+))(?::(\d+))\)/,
    xe =
      /^\s*(.*?)(?:\((.*?)\))?(?:^|@)?((?:[-a-z]+)?:\/.*?|\[native code\]|[^@]*(?:bundle|\d+\.js)|\/[\w\-. /=]+)(?::(\d+))?(?::(\d+))?\s*$/i,
    ke = /(\S+) line (\d+)(?: > eval line \d+)* > eval/i,
    Ee = (function () {
      for (var t = arguments.length, i = new Array(t), e = 0; e < t; e++)
        i[e] = arguments[e];
      var r = i.sort((t, i) => t[0] - i[0]).map((t) => t[1]);
      return function (t, i) {
        void 0 === i && (i = 0);
        for (var e = [], s = t.split("\n"), n = i; n < s.length; n++) {
          var o = s[n];
          if (!(o.length > 1024)) {
            var a = _e.test(o) ? o.replace(_e, "$1") : o;
            if (!a.match(/\S*Error: /)) {
              for (var l of r) {
                var h = l(a);
                if (h) {
                  e.push(h);
                  break;
                }
              }
              if (e.length >= me) break;
            }
          }
        }
        return (function (t) {
          if (!t.length) return [];
          var i = Array.from(t);
          return (
            i.reverse(),
            i.slice(0, me).map((t) =>
              f({}, t, {
                filename: t.filename || Ie(i).filename,
                function: t.function || be,
              }),
            )
          );
        })(e);
      };
    })(
      ...[
        [
          30,
          (t) => {
            var i = we.exec(t);
            if (i) {
              var [, e, r, s] = i;
              return ye(e, be, +r, +s);
            }
            var n = Se.exec(t);
            if (n) {
              if (n[2] && 0 === n[2].indexOf("eval")) {
                var o = $e.exec(n[2]);
                o && ((n[2] = o[1]), (n[3] = o[2]), (n[4] = o[3]));
              }
              var [a, l] = Ce(n[1] || be, n[2]);
              return ye(l, a, n[3] ? +n[3] : void 0, n[4] ? +n[4] : void 0);
            }
          },
        ],
        [
          50,
          (t) => {
            var i = xe.exec(t);
            if (i) {
              if (i[3] && i[3].indexOf(" > eval") > -1) {
                var e = ke.exec(i[3]);
                e &&
                  ((i[1] = i[1] || "eval"),
                  (i[3] = e[1]),
                  (i[4] = e[2]),
                  (i[5] = ""));
              }
              var r = i[3],
                s = i[1] || be;
              return (
                ([s, r] = Ce(s, r)),
                ye(r, s, i[4] ? +i[4] : void 0, i[5] ? +i[5] : void 0)
              );
            }
          },
        ],
      ],
    );
  function Ie(t) {
    return t[t.length - 1] || {};
  }
  var Pe,
    Re,
    Te,
    Ce = (t, i) => {
      var e = -1 !== t.indexOf("safari-extension"),
        r = -1 !== t.indexOf("safari-web-extension");
      return e || r
        ? [
            -1 !== t.indexOf("@") ? t.split("@")[0] : be,
            e ? "safari-extension:" + i : "safari-web-extension:" + i,
          ]
        : [t, i];
    };
  var Me =
    /^(?:[Uu]ncaught (?:exception: )?)?(?:((?:Eval|Internal|Range|Reference|Syntax|Type|URI|)Error): )?(.*)$/i;
  function Fe(t, i) {
    void 0 === i && (i = 0);
    var e = t.stacktrace || t.stack || "",
      r = (function (t) {
        if (t && Oe.test(t.message)) return 1;
        return 0;
      })(t);
    try {
      var s = Ee,
        n = (function (t, i) {
          var e = (function (t) {
            var i = globalThis._posthogChunkIds;
            if (!i) return {};
            var e = Object.keys(i);
            return (
              (Te && e.length === Re) ||
                ((Re = e.length),
                (Te = e.reduce((e, r) => {
                  Pe || (Pe = {});
                  var s = Pe[r];
                  if (s) e[s[0]] = s[1];
                  else
                    for (var n = t(r), o = n.length - 1; o >= 0; o--) {
                      var a = n[o],
                        l = null == a ? void 0 : a.filename,
                        h = i[r];
                      if (l && h) {
                        ((e[l] = h), (Pe[r] = [l, h]));
                        break;
                      }
                    }
                  return e;
                }, {}))),
              Te
            );
          })(i);
          return (
            t.forEach((t) => {
              t.filename && (t.chunk_id = e[t.filename]);
            }),
            t
          );
        })(s(e, r), s);
      return n.slice(0, n.length - i);
    } catch (t) {}
    return [];
  }
  var Oe = /Minified React error #\d+;/i;
  function Ae(t, i) {
    var e,
      r,
      s = Fe(t),
      n = null === (e = null == i ? void 0 : i.handled) || void 0 === e || e,
      o = null !== (r = null == i ? void 0 : i.synthetic) && void 0 !== r && r;
    return {
      type:
        null != i && i.overrideExceptionType ? i.overrideExceptionType : t.name,
      value: (function (t) {
        var i = t.message;
        if (i.error && "string" == typeof i.error.message)
          return String(i.error.message);
        return String(i);
      })(t),
      stacktrace: { frames: s, type: "raw" },
      mechanism: { handled: n, synthetic: o },
    };
  }
  function De(t, i) {
    var e = Ae(t, i);
    return t.cause && fe(t.cause) && t.cause !== t
      ? [
          e,
          ...De(t.cause, {
            handled: null == i ? void 0 : i.handled,
            synthetic: null == i ? void 0 : i.synthetic,
          }),
        ]
      : [e];
  }
  function je(t, i) {
    return { $exception_list: De(t, i), $exception_level: "error" };
  }
  function Le(t, i) {
    var e,
      r,
      s,
      n = null === (e = null == i ? void 0 : i.handled) || void 0 === e || e,
      o = null === (r = null == i ? void 0 : i.synthetic) || void 0 === r || r,
      a = {
        type:
          null != i && i.overrideExceptionType
            ? i.overrideExceptionType
            : null !== (s = null == i ? void 0 : i.defaultExceptionType) &&
                void 0 !== s
              ? s
              : "Error",
        value: t || (null == i ? void 0 : i.defaultExceptionMessage),
        mechanism: { handled: n, synthetic: o },
      };
    if (null != i && i.syntheticException) {
      var l = Fe(i.syntheticException, 1);
      l.length && (a.stacktrace = { frames: l, type: "raw" });
    }
    return { $exception_list: [a], $exception_level: "error" };
  }
  function Ne(t) {
    return R(t) && !T(t) && ki.indexOf(t) >= 0;
  }
  function ze(t, i) {
    var e,
      r,
      s = null === (e = null == i ? void 0 : i.handled) || void 0 === e || e,
      n = null === (r = null == i ? void 0 : i.synthetic) || void 0 === r || r,
      o =
        null != i && i.overrideExceptionType
          ? i.overrideExceptionType
          : ve(t)
            ? t.constructor.name
            : "Error",
      a =
        "Non-Error 'exception' captured with keys: " +
        (function (t, i) {
          void 0 === i && (i = 40);
          var e = Object.keys(t);
          if ((e.sort(), !e.length)) return "[object has no keys]";
          for (var r = e.length; r > 0; r--) {
            var s = e.slice(0, r).join(", ");
            if (!(s.length > i))
              return r === e.length || s.length <= i
                ? s
                : s.slice(0, i) + "...";
          }
          return "";
        })(t),
      l = { type: o, value: a, mechanism: { handled: s, synthetic: n } };
    if (null != i && i.syntheticException) {
      var h = Fe(null == i ? void 0 : i.syntheticException, 1);
      h.length && (l.stacktrace = { frames: h, type: "raw" });
    }
    return {
      $exception_list: [l],
      $exception_level: Ne(t.level) ? t.level : "error",
    };
  }
  function Ue(t, i) {
    var { error: e, event: r } = t,
      s = { $exception_list: [] },
      n = e || r;
    if (
      ge(n) ||
      (function (t) {
        return pe(t, "DOMException");
      })(n)
    ) {
      var o = n;
      if (
        (function (t) {
          return "stack" in t;
        })(n)
      )
        s = je(n, i);
      else {
        var a = o.name || (ge(o) ? "DOMError" : "DOMException"),
          l = o.message ? a + ": " + o.message : a;
        s = Le(
          l,
          f({}, i, {
            overrideExceptionType: ge(o) ? "DOMError" : "DOMException",
            defaultExceptionMessage: l,
          }),
        );
      }
      return ("code" in o && (s.$exception_DOMException_code = "" + o.code), s);
    }
    if (
      (function (t) {
        return pe(t, "ErrorEvent");
      })(n) &&
      n.error
    )
      return je(n.error, i);
    if (fe(n)) return je(n, i);
    if (
      (function (t) {
        return pe(t, "Object");
      })(n) ||
      ve(n)
    )
      return ze(n, i);
    if (P(e) && R(r)) {
      var h = "Error",
        u = r,
        d = r.match(Me);
      return (
        d && ((h = d[1]), (u = d[2])),
        Le(
          u,
          f({}, i, { overrideExceptionType: h, defaultExceptionMessage: u }),
        )
      );
    }
    return Le(n, i);
  }
  function Be(t, i, e) {
    try {
      if (!(i in t)) return () => {};
      var r = t[i],
        s = e(r);
      return (
        k(s) &&
          ((s.prototype = s.prototype || {}),
          Object.defineProperties(s, {
            __posthog_wrapped__: { enumerable: !1, value: !0 },
          })),
        (t[i] = s),
        () => {
          t[i] = r;
        }
      );
    } catch (t) {
      return () => {};
    }
  }
  class qe {
    constructor(i) {
      var e;
      ((this._instance = i),
        (this._t =
          (null == t || null == (e = t.location) ? void 0 : e.pathname) || ""));
    }
    get isEnabled() {
      return "history_change" === this._instance.config.capture_pageview;
    }
    startIfEnabled() {
      this.isEnabled &&
        (q.info("History API monitoring enabled, starting..."),
        this.monitorHistoryChanges());
    }
    stop() {
      (this.bt && this.bt(),
        (this.bt = void 0),
        q.info("History API monitoring stopped"));
    }
    monitorHistoryChanges() {
      var i, e;
      if (t && t.history) {
        var r = this;
        ((null != (i = t.history.pushState) && i.__posthog_wrapped__) ||
          Be(
            t.history,
            "pushState",
            (t) =>
              function (i, e, s) {
                (t.call(this, i, e, s), r.yt("pushState"));
              },
          ),
          (null != (e = t.history.replaceState) && e.__posthog_wrapped__) ||
            Be(
              t.history,
              "replaceState",
              (t) =>
                function (i, e, s) {
                  (t.call(this, i, e, s), r.yt("replaceState"));
                },
            ),
          this.wt());
      }
    }
    yt(i) {
      try {
        var e,
          r = null == t || null == (e = t.location) ? void 0 : e.pathname;
        if (!r) return;
        (r !== this._t &&
          this.isEnabled &&
          this._instance.capture("$pageview", { navigation_type: i }),
          (this._t = r));
      } catch (t) {
        q.error("Error capturing " + i + " pageview", t);
      }
    }
    wt() {
      if (!this.bt) {
        var i = () => {
          this.yt("popstate");
        };
        (ot(t, "popstate", i),
          (this.bt = () => {
            t && t.removeEventListener("popstate", i);
          }));
      }
    }
  }
  function He(t) {
    var i, e;
    return (
      (null ==
      (i = JSON.stringify(
        t,
        ((e = []),
        function (t, i) {
          if (E(i)) {
            for (; e.length > 0 && e[e.length - 1] !== this; ) e.pop();
            return e.includes(i) ? "[Circular]" : (e.push(i), i);
          }
          return i;
        }),
      ))
        ? void 0
        : i.length) || 0
    );
  }
  function We(t, i) {
    if ((void 0 === i && (i = 6606028.8), t.size >= i && t.data.length > 1)) {
      var e = Math.floor(t.data.length / 2),
        r = t.data.slice(0, e),
        s = t.data.slice(e);
      return [
        We({
          size: He(r),
          data: r,
          sessionId: t.sessionId,
          windowId: t.windowId,
        }),
        We({
          size: He(s),
          data: s,
          sessionId: t.sessionId,
          windowId: t.windowId,
        }),
      ].flatMap((t) => t);
    }
    return [t];
  }
  var Ge = ((t) => (
      (t[(t.DomContentLoaded = 0)] = "DomContentLoaded"),
      (t[(t.Load = 1)] = "Load"),
      (t[(t.FullSnapshot = 2)] = "FullSnapshot"),
      (t[(t.IncrementalSnapshot = 3)] = "IncrementalSnapshot"),
      (t[(t.Meta = 4)] = "Meta"),
      (t[(t.Custom = 5)] = "Custom"),
      (t[(t.Plugin = 6)] = "Plugin"),
      t
    ))(Ge || {}),
    Je = ((t) => (
      (t[(t.Mutation = 0)] = "Mutation"),
      (t[(t.MouseMove = 1)] = "MouseMove"),
      (t[(t.MouseInteraction = 2)] = "MouseInteraction"),
      (t[(t.Scroll = 3)] = "Scroll"),
      (t[(t.ViewportResize = 4)] = "ViewportResize"),
      (t[(t.Input = 5)] = "Input"),
      (t[(t.TouchMove = 6)] = "TouchMove"),
      (t[(t.MediaInteraction = 7)] = "MediaInteraction"),
      (t[(t.StyleSheetRule = 8)] = "StyleSheetRule"),
      (t[(t.CanvasMutation = 9)] = "CanvasMutation"),
      (t[(t.Font = 10)] = "Font"),
      (t[(t.Log = 11)] = "Log"),
      (t[(t.Drag = 12)] = "Drag"),
      (t[(t.StyleDeclaration = 13)] = "StyleDeclaration"),
      (t[(t.Selection = 14)] = "Selection"),
      (t[(t.AdoptedStyleSheet = 15)] = "AdoptedStyleSheet"),
      (t[(t.CustomElement = 16)] = "CustomElement"),
      t
    ))(Je || {}),
    Ve = "[SessionRecording]",
    Ke = "redacted",
    Ye = {
      initiatorTypes: [
        "audio",
        "beacon",
        "body",
        "css",
        "early-hint",
        "embed",
        "fetch",
        "frame",
        "iframe",
        "icon",
        "image",
        "img",
        "input",
        "link",
        "navigation",
        "object",
        "ping",
        "script",
        "track",
        "video",
        "xmlhttprequest",
      ],
      maskRequestFn: (t) => t,
      recordHeaders: !1,
      recordBody: !1,
      recordInitialRequests: !1,
      recordPerformance: !1,
      performanceEntryTypeToObserve: [
        "first-input",
        "navigation",
        "paint",
        "resource",
      ],
      payloadSizeLimitBytes: 1e6,
      payloadHostDenyList: [
        ".lr-ingest.io",
        ".ingest.sentry.io",
        ".clarity.ms",
        "analytics.google.com",
        "bam.nr-data.net",
      ],
    },
    Xe = [
      "authorization",
      "x-forwarded-for",
      "authorization",
      "cookie",
      "set-cookie",
      "x-api-key",
      "x-real-ip",
      "remote-addr",
      "forwarded",
      "proxy-authorization",
      "x-csrf-token",
      "x-csrftoken",
      "x-xsrf-token",
    ],
    Qe = [
      "password",
      "secret",
      "passwd",
      "api_key",
      "apikey",
      "auth",
      "credentials",
      "mysql_pwd",
      "privatekey",
      "private_key",
      "token",
    ],
    Ze = ["/s/", "/e/", "/i/"];
  function tr(t, i, e, r) {
    if (M(t)) return t;
    var s =
      (null == i ? void 0 : i["content-length"]) ||
      (function (t) {
        return new Blob([t]).size;
      })(t);
    return (
      R(s) && (s = parseInt(s)),
      s > e ? Ve + " " + r + " body too large to record (" + s + " bytes)" : t
    );
  }
  function ir(t, i) {
    if (M(t)) return t;
    var e = t;
    return (
      gi(e, !1) || (e = Ve + " " + i + " body " + Ke),
      K(Qe, (t) => {
        var r, s;
        null != (r = e) &&
          r.length &&
          -1 !== (null == (s = e) ? void 0 : s.indexOf(t)) &&
          (e = Ve + " " + i + " body " + Ke + " as might contain: " + t);
      }),
      e
    );
  }
  var er = (t, i) => {
    var e,
      r,
      s,
      n = {
        payloadSizeLimitBytes: Ye.payloadSizeLimitBytes,
        performanceEntryTypeToObserve: [...Ye.performanceEntryTypeToObserve],
        payloadHostDenyList: [
          ...(i.payloadHostDenyList || []),
          ...Ye.payloadHostDenyList,
        ],
      },
      o = !1 !== t.session_recording.recordHeaders && i.recordHeaders,
      a = !1 !== t.session_recording.recordBody && i.recordBody,
      l = !1 !== t.capture_performance && i.recordPerformance,
      h =
        ((e = n),
        (s = Math.min(
          1e6,
          null !== (r = e.payloadSizeLimitBytes) && void 0 !== r ? r : 1e6,
        )),
        (t) => (
          null != t &&
            t.requestBody &&
            (t.requestBody = tr(t.requestBody, t.requestHeaders, s, "Request")),
          null != t &&
            t.responseBody &&
            (t.responseBody = tr(
              t.responseBody,
              t.responseHeaders,
              s,
              "Response",
            )),
          t
        )),
      u = (i) => {
        return h(
          ((t, i) => {
            var e,
              r = Ii(t.name),
              s =
                0 === i.indexOf("http")
                  ? null == (e = Ii(i))
                    ? void 0
                    : e.pathname
                  : i;
            "/" === s && (s = "");
            var n = null == r ? void 0 : r.pathname.replace(s || "", "");
            if (!(r && n && Ze.some((t) => 0 === n.indexOf(t)))) return t;
          })(
            ((r = (e = i).requestHeaders),
            M(r) ||
              K(Object.keys(null != r ? r : {}), (t) => {
                Xe.includes(t.toLowerCase()) && (r[t] = Ke);
              }),
            e),
            t.api_host,
          ),
        );
        var e, r;
      },
      d = k(t.session_recording.maskNetworkRequestFn);
    return (
      d &&
        k(t.session_recording.maskCapturedNetworkRequestFn) &&
        q.warn(
          "Both `maskNetworkRequestFn` and `maskCapturedNetworkRequestFn` are defined. `maskNetworkRequestFn` will be ignored.",
        ),
      d &&
        (t.session_recording.maskCapturedNetworkRequestFn = (i) => {
          var e = t.session_recording.maskNetworkRequestFn({ url: i.name });
          return f({}, i, { name: null == e ? void 0 : e.url });
        }),
      (n.maskRequestFn = k(t.session_recording.maskCapturedNetworkRequestFn)
        ? (i) => {
            var e,
              r = u(i);
            return r &&
              null !==
                (e =
                  null == t.session_recording.maskCapturedNetworkRequestFn
                    ? void 0
                    : t.session_recording.maskCapturedNetworkRequestFn(r)) &&
              void 0 !== e
              ? e
              : void 0;
          }
        : (t) =>
            (function (t) {
              if (!P(t))
                return (
                  (t.requestBody = ir(t.requestBody, "Request")),
                  (t.responseBody = ir(t.responseBody, "Response")),
                  t
                );
            })(u(t))),
      f({}, Ye, n, {
        recordHeaders: o,
        recordBody: a,
        recordPerformance: l,
        recordInitialRequests: l,
      })
    );
  };
  class rr {
    constructor(t, i) {
      var e, r;
      (void 0 === i && (i = {}),
        (this.St = {}),
        (this.$t = (t) => {
          if (!this.St[t]) {
            var i, e;
            this.St[t] = !0;
            var r = this.xt(t);
            null == (i = (e = this.i).onBlockedNode) || i.call(e, t, r);
          }
        }),
        (this.kt = (t) => {
          var i = this.xt(t);
          if (
            "svg" !== (null == i ? void 0 : i.nodeName) &&
            i instanceof Element
          ) {
            var e = i.closest("svg");
            if (e) return [this._rrweb.mirror.getId(e), e];
          }
          return [t, i];
        }),
        (this.xt = (t) => this._rrweb.mirror.getNode(t)),
        (this.Et = (t) => {
          var i, e, r, s, n, o, a, l;
          return (
            (null !== (i = null == (e = t.removes) ? void 0 : e.length) &&
            void 0 !== i
              ? i
              : 0) +
            (null !== (r = null == (s = t.attributes) ? void 0 : s.length) &&
            void 0 !== r
              ? r
              : 0) +
            (null !== (n = null == (o = t.texts) ? void 0 : o.length) &&
            void 0 !== n
              ? n
              : 0) +
            (null !== (a = null == (l = t.adds) ? void 0 : l.length) &&
            void 0 !== a
              ? a
              : 0)
          );
        }),
        (this.throttleMutations = (t) => {
          if (3 !== t.type || 0 !== t.data.source) return t;
          var i = t.data,
            e = this.Et(i);
          i.attributes &&
            (i.attributes = i.attributes.filter((t) => {
              var [i] = this.kt(t.id);
              return !this.gt.consumeRateLimit(i) && t;
            }));
          var r = this.Et(i);
          return 0 !== r || e === r ? t : void 0;
        }),
        (this._rrweb = t),
        (this.i = i),
        (this.gt = new U({
          bucketSize:
            null !== (e = this.i.bucketSize) && void 0 !== e ? e : 100,
          refillRate: null !== (r = this.i.refillRate) && void 0 !== r ? r : 10,
          refillInterval: 1e3,
          I: this.$t,
          P: q,
        })));
    }
  }
  var sr = Uint8Array,
    nr = Uint16Array,
    or = Uint32Array,
    ar = new sr([
      0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5,
      5, 5, 5, 0, 0, 0, 0,
    ]),
    lr = new sr([
      0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10,
      11, 11, 12, 12, 13, 13, 0, 0,
    ]),
    hr = new sr([
      16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15,
    ]),
    ur = function (t, i) {
      for (var e = new nr(31), r = 0; r < 31; ++r) e[r] = i += 1 << t[r - 1];
      var s = new or(e[30]);
      for (r = 1; r < 30; ++r)
        for (var n = e[r]; n < e[r + 1]; ++n) s[n] = ((n - e[r]) << 5) | r;
      return [e, s];
    },
    dr = ur(ar, 2),
    vr = dr[0],
    cr = dr[1];
  ((vr[28] = 258), (cr[258] = 28));
  for (var fr = ur(lr, 0)[1], pr = new nr(32768), gr = 0; gr < 32768; ++gr) {
    var _r = ((43690 & gr) >>> 1) | ((21845 & gr) << 1);
    ((_r =
      ((61680 & (_r = ((52428 & _r) >>> 2) | ((13107 & _r) << 2))) >>> 4) |
      ((3855 & _r) << 4)),
      (pr[gr] = (((65280 & _r) >>> 8) | ((255 & _r) << 8)) >>> 1));
  }
  var mr = function (t, i, e) {
      for (var r = t.length, s = 0, n = new nr(i); s < r; ++s) ++n[t[s] - 1];
      var o,
        a = new nr(i);
      for (s = 0; s < i; ++s) a[s] = (a[s - 1] + n[s - 1]) << 1;
      if (e) {
        o = new nr(1 << i);
        var l = 15 - i;
        for (s = 0; s < r; ++s)
          if (t[s])
            for (
              var h = (s << 4) | t[s],
                u = i - t[s],
                d = a[t[s] - 1]++ << u,
                v = d | ((1 << u) - 1);
              d <= v;
              ++d
            )
              o[pr[d] >>> l] = h;
      } else
        for (o = new nr(r), s = 0; s < r; ++s)
          o[s] = pr[a[t[s] - 1]++] >>> (15 - t[s]);
      return o;
    },
    br = new sr(288);
  for (gr = 0; gr < 144; ++gr) br[gr] = 8;
  for (gr = 144; gr < 256; ++gr) br[gr] = 9;
  for (gr = 256; gr < 280; ++gr) br[gr] = 7;
  for (gr = 280; gr < 288; ++gr) br[gr] = 8;
  var yr = new sr(32);
  for (gr = 0; gr < 32; ++gr) yr[gr] = 5;
  var wr = mr(br, 9, 0),
    Sr = mr(yr, 5, 0),
    $r = function (t) {
      return ((t / 8) >> 0) + (7 & t && 1);
    },
    xr = function (t, i, e) {
      (null == e || e > t.length) && (e = t.length);
      var r = new (t instanceof nr ? nr : t instanceof or ? or : sr)(e - i);
      return (r.set(t.subarray(i, e)), r);
    },
    kr = function (t, i, e) {
      e <<= 7 & i;
      var r = (i / 8) >> 0;
      ((t[r] |= e), (t[r + 1] |= e >>> 8));
    },
    Er = function (t, i, e) {
      e <<= 7 & i;
      var r = (i / 8) >> 0;
      ((t[r] |= e), (t[r + 1] |= e >>> 8), (t[r + 2] |= e >>> 16));
    },
    Ir = function (t, i) {
      for (var e = [], r = 0; r < t.length; ++r)
        t[r] && e.push({ s: r, f: t[r] });
      var s = e.length,
        n = e.slice();
      if (!s) return [new sr(0), 0];
      if (1 == s) {
        var o = new sr(e[0].s + 1);
        return ((o[e[0].s] = 1), [o, 1]);
      }
      (e.sort(function (t, i) {
        return t.f - i.f;
      }),
        e.push({ s: -1, f: 25001 }));
      var a = e[0],
        l = e[1],
        h = 0,
        u = 1,
        d = 2;
      for (e[0] = { s: -1, f: a.f + l.f, l: a, r: l }; u != s - 1; )
        ((a = e[e[h].f < e[d].f ? h++ : d++]),
          (l = e[h != u && e[h].f < e[d].f ? h++ : d++]),
          (e[u++] = { s: -1, f: a.f + l.f, l: a, r: l }));
      var v = n[0].s;
      for (r = 1; r < s; ++r) n[r].s > v && (v = n[r].s);
      var c = new nr(v + 1),
        f = Pr(e[u - 1], c, 0);
      if (f > i) {
        r = 0;
        var p = 0,
          g = f - i,
          _ = 1 << g;
        for (
          n.sort(function (t, i) {
            return c[i.s] - c[t.s] || t.f - i.f;
          });
          r < s;
          ++r
        ) {
          var m = n[r].s;
          if (!(c[m] > i)) break;
          ((p += _ - (1 << (f - c[m]))), (c[m] = i));
        }
        for (p >>>= g; p > 0; ) {
          var b = n[r].s;
          c[b] < i ? (p -= 1 << (i - c[b]++ - 1)) : ++r;
        }
        for (; r >= 0 && p; --r) {
          var y = n[r].s;
          c[y] == i && (--c[y], ++p);
        }
        f = i;
      }
      return [new sr(c), f];
    },
    Pr = function (t, i, e) {
      return -1 == t.s
        ? Math.max(Pr(t.l, i, e + 1), Pr(t.r, i, e + 1))
        : (i[t.s] = e);
    },
    Rr = function (t) {
      for (var i = t.length; i && !t[--i]; );
      for (
        var e = new nr(++i),
          r = 0,
          s = t[0],
          n = 1,
          o = function (t) {
            e[r++] = t;
          },
          a = 1;
        a <= i;
        ++a
      )
        if (t[a] == s && a != i) ++n;
        else {
          if (!s && n > 2) {
            for (; n > 138; n -= 138) o(32754);
            n > 2 &&
              (o(n > 10 ? ((n - 11) << 5) | 28690 : ((n - 3) << 5) | 12305),
              (n = 0));
          } else if (n > 3) {
            for (o(s), --n; n > 6; n -= 6) o(8304);
            n > 2 && (o(((n - 3) << 5) | 8208), (n = 0));
          }
          for (; n--; ) o(s);
          ((n = 1), (s = t[a]));
        }
      return [e.subarray(0, r), i];
    },
    Tr = function (t, i) {
      for (var e = 0, r = 0; r < i.length; ++r) e += t[r] * i[r];
      return e;
    },
    Cr = function (t, i, e) {
      var r = e.length,
        s = $r(i + 2);
      ((t[s] = 255 & r),
        (t[s + 1] = r >>> 8),
        (t[s + 2] = 255 ^ t[s]),
        (t[s + 3] = 255 ^ t[s + 1]));
      for (var n = 0; n < r; ++n) t[s + n + 4] = e[n];
      return 8 * (s + 4 + r);
    },
    Mr = function (t, i, e, r, s, n, o, a, l, h, u) {
      (kr(i, u++, e), ++s[256]);
      for (
        var d = Ir(s, 15),
          v = d[0],
          c = d[1],
          f = Ir(n, 15),
          p = f[0],
          g = f[1],
          _ = Rr(v),
          m = _[0],
          b = _[1],
          y = Rr(p),
          w = y[0],
          S = y[1],
          $ = new nr(19),
          x = 0;
        x < m.length;
        ++x
      )
        $[31 & m[x]]++;
      for (x = 0; x < w.length; ++x) $[31 & w[x]]++;
      for (
        var k = Ir($, 7), E = k[0], I = k[1], P = 19;
        P > 4 && !E[hr[P - 1]];
        --P
      );
      var R,
        T,
        C,
        M,
        F = (h + 5) << 3,
        O = Tr(s, br) + Tr(n, yr) + o,
        A =
          Tr(s, v) +
          Tr(n, p) +
          o +
          14 +
          3 * P +
          Tr($, E) +
          (2 * $[16] + 3 * $[17] + 7 * $[18]);
      if (F <= O && F <= A) return Cr(i, u, t.subarray(l, l + h));
      if ((kr(i, u, 1 + (A < O)), (u += 2), A < O)) {
        ((R = mr(v, c, 0)), (T = v), (C = mr(p, g, 0)), (M = p));
        var D = mr(E, I, 0);
        (kr(i, u, b - 257),
          kr(i, u + 5, S - 1),
          kr(i, u + 10, P - 4),
          (u += 14));
        for (x = 0; x < P; ++x) kr(i, u + 3 * x, E[hr[x]]);
        u += 3 * P;
        for (var j = [m, w], L = 0; L < 2; ++L) {
          var N = j[L];
          for (x = 0; x < N.length; ++x) {
            var z = 31 & N[x];
            (kr(i, u, D[z]),
              (u += E[z]),
              z > 15 && (kr(i, u, (N[x] >>> 5) & 127), (u += N[x] >>> 12)));
          }
        }
      } else ((R = wr), (T = br), (C = Sr), (M = yr));
      for (x = 0; x < a; ++x)
        if (r[x] > 255) {
          z = (r[x] >>> 18) & 31;
          (Er(i, u, R[z + 257]),
            (u += T[z + 257]),
            z > 7 && (kr(i, u, (r[x] >>> 23) & 31), (u += ar[z])));
          var U = 31 & r[x];
          (Er(i, u, C[U]),
            (u += M[U]),
            U > 3 && (Er(i, u, (r[x] >>> 5) & 8191), (u += lr[U])));
        } else (Er(i, u, R[r[x]]), (u += T[r[x]]));
      return (Er(i, u, R[256]), u + T[256]);
    },
    Fr = new or([
      65540, 131080, 131088, 131104, 262176, 1048704, 1048832, 2114560, 2117632,
    ]),
    Or = (function () {
      for (var t = new or(256), i = 0; i < 256; ++i) {
        for (var e = i, r = 9; --r; ) e = (1 & e && 3988292384) ^ (e >>> 1);
        t[i] = e;
      }
      return t;
    })(),
    Ar = function () {
      var t = 4294967295;
      return {
        p: function (i) {
          for (var e = t, r = 0; r < i.length; ++r)
            e = Or[(255 & e) ^ i[r]] ^ (e >>> 8);
          t = e;
        },
        d: function () {
          return 4294967295 ^ t;
        },
      };
    },
    Dr = function (t, i, e, r, s) {
      return (function (t, i, e, r, s, n) {
        var o = t.length,
          a = new sr(r + o + 5 * (1 + Math.floor(o / 7e3)) + s),
          l = a.subarray(r, a.length - s),
          h = 0;
        if (!i || o < 8)
          for (var u = 0; u <= o; u += 65535) {
            var d = u + 65535;
            d < o
              ? (h = Cr(l, h, t.subarray(u, d)))
              : ((l[u] = n), (h = Cr(l, h, t.subarray(u, o))));
          }
        else {
          for (
            var v = Fr[i - 1],
              c = v >>> 13,
              f = 8191 & v,
              p = (1 << e) - 1,
              g = new nr(32768),
              _ = new nr(p + 1),
              m = Math.ceil(e / 3),
              b = 2 * m,
              y = function (i) {
                return (t[i] ^ (t[i + 1] << m) ^ (t[i + 2] << b)) & p;
              },
              w = new or(25e3),
              S = new nr(288),
              $ = new nr(32),
              x = 0,
              k = 0,
              E = ((u = 0), 0),
              I = 0,
              P = 0;
            u < o;
            ++u
          ) {
            var R = y(u),
              T = 32767 & u,
              C = _[R];
            if (((g[T] = C), (_[R] = T), I <= u)) {
              var M = o - u;
              if ((x > 7e3 || E > 24576) && M > 423) {
                ((h = Mr(t, l, 0, w, S, $, k, E, P, u - P, h)),
                  (E = x = k = 0),
                  (P = u));
                for (var F = 0; F < 286; ++F) S[F] = 0;
                for (F = 0; F < 30; ++F) $[F] = 0;
              }
              var O = 2,
                A = 0,
                D = f,
                j = (T - C) & 32767;
              if (M > 2 && R == y(u - j))
                for (
                  var L = Math.min(c, M) - 1,
                    N = Math.min(32767, u),
                    z = Math.min(258, M);
                  j <= N && --D && T != C;

                ) {
                  if (t[u + O] == t[u + O - j]) {
                    for (var U = 0; U < z && t[u + U] == t[u + U - j]; ++U);
                    if (U > O) {
                      if (((O = U), (A = j), U > L)) break;
                      var B = Math.min(j, U - 2),
                        q = 0;
                      for (F = 0; F < B; ++F) {
                        var H = (u - j + F + 32768) & 32767,
                          W = (H - g[H] + 32768) & 32767;
                        W > q && ((q = W), (C = H));
                      }
                    }
                  }
                  j += ((T = C) - (C = g[T]) + 32768) & 32767;
                }
              if (A) {
                w[E++] = 268435456 | (cr[O] << 18) | fr[A];
                var G = 31 & cr[O],
                  J = 31 & fr[A];
                ((k += ar[G] + lr[J]), ++S[257 + G], ++$[J], (I = u + O), ++x);
              } else ((w[E++] = t[u]), ++S[t[u]]);
            }
          }
          h = Mr(t, l, n, w, S, $, k, E, P, u - P, h);
        }
        return xr(a, 0, r + $r(h) + s);
      })(
        t,
        null == i.level ? 6 : i.level,
        null == i.mem
          ? Math.ceil(1.5 * Math.max(8, Math.min(13, Math.log(t.length))))
          : 12 + i.mem,
        e,
        r,
        !s,
      );
    },
    jr = function (t, i, e) {
      for (; e; ++i) ((t[i] = e), (e >>>= 8));
    },
    Lr = function (t, i) {
      var e = i.filename;
      if (
        ((t[0] = 31),
        (t[1] = 139),
        (t[2] = 8),
        (t[8] = i.level < 2 ? 4 : 9 == i.level ? 2 : 0),
        (t[9] = 3),
        0 != i.mtime &&
          jr(t, 4, Math.floor(new Date(i.mtime || Date.now()) / 1e3)),
        e)
      ) {
        t[3] = 8;
        for (var r = 0; r <= e.length; ++r) t[r + 10] = e.charCodeAt(r);
      }
    },
    Nr = function (t) {
      return 10 + ((t.filename && t.filename.length + 1) || 0);
    };
  function zr(t, i) {
    void 0 === i && (i = {});
    var e = Ar(),
      r = t.length;
    e.p(t);
    var s = Dr(t, i, Nr(i), 8),
      n = s.length;
    return (Lr(s, i), jr(s, n - 8, e.d()), jr(s, n - 4, r), s);
  }
  function Ur(t, i) {
    var e = t.length;
    if ("undefined" != typeof TextEncoder) return new TextEncoder().encode(t);
    for (
      var r = new sr(t.length + (t.length >>> 1)),
        s = 0,
        n = function (t) {
          r[s++] = t;
        },
        o = 0;
      o < e;
      ++o
    ) {
      if (s + 5 > r.length) {
        var a = new sr(s + 8 + ((e - o) << 1));
        (a.set(r), (r = a));
      }
      var l = t.charCodeAt(o);
      l < 128 || i
        ? n(l)
        : l < 2048
          ? (n(192 | (l >>> 6)), n(128 | (63 & l)))
          : l > 55295 && l < 57344
            ? (n(
                240 |
                  ((l =
                    (65536 + (1047552 & l)) | (1023 & t.charCodeAt(++o))) >>>
                    18),
              ),
              n(128 | ((l >>> 12) & 63)),
              n(128 | ((l >>> 6) & 63)),
              n(128 | (63 & l)))
            : (n(224 | (l >>> 12)),
              n(128 | ((l >>> 6) & 63)),
              n(128 | (63 & l)));
    }
    return xr(r, 0, s);
  }
  function Br(t, i) {
    return (
      (function (t) {
        for (var i = 0, e = 0; e < t.length; e++)
          ((i = (i << 5) - i + t.charCodeAt(e)), (i |= 0));
        return Math.abs(i);
      })(t) %
        100 <
      z(100 * i, 0, 100, q)
    );
  }
  var qr = "disabled",
    Hr = "sampled",
    Wr = "active",
    Gr = "buffering",
    Jr = "paused",
    Vr = "trigger",
    Kr = Vr + "_activated",
    Yr = Vr + "_pending",
    Xr = Vr + "_" + qr;
  function Qr(t, i) {
    return i.some((i) => "regex" === i.matching && new RegExp(i.url).test(t));
  }
  class Zr {
    constructor(t) {
      this.It = t;
    }
    triggerStatus(t) {
      var i = this.It.map((i) => i.triggerStatus(t));
      return i.includes(Kr) ? Kr : i.includes(Yr) ? Yr : Xr;
    }
    stop() {
      this.It.forEach((t) => t.stop());
    }
  }
  class ts {
    constructor(t) {
      this.It = t;
    }
    triggerStatus(t) {
      var i = new Set();
      for (var e of this.It) i.add(e.triggerStatus(t));
      switch ((i.delete(Xr), i.size)) {
        case 0:
          return Xr;
        case 1:
          return Array.from(i)[0];
        default:
          return Yr;
      }
    }
    stop() {
      this.It.forEach((t) => t.stop());
    }
  }
  class is {
    triggerStatus() {
      return Yr;
    }
    stop() {}
  }
  class es {
    constructor(t) {
      ((this.Pt = []),
        (this.Rt = []),
        (this.urlBlocked = !1),
        (this._instance = t));
    }
    onRemoteConfig(t) {
      var i, e;
      ((this.Pt =
        (null == (i = t.sessionRecording) ? void 0 : i.urlTriggers) || []),
        (this.Rt =
          (null == (e = t.sessionRecording) ? void 0 : e.urlBlocklist) || []));
    }
    Tt(t) {
      var i;
      return 0 === this.Pt.length
        ? Xr
        : (null == (i = this._instance) ? void 0 : i.get_property(Pt)) === t
          ? Kr
          : Yr;
    }
    triggerStatus(t) {
      var i = this.Tt(t),
        e = i === Kr ? Kr : i === Yr ? Yr : Xr;
      return (
        this._instance.register_for_session({
          $sdk_debug_replay_url_trigger_status: e,
        }),
        e
      );
    }
    checkUrlTriggerConditions(i, e, r) {
      if (void 0 !== t && t.location.href) {
        var s = t.location.href,
          n = this.urlBlocked,
          o = Qr(s, this.Rt);
        (n && o) ||
          (o && !n ? i() : !o && n && e(), Qr(s, this.Pt) && r("url"));
      }
    }
    stop() {}
  }
  class rs {
    constructor(t) {
      ((this.linkedFlag = null),
        (this.linkedFlagSeen = !1),
        (this.Ct = () => {}),
        (this._instance = t));
    }
    triggerStatus() {
      var t = Yr;
      return (
        M(this.linkedFlag) && (t = Xr),
        this.linkedFlagSeen && (t = Kr),
        this._instance.register_for_session({
          $sdk_debug_replay_linked_flag_trigger_status: t,
        }),
        t
      );
    }
    onRemoteConfig(t, i) {
      var e;
      if (
        ((this.linkedFlag =
          (null == (e = t.sessionRecording) ? void 0 : e.linkedFlag) || null),
        !M(this.linkedFlag) && !this.linkedFlagSeen)
      ) {
        var r = R(this.linkedFlag) ? this.linkedFlag : this.linkedFlag.flag,
          s = R(this.linkedFlag) ? null : this.linkedFlag.variant;
        this.Ct = this._instance.onFeatureFlags((t, e) => {
          var n = !1;
          if (E(e) && r in e) {
            var o = e[r];
            n = O(o) ? !0 === o : s ? o === s : !!o;
          }
          ((this.linkedFlagSeen = n), n && i(r, s));
        });
      }
    }
    stop() {
      this.Ct();
    }
  }
  class ss {
    constructor(t) {
      ((this.Mt = []), (this._instance = t));
    }
    onRemoteConfig(t) {
      var i;
      this.Mt =
        (null == (i = t.sessionRecording) ? void 0 : i.eventTriggers) || [];
    }
    Ft(t) {
      var i;
      return 0 === this.Mt.length
        ? Xr
        : (null == (i = this._instance) ? void 0 : i.get_property(Rt)) === t
          ? Kr
          : Yr;
    }
    triggerStatus(t) {
      var i = this.Ft(t),
        e = i === Kr ? Kr : i === Yr ? Yr : Xr;
      return (
        this._instance.register_for_session({
          $sdk_debug_replay_event_trigger_status: e,
        }),
        e
      );
    }
    stop() {}
  }
  function ns(t) {
    return t.isRecordingEnabled ? Gr : qr;
  }
  function os(t) {
    if (!t.receivedFlags) return Gr;
    if (!t.isRecordingEnabled) return qr;
    if (t.urlTriggerMatching.urlBlocked) return Jr;
    var i = !0 === t.isSampled,
      e = new Zr([
        t.eventTriggerMatching,
        t.urlTriggerMatching,
        t.linkedFlagMatching,
      ]).triggerStatus(t.sessionId);
    return i
      ? Hr
      : e === Kr
        ? Wr
        : e === Yr
          ? Gr
          : !1 === t.isSampled
            ? qr
            : Wr;
  }
  function as(t) {
    if (!t.receivedFlags) return Gr;
    if (!t.isRecordingEnabled) return qr;
    if (t.urlTriggerMatching.urlBlocked) return Jr;
    var i = new ts([
        t.eventTriggerMatching,
        t.urlTriggerMatching,
        t.linkedFlagMatching,
      ]).triggerStatus(t.sessionId),
      e = i !== Xr,
      r = O(t.isSampled);
    return e && i === Yr
      ? Gr
      : (e && i === Xr) || (r && !t.isSampled)
        ? qr
        : !0 === t.isSampled
          ? Hr
          : Wr;
  }
  var ls = "[SessionRecording]",
    hs = H(ls);
  function us() {
    var t;
    return null == v ||
      null == (t = v.__PosthogExtensions__) ||
      null == (t = t.rrweb)
      ? void 0
      : t.record;
  }
  var ds = 3e5,
    vs = [
      Je.MouseMove,
      Je.MouseInteraction,
      Je.Scroll,
      Je.ViewportResize,
      Je.Input,
      Je.TouchMove,
      Je.MediaInteraction,
      Je.Drag,
    ],
    cs = (t) => ({ rrwebMethod: t, enqueuedAt: Date.now(), attempt: 1 });
  function fs(t) {
    return (function (t, i) {
      for (var e = "", r = 0; r < t.length; ) {
        var s = t[r++];
        s < 128 || i
          ? (e += String.fromCharCode(s))
          : s < 224
            ? (e += String.fromCharCode(((31 & s) << 6) | (63 & t[r++])))
            : s < 240
              ? (e += String.fromCharCode(
                  ((15 & s) << 12) | ((63 & t[r++]) << 6) | (63 & t[r++]),
                ))
              : ((s =
                  (((15 & s) << 18) |
                    ((63 & t[r++]) << 12) |
                    ((63 & t[r++]) << 6) |
                    (63 & t[r++])) -
                  65536),
                (e += String.fromCharCode(
                  55296 | (s >> 10),
                  56320 | (1023 & s),
                )));
      }
      return e;
    })(zr(Ur(JSON.stringify(t))), !0);
  }
  function ps(t) {
    return t.type === Ge.Custom && "sessionIdle" === t.data.tag;
  }
  class gs {
    get sessionId() {
      return this.Ot;
    }
    get At() {
      return (
        this._instance.config.session_recording.session_idle_threshold_ms || 3e5
      );
    }
    get started() {
      return this.Dt;
    }
    get jt() {
      if (!this._instance.sessionManager)
        throw new Error(ls + " must be started with a valid sessionManager.");
      return this._instance.sessionManager;
    }
    get Lt() {
      var t, i;
      return this.Nt.triggerStatus(this.sessionId) === Yr
        ? 6e4
        : null !==
              (t =
                null == (i = this._instance.config.session_recording)
                  ? void 0
                  : i.full_snapshot_interval_millis) && void 0 !== t
          ? t
          : ds;
    }
    get zt() {
      var t = this._instance.get_property(It);
      return O(t) ? t : null;
    }
    get Ut() {
      var t,
        i,
        e =
          null == (t = this.H)
            ? void 0
            : t.data[(null == (i = this.H) ? void 0 : i.data.length) - 1],
        { sessionStartTimestamp: r } =
          this.jt.checkAndGetSessionAndWindowId(!0);
      return e ? e.timestamp - r : null;
    }
    get Bt() {
      var i = !!this._instance.get_property(mt),
        e = !this._instance.config.disable_session_recording;
      return t && i && e;
    }
    get qt() {
      var t = !!this._instance.get_property(bt),
        i = this._instance.config.enable_recording_console_log;
      return null != i ? i : t;
    }
    get Ht() {
      var t,
        i,
        e,
        r,
        s,
        n,
        o = this._instance.config.session_recording.captureCanvas,
        a = this._instance.get_property(St),
        l =
          null !==
            (t =
              null !== (i = null == o ? void 0 : o.recordCanvas) && void 0 !== i
                ? i
                : null == a
                  ? void 0
                  : a.enabled) &&
          void 0 !== t &&
          t,
        h =
          null !==
            (e =
              null !== (r = null == o ? void 0 : o.canvasFps) && void 0 !== r
                ? r
                : null == a
                  ? void 0
                  : a.fps) && void 0 !== e
            ? e
            : 4,
        u =
          null !==
            (s =
              null !== (n = null == o ? void 0 : o.canvasQuality) &&
              void 0 !== n
                ? n
                : null == a
                  ? void 0
                  : a.quality) && void 0 !== s
            ? s
            : 0.4;
      if ("string" == typeof u) {
        var d = parseFloat(u);
        u = isNaN(d) ? 0.4 : d;
      }
      return {
        enabled: l,
        fps: z(h, 0, 12, hs.createLogger("canvas recording fps"), 4),
        quality: z(u, 0, 1, hs.createLogger("canvas recording quality"), 0.4),
      };
    }
    get Wt() {
      var t,
        i,
        e = this._instance.get_property(yt),
        r = {
          recordHeaders:
            null == (t = this._instance.config.session_recording)
              ? void 0
              : t.recordHeaders,
          recordBody:
            null == (i = this._instance.config.session_recording)
              ? void 0
              : i.recordBody,
        },
        s =
          (null == r ? void 0 : r.recordHeaders) ||
          (null == e ? void 0 : e.recordHeaders),
        n =
          (null == r ? void 0 : r.recordBody) ||
          (null == e ? void 0 : e.recordBody),
        o = E(this._instance.config.capture_performance)
          ? this._instance.config.capture_performance.network_timing
          : this._instance.config.capture_performance,
        a = !!(O(o) ? o : null == e ? void 0 : e.capturePerformance);
      return s || n || a
        ? { recordHeaders: s, recordBody: n, recordPerformance: a }
        : void 0;
    }
    get Gt() {
      var t,
        i,
        e,
        r,
        s,
        n,
        o = this._instance.get_property(wt),
        a = {
          maskAllInputs:
            null == (t = this._instance.config.session_recording)
              ? void 0
              : t.maskAllInputs,
          maskTextSelector:
            null == (i = this._instance.config.session_recording)
              ? void 0
              : i.maskTextSelector,
          blockSelector:
            null == (e = this._instance.config.session_recording)
              ? void 0
              : e.blockSelector,
        },
        l =
          null !== (r = null == a ? void 0 : a.maskAllInputs) && void 0 !== r
            ? r
            : null == o
              ? void 0
              : o.maskAllInputs,
        h =
          null !== (s = null == a ? void 0 : a.maskTextSelector) && void 0 !== s
            ? s
            : null == o
              ? void 0
              : o.maskTextSelector,
        u =
          null !== (n = null == a ? void 0 : a.blockSelector) && void 0 !== n
            ? n
            : null == o
              ? void 0
              : o.blockSelector;
      return P(l) && P(h) && P(u)
        ? void 0
        : {
            maskAllInputs: null == l || l,
            maskTextSelector: h,
            blockSelector: u,
          };
    }
    get Jt() {
      var t = this._instance.get_property($t);
      return F(t) ? t : null;
    }
    get Vt() {
      var t = this._instance.get_property(xt);
      return F(t) ? t : null;
    }
    get status() {
      return this.Kt
        ? this.Yt({
            receivedFlags: this.Kt,
            isRecordingEnabled: this.Bt,
            isSampled: this.zt,
            urlTriggerMatching: this.Xt,
            eventTriggerMatching: this.Qt,
            linkedFlagMatching: this.Zt,
            sessionId: this.sessionId,
          })
        : Gr;
    }
    constructor(t) {
      if (
        ((this.Yt = ns),
        (this.Kt = !1),
        (this.ti = []),
        (this.ii = "unknown"),
        (this.ei = Date.now()),
        (this.Nt = new is()),
        (this.ri = void 0),
        (this.si = void 0),
        (this.ni = void 0),
        (this.oi = void 0),
        (this.ai = void 0),
        (this._forceAllowLocalhostNetworkCapture = !1),
        (this.li = () => {
          this.hi();
        }),
        (this.ui = () => {
          this.di("browser offline", {});
        }),
        (this.vi = () => {
          this.di("browser online", {});
        }),
        (this.ci = () => {
          if (null != o && o.visibilityState) {
            var t = "window " + o.visibilityState;
            this.di(t, {});
          }
        }),
        (this._instance = t),
        (this.Dt = !1),
        (this.fi = "/s/"),
        (this.pi = void 0),
        (this.Kt = !1),
        !this._instance.sessionManager)
      )
        throw (
          hs.error("started without valid sessionManager"),
          new Error(
            ls + " started without valid sessionManager. This is a bug.",
          )
        );
      if ("always" === this._instance.config.cookieless_mode)
        throw new Error(ls + ' cannot be used with cookieless_mode="always"');
      ((this.Zt = new rs(this._instance)),
        (this.Xt = new es(this._instance)),
        (this.Qt = new ss(this._instance)));
      var { sessionId: i, windowId: e } =
        this.jt.checkAndGetSessionAndWindowId();
      ((this.Ot = i),
        (this.gi = e),
        (this.H = this.mi()),
        this.At >= this.jt.sessionTimeoutMs &&
          hs.warn(
            "session_idle_threshold_ms (" +
              this.At +
              ") is greater than the session timeout (" +
              this.jt.sessionTimeoutMs +
              "). Session will never be detected as idle",
          ));
    }
    startIfEnabledOrStop(i) {
      this.Bt
        ? (this.bi(i),
          ot(t, "beforeunload", this.li),
          ot(t, "offline", this.ui),
          ot(t, "online", this.vi),
          ot(t, "visibilitychange", this.ci),
          this.yi(),
          this.wi(),
          M(this.ri) &&
            (this.ri = this._instance.on("eventCaptured", (t) => {
              try {
                if ("$pageview" === t.event) {
                  var i =
                    null != t && t.properties.$current_url
                      ? this.Si(null == t ? void 0 : t.properties.$current_url)
                      : "";
                  if (!i) return;
                  this.di("$pageview", { href: i });
                }
              } catch (t) {
                hs.error("Could not add $pageview to rrweb session", t);
              }
            })),
          this.si ||
            (this.si = this.jt.onSessionId((t, i, e) => {
              var r, s;
              e &&
                (this.di("$session_id_change", {
                  sessionId: t,
                  windowId: i,
                  changeReason: e,
                }),
                null == (r = this._instance) ||
                  null == (r = r.persistence) ||
                  r.unregister(Rt),
                null == (s = this._instance) ||
                  null == (s = s.persistence) ||
                  s.unregister(Pt));
            })))
        : this.stopRecording();
    }
    stopRecording() {
      var i, e, r, s;
      this.Dt &&
        this.pi &&
        (this.pi(),
        (this.pi = void 0),
        (this.Dt = !1),
        null == t || t.removeEventListener("beforeunload", this.li),
        null == t || t.removeEventListener("offline", this.ui),
        null == t || t.removeEventListener("online", this.vi),
        null == t || t.removeEventListener("visibilitychange", this.ci),
        this.mi(),
        clearInterval(this.$i),
        null == (i = this.ri) || i.call(this),
        (this.ri = void 0),
        null == (e = this.ai) || e.call(this),
        (this.ai = void 0),
        null == (r = this.si) || r.call(this),
        (this.si = void 0),
        null == (s = this.oi) || s.call(this),
        (this.oi = void 0),
        this.Qt.stop(),
        this.Xt.stop(),
        this.Zt.stop(),
        hs.info("stopped"));
    }
    xi() {
      var t;
      null == (t = this._instance.persistence) || t.unregister(It);
    }
    ki(t) {
      var i,
        e = this.Ot !== t,
        r = this.Jt;
      if (F(r)) {
        var s = this.zt,
          n = e || !O(s),
          o = n ? Br(t, r) : s;
        (n &&
          (o
            ? this.Ei(Hr)
            : hs.warn(
                "Sample rate (" +
                  r +
                  ") has determined that this sessionId (" +
                  t +
                  ") will not be sent to the server.",
              ),
          this.di("samplingDecisionMade", { sampleRate: r, isSampled: o })),
          null == (i = this._instance.persistence) || i.register({ [It]: o }));
      } else this.xi();
    }
    onRemoteConfig(t) {
      var i, e, r, s;
      (this.di("$remote_config_received", t),
      this.Ii(t),
      null != (i = t.sessionRecording) && i.endpoint) &&
        (this.fi = null == (s = t.sessionRecording) ? void 0 : s.endpoint);
      (this.yi(),
        "any" ===
        (null == (e = t.sessionRecording) ? void 0 : e.triggerMatchType)
          ? ((this.Yt = os), (this.Nt = new Zr([this.Qt, this.Xt])))
          : ((this.Yt = as), (this.Nt = new ts([this.Qt, this.Xt]))),
        this._instance.register_for_session({
          $sdk_debug_replay_remote_trigger_matching_config:
            null == (r = t.sessionRecording) ? void 0 : r.triggerMatchType,
        }),
        this.Xt.onRemoteConfig(t),
        this.Qt.onRemoteConfig(t),
        this.Zt.onRemoteConfig(t, (t, i) => {
          this.Ei("linked_flag_matched", { flag: t, variant: i });
        }),
        (this.Kt = !0),
        this.startIfEnabledOrStop());
    }
    yi() {
      F(this.Jt) &&
        M(this.oi) &&
        (this.oi = this.jt.onSessionId((t) => {
          this.ki(t);
        }));
    }
    Ii(t) {
      if (this._instance.persistence) {
        var i,
          e = this._instance.persistence,
          r = () => {
            var i,
              r,
              s,
              n,
              o,
              a,
              l,
              h,
              u,
              d = null == (i = t.sessionRecording) ? void 0 : i.sampleRate,
              v = M(d) ? null : parseFloat(d);
            M(v) && this.xi();
            var c =
              null == (r = t.sessionRecording)
                ? void 0
                : r.minimumDurationMilliseconds;
            e.register({
              [mt]: !!t.sessionRecording,
              [bt]:
                null == (s = t.sessionRecording)
                  ? void 0
                  : s.consoleLogRecordingEnabled,
              [yt]: f(
                { capturePerformance: t.capturePerformance },
                null == (n = t.sessionRecording)
                  ? void 0
                  : n.networkPayloadCapture,
              ),
              [wt]: null == (o = t.sessionRecording) ? void 0 : o.masking,
              [St]: {
                enabled:
                  null == (a = t.sessionRecording) ? void 0 : a.recordCanvas,
                fps: null == (l = t.sessionRecording) ? void 0 : l.canvasFps,
                quality:
                  null == (h = t.sessionRecording) ? void 0 : h.canvasQuality,
              },
              [$t]: v,
              [xt]: P(c) ? null : c,
              [kt]: null == (u = t.sessionRecording) ? void 0 : u.scriptConfig,
            });
          };
        (r(),
          null == (i = this.ni) || i.call(this),
          (this.ni = this.jt.onSessionId(r)));
      }
    }
    log(t, i) {
      var e;
      (void 0 === i && (i = "log"),
        null == (e = this._instance.sessionRecording) ||
          e.onRRwebEmit({
            type: 6,
            data: {
              plugin: "rrweb/console@1",
              payload: { level: i, trace: [], payload: [JSON.stringify(t)] },
            },
            timestamp: Date.now(),
          }));
    }
    bi(t) {
      if (
        !P(Object.assign) &&
        !P(Array.from) &&
        !(
          this.Dt ||
          this._instance.config.disable_session_recording ||
          this._instance.consent.isOptedOut()
        )
      ) {
        var i;
        if (((this.Dt = !0), this.jt.checkAndGetSessionAndWindowId(), us()))
          this.Pi();
        else
          null == (i = v.__PosthogExtensions__) ||
            null == i.loadExternalDependency ||
            i.loadExternalDependency(this._instance, this.Ri, (t) => {
              if (t) return hs.error("could not load recorder", t);
              this.Pi();
            });
        (hs.info("starting"),
          this.status === Wr && this.Ei(t || "recording_initialized"));
      }
    }
    get Ri() {
      var t;
      return (
        (null == (t = this._instance) ||
        null == (t = t.persistence) ||
        null == (t = t.get_property(kt))
          ? void 0
          : t.script) || "recorder"
      );
    }
    Ti(t) {
      var i;
      return (
        3 === t.type &&
        -1 !== vs.indexOf(null == (i = t.data) ? void 0 : i.source)
      );
    }
    Ci(t) {
      var i = this.Ti(t);
      i ||
        this.ii ||
        (t.timestamp - this.ei > this.At &&
          ((this.ii = !0),
          clearInterval(this.$i),
          this.di("sessionIdle", {
            eventTimestamp: t.timestamp,
            lastActivityTimestamp: this.ei,
            threshold: this.At,
            bufferLength: this.H.data.length,
            bufferSize: this.H.size,
          }),
          this.hi()));
      var e = !1;
      if (i && ((this.ei = t.timestamp), this.ii)) {
        var r = "unknown" === this.ii;
        ((this.ii = !1),
          r ||
            (this.di("sessionNoLongerIdle", {
              reason: "user activity",
              type: t.type,
            }),
            (e = !0)));
      }
      if (!this.ii) {
        var { windowId: s, sessionId: n } =
            this.jt.checkAndGetSessionAndWindowId(!i, t.timestamp),
          o = this.Ot !== n,
          a = this.gi !== s;
        ((this.gi = s),
          (this.Ot = n),
          o || a
            ? (this.stopRecording(),
              this.startIfEnabledOrStop("session_id_changed"))
            : e && this.Mi());
      }
    }
    Fi(t) {
      try {
        return (t.rrwebMethod(), !0);
      } catch (i) {
        return (
          this.ti.length < 10
            ? this.ti.push({
                enqueuedAt: t.enqueuedAt || Date.now(),
                attempt: t.attempt++,
                rrwebMethod: t.rrwebMethod,
              })
            : hs.warn("could not emit queued rrweb event.", i, t),
          !1
        );
      }
    }
    di(t, i) {
      return this.Fi(cs(() => us().addCustomEvent(t, i)));
    }
    Oi() {
      return this.Fi(cs(() => us().takeFullSnapshot()));
    }
    Pi() {
      var t,
        i,
        e,
        r,
        s = {
          blockClass: "ph-no-capture",
          blockSelector: void 0,
          ignoreClass: "ph-ignore-input",
          maskTextClass: "ph-mask",
          maskTextSelector: void 0,
          maskTextFn: void 0,
          maskAllInputs: !0,
          maskInputOptions: { password: !0 },
          maskInputFn: void 0,
          slimDOMOptions: {},
          collectFonts: !1,
          inlineStylesheet: !0,
          recordCrossOriginIframes: !1,
        },
        n = this._instance.config.session_recording;
      for (var [o, a] of Object.entries(n || {}))
        o in s &&
          ("maskInputOptions" === o
            ? (s.maskInputOptions = f({ password: !0 }, a))
            : (s[o] = a));
      (this.Ht &&
        this.Ht.enabled &&
        ((s.recordCanvas = !0),
        (s.sampling = { canvas: this.Ht.fps }),
        (s.dataURLOptions = { type: "image/webp", quality: this.Ht.quality })),
      this.Gt) &&
        ((s.maskAllInputs =
          null === (i = this.Gt.maskAllInputs) || void 0 === i || i),
        (s.maskTextSelector =
          null !== (e = this.Gt.maskTextSelector) && void 0 !== e ? e : void 0),
        (s.blockSelector =
          null !== (r = this.Gt.blockSelector) && void 0 !== r ? r : void 0));
      var l = us();
      if (l) {
        this.Ai =
          null !== (t = this.Ai) && void 0 !== t
            ? t
            : new rr(l, {
                refillRate:
                  this._instance.config.session_recording
                    .__mutationThrottlerRefillRate,
                bucketSize:
                  this._instance.config.session_recording
                    .__mutationThrottlerBucketSize,
                onBlockedNode: (t, i) => {
                  var e =
                    "Too many mutations on node '" +
                    t +
                    "'. Rate limiting. This could be due to SVG animations or something similar";
                  (hs.info(e, { node: i }), this.log(ls + " " + e, "warn"));
                },
              });
        var h = this.Di();
        ((this.pi = l(
          f(
            {
              emit: (t) => {
                this.onRRwebEmit(t);
              },
              plugins: h,
            },
            s,
          ),
        )),
          (this.ei = Date.now()),
          (this.ii = O(this.ii) ? this.ii : "unknown"),
          this.di("$session_options", {
            sessionRecordingOptions: s,
            activePlugins: h.map((t) => (null == t ? void 0 : t.name)),
          }),
          this.di("$posthog_config", { config: this._instance.config }));
      } else
        hs.error(
          "onScriptLoaded was called but rrwebRecord is not available. This indicates something has gone wrong.",
        );
    }
    Mi() {
      if ((this.$i && clearInterval(this.$i), !0 !== this.ii)) {
        var t = this.Lt;
        t &&
          (this.$i = setInterval(() => {
            this.Oi();
          }, t));
      }
    }
    Di() {
      var t,
        i,
        e = [],
        r =
          null == (t = v.__PosthogExtensions__) || null == (t = t.rrwebPlugins)
            ? void 0
            : t.getRecordConsolePlugin;
      r && this.qt && e.push(r());
      var s =
        null == (i = v.__PosthogExtensions__) || null == (i = i.rrwebPlugins)
          ? void 0
          : i.getRecordNetworkPlugin;
      this.Wt &&
        k(s) &&
        (!Ei.includes(location.hostname) ||
        this._forceAllowLocalhostNetworkCapture
          ? e.push(s(er(this._instance.config, this.Wt)))
          : hs.info("NetworkCapture not started because we are on localhost."));
      return e;
    }
    onRRwebEmit(t) {
      var i;
      if ((this.ji(), t && E(t))) {
        if (t.type === Ge.Meta) {
          var e = this.Si(t.data.href);
          if (((this.Li = e), !e)) return;
          t.data.href = e;
        } else this.Ni();
        if (
          (this.Xt.checkUrlTriggerConditions(
            () => this.zi(),
            () => this.Ui(),
            (t) => this.Bi(t),
          ),
          !this.Xt.urlBlocked ||
            ((r = t).type === Ge.Custom && "recording paused" === r.data.tag))
        ) {
          var r;
          (t.type === Ge.FullSnapshot && this.Mi(),
            t.type === Ge.FullSnapshot &&
              this.Kt &&
              this.Nt.triggerStatus(this.sessionId) === Yr &&
              this.mi());
          var s = this.Ai ? this.Ai.throttleMutations(t) : t;
          if (s) {
            var n = (function (t) {
              var i = t;
              if (
                i &&
                E(i) &&
                6 === i.type &&
                E(i.data) &&
                "rrweb/console@1" === i.data.plugin
              ) {
                i.data.payload.payload.length > 10 &&
                  ((i.data.payload.payload = i.data.payload.payload.slice(
                    0,
                    10,
                  )),
                  i.data.payload.payload.push("...[truncated]"));
                for (var e = [], r = 0; r < i.data.payload.payload.length; r++)
                  i.data.payload.payload[r] &&
                  i.data.payload.payload[r].length > 2e3
                    ? e.push(
                        i.data.payload.payload[r].slice(0, 2e3) +
                          "...[truncated]",
                      )
                    : e.push(i.data.payload.payload[r]);
                return ((i.data.payload.payload = e), t);
              }
              return t;
            })(s);
            if ((this.Ci(n), !0 !== this.ii || ps(n))) {
              if (ps(n)) {
                var o = n.data.payload;
                if (o) {
                  var a = o.lastActivityTimestamp,
                    l = o.threshold;
                  n.timestamp = a + l;
                }
              }
              var h =
                  null ===
                    (i =
                      this._instance.config.session_recording
                        .compress_events) ||
                  void 0 === i ||
                  i
                    ? (function (t) {
                        if (He(t) < 1024) return t;
                        try {
                          if (t.type === Ge.FullSnapshot)
                            return f({}, t, {
                              data: fs(t.data),
                              cv: "2024-10",
                            });
                          if (
                            t.type === Ge.IncrementalSnapshot &&
                            t.data.source === Je.Mutation
                          )
                            return f({}, t, {
                              cv: "2024-10",
                              data: f({}, t.data, {
                                texts: fs(t.data.texts),
                                attributes: fs(t.data.attributes),
                                removes: fs(t.data.removes),
                                adds: fs(t.data.adds),
                              }),
                            });
                          if (
                            t.type === Ge.IncrementalSnapshot &&
                            t.data.source === Je.StyleSheetRule
                          )
                            return f({}, t, {
                              cv: "2024-10",
                              data: f({}, t.data, {
                                adds: t.data.adds ? fs(t.data.adds) : void 0,
                                removes: t.data.removes
                                  ? fs(t.data.removes)
                                  : void 0,
                              }),
                            });
                        } catch (t) {
                          hs.error(
                            "could not compress event - will use uncompressed event",
                            t,
                          );
                        }
                        return t;
                      })(n)
                    : n,
                u = {
                  $snapshot_bytes: He(h),
                  $snapshot_data: h,
                  $session_id: this.Ot,
                  $window_id: this.gi,
                };
              this.status !== qr ? this.qi(u) : this.mi();
            }
          }
        }
      }
    }
    Ni() {
      if (!this._instance.config.capture_pageview && t) {
        var i = this.Si(t.location.href);
        this.Li !== i && (this.di("$url_changed", { href: i }), (this.Li = i));
      }
    }
    ji() {
      if (this.ti.length) {
        var t = [...this.ti];
        ((this.ti = []),
          t.forEach((t) => {
            Date.now() - t.enqueuedAt <= 2e3 && this.Fi(t);
          }));
      }
    }
    Si(t) {
      var i = this._instance.config.session_recording;
      if (i.maskNetworkRequestFn) {
        var e,
          r = { url: t };
        return null == (e = r = i.maskNetworkRequestFn(r)) ? void 0 : e.url;
      }
      return t;
    }
    mi() {
      return (
        (this.H = { size: 0, data: [], sessionId: this.Ot, windowId: this.gi }),
        this.H
      );
    }
    hi() {
      this.Hi && (clearTimeout(this.Hi), (this.Hi = void 0));
      var t = this.Vt,
        i = this.Ut,
        e = F(i) && i >= 0,
        r = F(t) && e && i < t;
      if (this.status === Gr || this.status === Jr || this.status === qr || r)
        return (
          (this.Hi = setTimeout(() => {
            this.hi();
          }, 2e3)),
          this.H
        );
      this.H.data.length > 0 &&
        We(this.H).forEach((t) => {
          this.Wi({
            $snapshot_bytes: t.size,
            $snapshot_data: t.data,
            $session_id: t.sessionId,
            $window_id: t.windowId,
            $lib: "web",
            $lib_version: c.LIB_VERSION,
          });
        });
      return this.mi();
    }
    qi(t) {
      var i,
        e = 2 + ((null == (i = this.H) ? void 0 : i.data.length) || 0);
      (!this.ii &&
        (this.H.size + t.$snapshot_bytes + e > 943718.4 ||
          this.H.sessionId !== this.Ot) &&
        (this.H = this.hi()),
        (this.H.size += t.$snapshot_bytes),
        this.H.data.push(t.$snapshot_data),
        this.Hi ||
          this.ii ||
          (this.Hi = setTimeout(() => {
            this.hi();
          }, 2e3)));
    }
    Wi(t) {
      this._instance.capture("$snapshot", t, {
        _url: this._instance.requestRouter.endpointFor("api", this.fi),
        _noTruncate: !0,
        _batchKey: "recordings",
        skip_client_rate_limiting: !0,
      });
    }
    Bi(t) {
      var i;
      this.Nt.triggerStatus(this.sessionId) === Yr &&
        (null == (i = this._instance) ||
          null == (i = i.persistence) ||
          i.register({ ["url" === t ? Pt : Rt]: this.Ot }),
        this.hi(),
        this.Ei(t + "_trigger_matched"));
    }
    zi() {
      this.Xt.urlBlocked ||
        ((this.Xt.urlBlocked = !0),
        clearInterval(this.$i),
        hs.info("recording paused due to URL blocker"),
        this.di("recording paused", { reason: "url blocker" }));
    }
    Ui() {
      this.Xt.urlBlocked &&
        ((this.Xt.urlBlocked = !1),
        this.Oi(),
        this.Mi(),
        this.di("recording resumed", { reason: "left blocked url" }),
        hs.info("recording resumed"));
    }
    wi() {
      0 !== this.Qt.Mt.length &&
        M(this.ai) &&
        (this.ai = this._instance.on("eventCaptured", (t) => {
          try {
            this.Qt.Mt.includes(t.event) && this.Bi("event");
          } catch (t) {
            hs.error("Could not activate event trigger", t);
          }
        }));
    }
    overrideLinkedFlag() {
      ((this.Zt.linkedFlagSeen = !0),
        this.Oi(),
        this.Ei("linked_flag_overridden"));
    }
    overrideSampling() {
      var t;
      (null == (t = this._instance.persistence) || t.register({ [It]: !0 }),
        this.Oi(),
        this.Ei("sampling_overridden"));
    }
    overrideTrigger(t) {
      this.Bi(t);
    }
    Ei(t, i) {
      (this._instance.register_for_session({
        $session_recording_start_reason: t,
      }),
        hs.info(t.replace("_", " "), i),
        _(["recording_initialized", "session_id_changed"], t) || this.di(t, i));
    }
    get sdkDebugProperties() {
      var { sessionStartTimestamp: t } =
        this.jt.checkAndGetSessionAndWindowId(!0);
      return {
        $recording_status: this.status,
        $sdk_debug_replay_internal_buffer_length: this.H.data.length,
        $sdk_debug_replay_internal_buffer_size: this.H.size,
        $sdk_debug_current_session_duration: this.Ut,
        $sdk_debug_session_start: t,
      };
    }
  }
  var _s = H("[SegmentIntegration]");
  function ms(t, i) {
    var e = t.config.segment;
    if (!e) return i();
    !(function (t, i) {
      var e = t.config.segment;
      if (!e) return i();
      var r = (e) => {
          var r = () => e.anonymousId() || Hi();
          ((t.config.get_device_id = r),
            e.id() &&
              (t.register({ distinct_id: e.id(), $device_id: r() }),
              t.persistence.set_property(Lt, "identified")),
            i());
        },
        s = e.user();
      "then" in s && k(s.then) ? s.then((t) => r(t)) : r(s);
    })(t, () => {
      e.register(
        ((t) => {
          (Promise && Promise.resolve) ||
            _s.warn(
              "This browser does not have Promise support, and can not use the segment integration",
            );
          var i = (i, e) => {
            if (!e) return i;
            (i.event.userId ||
              i.event.anonymousId === t.get_distinct_id() ||
              (_s.info("No userId set, resetting PostHog"), t.reset()),
              i.event.userId &&
                i.event.userId !== t.get_distinct_id() &&
                (_s.info("UserId set, identifying with PostHog"),
                t.identify(i.event.userId)));
            var r = t.calculateEventProperties(e, i.event.properties);
            return (
              (i.event.properties = Object.assign({}, r, i.event.properties)),
              i
            );
          };
          return {
            name: "PostHog JS",
            type: "enrichment",
            version: "1.0.0",
            isLoaded: () => !0,
            load: () => Promise.resolve(),
            track: (t) => i(t, t.event.event),
            page: (t) => i(t, "$pageview"),
            identify: (t) => i(t, "$identify"),
            screen: (t) => i(t, "$screen"),
          };
        })(t),
      ).then(() => {
        i();
      });
    });
  }
  var bs = "posthog-js";
  function ys(t, i) {
    var {
      organization: e,
      projectId: r,
      prefix: s,
      severityAllowList: n = ["error"],
    } = void 0 === i ? {} : i;
    return (i) => {
      var o, a, l, h, u;
      if (!("*" === n || n.includes(i.level)) || !t.__loaded) return i;
      i.tags || (i.tags = {});
      var d = t.requestRouter.endpointFor(
        "ui",
        "/project/" + t.config.token + "/person/" + t.get_distinct_id(),
      );
      ((i.tags["PostHog Person URL"] = d),
        t.sessionRecordingStarted() &&
          (i.tags["PostHog Recording URL"] = t.get_session_replay_url({
            withTimestamp: !0,
          })));
      var v = (null == (o = i.exception) ? void 0 : o.values) || [],
        c = v.map((t) =>
          f({}, t, {
            stacktrace: t.stacktrace
              ? f({}, t.stacktrace, {
                  type: "raw",
                  frames: (t.stacktrace.frames || []).map((t) =>
                    f({}, t, { platform: "web:javascript" }),
                  ),
                })
              : void 0,
          }),
        ),
        p = {
          $exception_message:
            (null == (a = v[0]) ? void 0 : a.value) || i.message,
          $exception_type: null == (l = v[0]) ? void 0 : l.type,
          $exception_personURL: d,
          $exception_level: i.level,
          $exception_list: c,
          $sentry_event_id: i.event_id,
          $sentry_exception: i.exception,
          $sentry_exception_message:
            (null == (h = v[0]) ? void 0 : h.value) || i.message,
          $sentry_exception_type: null == (u = v[0]) ? void 0 : u.type,
          $sentry_tags: i.tags,
        };
      return (
        e &&
          r &&
          (p.$sentry_url =
            (s || "https://sentry.io/organizations/") +
            e +
            "/issues/?project=" +
            r +
            "&query=" +
            i.event_id),
        t.exceptions.sendExceptionEvent(p),
        i
      );
    };
  }
  class ws {
    constructor(t, i, e, r, s) {
      ((this.name = bs),
        (this.setupOnce = function (n) {
          n(
            ys(t, {
              organization: i,
              projectId: e,
              prefix: r,
              severityAllowList: s,
            }),
          );
        }));
    }
  }
  var Ss =
      null != t && t.location
        ? Ci(t.location.hash, "__posthog") || Ci(location.hash, "state")
        : null,
    $s = "_postHogToolbarParams",
    xs = H("[Toolbar]"),
    ks = (function (t) {
      return (
        (t[(t.UNINITIALIZED = 0)] = "UNINITIALIZED"),
        (t[(t.LOADING = 1)] = "LOADING"),
        (t[(t.LOADED = 2)] = "LOADED"),
        t
      );
    })(ks || {});
  class Es {
    constructor(t) {
      this.instance = t;
    }
    Gi(t) {
      v.ph_toolbar_state = t;
    }
    Ji() {
      var t;
      return null !== (t = v.ph_toolbar_state) && void 0 !== t
        ? t
        : ks.UNINITIALIZED;
    }
    maybeLoadToolbar(i, e, r) {
      if (
        (void 0 === i && (i = void 0),
        void 0 === e && (e = void 0),
        void 0 === r && (r = void 0),
        !t || !o)
      )
        return !1;
      ((i = null != i ? i : t.location), (r = null != r ? r : t.history));
      try {
        if (!e) {
          try {
            (t.localStorage.setItem("test", "test"),
              t.localStorage.removeItem("test"));
          } catch (t) {
            return !1;
          }
          e = null == t ? void 0 : t.localStorage;
        }
        var s,
          n = Ss || Ci(i.hash, "__posthog") || Ci(i.hash, "state"),
          a = n
            ? Z(() => JSON.parse(atob(decodeURIComponent(n)))) ||
              Z(() => JSON.parse(decodeURIComponent(n)))
            : null;
        return (
          a && "ph_authorize" === a.action
            ? (((s = a).source = "url"),
              s &&
                Object.keys(s).length > 0 &&
                (a.desiredHash
                  ? (i.hash = a.desiredHash)
                  : r
                    ? r.replaceState(r.state, "", i.pathname + i.search)
                    : (i.hash = "")))
            : (((s = JSON.parse(e.getItem($s) || "{}")).source =
                "localstorage"),
              delete s.userIntent),
          !(!s.token || this.instance.config.token !== s.token) &&
            (this.loadToolbar(s), !0)
        );
      } catch (t) {
        return !1;
      }
    }
    Vi(t) {
      var i = v.ph_load_toolbar || v.ph_load_editor;
      !M(i) && k(i)
        ? i(t, this.instance)
        : xs.warn("No toolbar load function found");
    }
    loadToolbar(i) {
      var e = !(null == o || !o.getElementById(Wt));
      if (!t || e) return !1;
      var r =
          "custom" === this.instance.requestRouter.region &&
          this.instance.config.advanced_disable_toolbar_metrics,
        s = f(
          { token: this.instance.config.token },
          i,
          { apiURL: this.instance.requestRouter.endpointFor("ui") },
          r ? { instrument: !1 } : {},
        );
      if (
        (t.localStorage.setItem(
          $s,
          JSON.stringify(f({}, s, { source: void 0 })),
        ),
        this.Ji() === ks.LOADED)
      )
        this.Vi(s);
      else if (this.Ji() === ks.UNINITIALIZED) {
        var n;
        (this.Gi(ks.LOADING),
          null == (n = v.__PosthogExtensions__) ||
            null == n.loadExternalDependency ||
            n.loadExternalDependency(this.instance, "toolbar", (t) => {
              if (t)
                return (
                  xs.error("[Toolbar] Failed to load", t),
                  void this.Gi(ks.UNINITIALIZED)
                );
              (this.Gi(ks.LOADED), this.Vi(s));
            }),
          ot(t, "turbolinks:load", () => {
            (this.Gi(ks.UNINITIALIZED), this.loadToolbar(s));
          }));
      }
      return !0;
    }
    Ki(t) {
      return this.loadToolbar(t);
    }
    maybeLoadEditor(t, i, e) {
      return (
        void 0 === t && (t = void 0),
        void 0 === i && (i = void 0),
        void 0 === e && (e = void 0),
        this.maybeLoadToolbar(t, i, e)
      );
    }
  }
  var Is = H("[TracingHeaders]");
  class Ps {
    constructor(t) {
      ((this.Yi = void 0),
        (this.Xi = void 0),
        (this.lt = () => {
          var t, i;
          P(this.Yi) &&
            (null == (t = v.__PosthogExtensions__) ||
              null == (t = t.tracingHeadersPatchFns) ||
              t._patchXHR(
                this._instance.config.__add_tracing_headers || [],
                this._instance.get_distinct_id(),
                this._instance.sessionManager,
              ));
          P(this.Xi) &&
            (null == (i = v.__PosthogExtensions__) ||
              null == (i = i.tracingHeadersPatchFns) ||
              i._patchFetch(
                this._instance.config.__add_tracing_headers || [],
                this._instance.get_distinct_id(),
                this._instance.sessionManager,
              ));
        }),
        (this._instance = t));
    }
    nt(t) {
      var i, e;
      (null != (i = v.__PosthogExtensions__) && i.tracingHeadersPatchFns && t(),
        null == (e = v.__PosthogExtensions__) ||
          null == e.loadExternalDependency ||
          e.loadExternalDependency(this._instance, "tracing-headers", (i) => {
            if (i) return Is.error("failed to load script", i);
            t();
          }));
    }
    startIfEnabledOrStop() {
      var t, i;
      this._instance.config.__add_tracing_headers
        ? this.nt(this.lt)
        : (null == (t = this.Yi) || t.call(this),
          null == (i = this.Xi) || i.call(this),
          (this.Yi = void 0),
          (this.Xi = void 0));
    }
  }
  var Rs = H("[Web Vitals]"),
    Ts = 9e5;
  class Cs {
    constructor(t) {
      var i;
      ((this.Qi = !1),
        (this.C = !1),
        (this.H = { url: void 0, metrics: [], firstMetricTimestamp: void 0 }),
        (this.Zi = () => {
          (clearTimeout(this.te),
            0 !== this.H.metrics.length &&
              (this._instance.capture(
                "$web_vitals",
                this.H.metrics.reduce(
                  (t, i) =>
                    f({}, t, {
                      ["$web_vitals_" + i.name + "_event"]: f({}, i),
                      ["$web_vitals_" + i.name + "_value"]: i.value,
                    }),
                  {},
                ),
              ),
              (this.H = {
                url: void 0,
                metrics: [],
                firstMetricTimestamp: void 0,
              })));
        }),
        (this.ie = (t) => {
          var i,
            e =
              null == (i = this._instance.sessionManager)
                ? void 0
                : i.checkAndGetSessionAndWindowId(!0);
          if (P(e)) Rs.error("Could not read session ID. Dropping metrics!");
          else {
            this.H = this.H || {
              url: void 0,
              metrics: [],
              firstMetricTimestamp: void 0,
            };
            var r = this.ee();
            if (!P(r))
              if (
                M(null == t ? void 0 : t.name) ||
                M(null == t ? void 0 : t.value)
              )
                Rs.error("Invalid metric received", t);
              else if (this.re && t.value >= this.re)
                Rs.error("Ignoring metric with value >= " + this.re, t);
              else
                (this.H.url !== r &&
                  (this.Zi(),
                  (this.te = setTimeout(
                    this.Zi,
                    this.flushToCaptureTimeoutMs,
                  ))),
                  P(this.H.url) && (this.H.url = r),
                  (this.H.firstMetricTimestamp = P(this.H.firstMetricTimestamp)
                    ? Date.now()
                    : this.H.firstMetricTimestamp),
                  t.attribution &&
                    t.attribution.interactionTargetElement &&
                    (t.attribution.interactionTargetElement = void 0),
                  this.H.metrics.push(
                    f({}, t, {
                      $current_url: r,
                      $session_id: e.sessionId,
                      $window_id: e.windowId,
                      timestamp: Date.now(),
                    }),
                  ),
                  this.H.metrics.length === this.allowedMetrics.length &&
                    this.Zi());
          }
        }),
        (this.lt = () => {
          var t,
            i,
            e,
            r,
            s = v.__PosthogExtensions__;
          (P(s) ||
            P(s.postHogWebVitalsCallbacks) ||
            ({
              onLCP: t,
              onCLS: i,
              onFCP: e,
              onINP: r,
            } = s.postHogWebVitalsCallbacks),
            t && i && e && r
              ? (this.allowedMetrics.indexOf("LCP") > -1 &&
                  t(this.ie.bind(this)),
                this.allowedMetrics.indexOf("CLS") > -1 &&
                  i(this.ie.bind(this)),
                this.allowedMetrics.indexOf("FCP") > -1 &&
                  e(this.ie.bind(this)),
                this.allowedMetrics.indexOf("INP") > -1 &&
                  r(this.ie.bind(this)),
                (this.C = !0))
              : Rs.error("web vitals callbacks not loaded - not starting"));
        }),
        (this._instance = t),
        (this.Qi = !(null == (i = this._instance.persistence) || !i.props[pt])),
        this.startIfEnabled());
    }
    get allowedMetrics() {
      var t,
        i,
        e = E(this._instance.config.capture_performance)
          ? null == (t = this._instance.config.capture_performance)
            ? void 0
            : t.web_vitals_allowed_metrics
          : void 0;
      return P(e)
        ? (null == (i = this._instance.persistence) ? void 0 : i.props[_t]) || [
            "CLS",
            "FCP",
            "INP",
            "LCP",
          ]
        : e;
    }
    get flushToCaptureTimeoutMs() {
      return (
        (E(this._instance.config.capture_performance)
          ? this._instance.config.capture_performance
              .web_vitals_delayed_flush_ms
          : void 0) || 5e3
      );
    }
    get re() {
      var t =
        E(this._instance.config.capture_performance) &&
        F(this._instance.config.capture_performance.__web_vitals_max_value)
          ? this._instance.config.capture_performance.__web_vitals_max_value
          : Ts;
      return 0 < t && t <= 6e4 ? Ts : t;
    }
    get isEnabled() {
      var t = null == a ? void 0 : a.protocol;
      if ("http:" !== t && "https:" !== t)
        return (
          Rs.info("Web Vitals are disabled on non-http/https protocols"),
          !1
        );
      var i = E(this._instance.config.capture_performance)
        ? this._instance.config.capture_performance.web_vitals
        : O(this._instance.config.capture_performance)
          ? this._instance.config.capture_performance
          : void 0;
      return O(i) ? i : this.Qi;
    }
    startIfEnabled() {
      this.isEnabled &&
        !this.C &&
        (Rs.info("enabled, starting..."), this.nt(this.lt));
    }
    onRemoteConfig(t) {
      var i = E(t.capturePerformance) && !!t.capturePerformance.web_vitals,
        e = E(t.capturePerformance)
          ? t.capturePerformance.web_vitals_allowed_metrics
          : void 0;
      (this._instance.persistence &&
        (this._instance.persistence.register({ [pt]: i }),
        this._instance.persistence.register({ [_t]: e })),
        (this.Qi = i),
        this.startIfEnabled());
    }
    nt(t) {
      var i, e;
      (null != (i = v.__PosthogExtensions__) &&
        i.postHogWebVitalsCallbacks &&
        t(),
        null == (e = v.__PosthogExtensions__) ||
          null == e.loadExternalDependency ||
          e.loadExternalDependency(this._instance, "web-vitals", (i) => {
            i ? Rs.error("failed to load script", i) : t();
          }));
    }
    ee() {
      var i = t ? t.location.href : void 0;
      return (i || Rs.error("Could not determine current URL"), i);
    }
  }
  var Ms = H("[Heatmaps]");
  function Fs(t) {
    return (
      E(t) && "clientX" in t && "clientY" in t && F(t.clientX) && F(t.clientY)
    );
  }
  class Os {
    constructor(t) {
      var i;
      ((this.rageclicks = new Si()),
        (this.Qi = !1),
        (this.C = !1),
        (this.se = null),
        (this.instance = t),
        (this.Qi = !(null == (i = this.instance.persistence) || !i.props[dt])));
    }
    get flushIntervalMilliseconds() {
      var t = 5e3;
      return (
        E(this.instance.config.capture_heatmaps) &&
          this.instance.config.capture_heatmaps.flush_interval_milliseconds &&
          (t =
            this.instance.config.capture_heatmaps.flush_interval_milliseconds),
        t
      );
    }
    get isEnabled() {
      return P(this.instance.config.capture_heatmaps)
        ? P(this.instance.config.enable_heatmaps)
          ? this.Qi
          : this.instance.config.enable_heatmaps
        : !1 !== this.instance.config.capture_heatmaps;
    }
    startIfEnabled() {
      if (this.isEnabled) {
        if (this.C) return;
        (Ms.info("starting..."),
          this.ne(),
          (this.se = setInterval(
            this.oe.bind(this),
            this.flushIntervalMilliseconds,
          )));
      } else {
        var t, i;
        (clearInterval(null !== (t = this.se) && void 0 !== t ? t : void 0),
          null == (i = this.ae) || i.stop(),
          this.getAndClearBuffer());
      }
    }
    onRemoteConfig(t) {
      var i = !!t.heatmaps;
      (this.instance.persistence &&
        this.instance.persistence.register({ [dt]: i }),
        (this.Qi = i),
        this.startIfEnabled());
    }
    getAndClearBuffer() {
      var t = this.H;
      return ((this.H = void 0), t);
    }
    le(t) {
      this.he(t.originalEvent, "deadclick");
    }
    ne() {
      t &&
        o &&
        (ot(t, "beforeunload", this.oe.bind(this)),
        ot(o, "click", (i) => this.he(i || (null == t ? void 0 : t.event)), {
          capture: !0,
        }),
        ot(
          o,
          "mousemove",
          (i) => this.ue(i || (null == t ? void 0 : t.event)),
          { capture: !0 },
        ),
        (this.ae = new he(this.instance, ae, this.le.bind(this))),
        this.ae.startIfEnabled(),
        (this.C = !0));
    }
    de(i, e) {
      var r = this.instance.scrollManager.scrollY(),
        s = this.instance.scrollManager.scrollX(),
        n = this.instance.scrollManager.scrollElement(),
        o = (function (i, e, r) {
          for (var s = i; s && Kt(s) && !Yt(s, "body"); ) {
            if (s === r) return !1;
            if (_(e, null == t ? void 0 : t.getComputedStyle(s).position))
              return !0;
            s = oi(s);
          }
          return !1;
        })(si(i), ["fixed", "sticky"], n);
      return {
        x: i.clientX + (o ? 0 : s),
        y: i.clientY + (o ? 0 : r),
        target_fixed: o,
        type: e,
      };
    }
    he(t, i) {
      var e;
      if ((void 0 === i && (i = "click"), !Vt(t.target) && Fs(t))) {
        var r = this.de(t, i);
        (null != (e = this.rageclicks) &&
          e.isRageClick(t.clientX, t.clientY, new Date().getTime()) &&
          this.ve(f({}, r, { type: "rageclick" })),
          this.ve(r));
      }
    }
    ue(t) {
      !Vt(t.target) &&
        Fs(t) &&
        (clearTimeout(this.ce),
        (this.ce = setTimeout(() => {
          this.ve(this.de(t, "mousemove"));
        }, 500)));
    }
    ve(i) {
      if (t) {
        var e = t.location.href;
        ((this.H = this.H || {}),
          this.H[e] || (this.H[e] = []),
          this.H[e].push(i));
      }
    }
    oe() {
      this.H &&
        !I(this.H) &&
        this.instance.capture("$$heatmap", {
          $heatmap_data: this.getAndClearBuffer(),
        });
    }
  }
  class As {
    constructor(t) {
      this._instance = t;
    }
    doPageView(i, e) {
      var r,
        s = this.fe(i, e);
      return (
        (this.pe = {
          pathname:
            null !== (r = null == t ? void 0 : t.location.pathname) &&
            void 0 !== r
              ? r
              : "",
          pageViewId: e,
          timestamp: i,
        }),
        this._instance.scrollManager.resetContext(),
        s
      );
    }
    doPageLeave(t) {
      var i;
      return this.fe(t, null == (i = this.pe) ? void 0 : i.pageViewId);
    }
    doEvent() {
      var t;
      return { $pageview_id: null == (t = this.pe) ? void 0 : t.pageViewId };
    }
    fe(t, i) {
      var e = this.pe;
      if (!e) return { $pageview_id: i };
      var r = { $pageview_id: i, $prev_pageview_id: e.pageViewId },
        s = this._instance.scrollManager.getContext();
      if (s && !this._instance.config.disable_scroll_properties) {
        var {
          maxScrollHeight: n,
          lastScrollY: o,
          maxScrollY: a,
          maxContentHeight: l,
          lastContentY: h,
          maxContentY: u,
        } = s;
        if (!(P(n) || P(o) || P(a) || P(l) || P(h) || P(u))) {
          ((n = Math.ceil(n)),
            (o = Math.ceil(o)),
            (a = Math.ceil(a)),
            (l = Math.ceil(l)),
            (h = Math.ceil(h)),
            (u = Math.ceil(u)));
          var d = n <= 1 ? 1 : z(o / n, 0, 1, q),
            v = n <= 1 ? 1 : z(a / n, 0, 1, q),
            c = l <= 1 ? 1 : z(h / l, 0, 1, q),
            f = l <= 1 ? 1 : z(u / l, 0, 1, q);
          r = Y(r, {
            $prev_pageview_last_scroll: o,
            $prev_pageview_last_scroll_percentage: d,
            $prev_pageview_max_scroll: a,
            $prev_pageview_max_scroll_percentage: v,
            $prev_pageview_last_content: h,
            $prev_pageview_last_content_percentage: c,
            $prev_pageview_max_content: u,
            $prev_pageview_max_content_percentage: f,
          });
        }
      }
      return (
        e.pathname && (r.$prev_pageview_pathname = e.pathname),
        e.timestamp &&
          (r.$prev_pageview_duration =
            (t.getTime() - e.timestamp.getTime()) / 1e3),
        r
      );
    }
  }
  var Ds = function (t) {
      var i,
        e,
        r,
        s,
        n = "";
      for (
        i = e = 0,
          r = (t = (t + "").replace(/\r\n/g, "\n").replace(/\r/g, "\n")).length,
          s = 0;
        s < r;
        s++
      ) {
        var o = t.charCodeAt(s),
          a = null;
        (o < 128
          ? e++
          : (a =
              o > 127 && o < 2048
                ? String.fromCharCode((o >> 6) | 192, (63 & o) | 128)
                : String.fromCharCode(
                    (o >> 12) | 224,
                    ((o >> 6) & 63) | 128,
                    (63 & o) | 128,
                  )),
          C(a) ||
            (e > i && (n += t.substring(i, e)), (n += a), (i = e = s + 1)));
      }
      return (e > i && (n += t.substring(i, t.length)), n);
    },
    js = !!h || !!l,
    Ls = "text/plain",
    Ns = (t, i) => {
      var [e, r] = t.split("?"),
        s = f({}, i);
      null == r ||
        r.split("&").forEach((t) => {
          var [i] = t.split("=");
          delete s[i];
        });
      var n = Pi(s);
      return e + "?" + (n = n ? (r ? r + "&" : "") + n : r);
    },
    zs = (t, i) =>
      JSON.stringify(t, (t, i) => ("bigint" == typeof i ? i.toString() : i), i),
    Us = (t) => {
      var { data: i, compression: e } = t;
      if (i) {
        if (e === xi.GZipJS) {
          var r = zr(Ur(zs(i)), { mtime: 0 }),
            s = new Blob([r], { type: Ls });
          return { contentType: Ls, body: s, estimatedSize: s.size };
        }
        if (e === xi.Base64) {
          var n = (function (t) {
              var i,
                e,
                r,
                s,
                n,
                o =
                  "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
                a = 0,
                l = 0,
                h = "",
                u = [];
              if (!t) return t;
              t = Ds(t);
              do {
                ((i =
                  ((n =
                    (t.charCodeAt(a++) << 16) |
                    (t.charCodeAt(a++) << 8) |
                    t.charCodeAt(a++)) >>
                    18) &
                  63),
                  (e = (n >> 12) & 63),
                  (r = (n >> 6) & 63),
                  (s = 63 & n),
                  (u[l++] =
                    o.charAt(i) + o.charAt(e) + o.charAt(r) + o.charAt(s)));
              } while (a < t.length);
              switch (((h = u.join("")), t.length % 3)) {
                case 1:
                  h = h.slice(0, -2) + "==";
                  break;
                case 2:
                  h = h.slice(0, -1) + "=";
              }
              return h;
            })(zs(i)),
            o = ((t) =>
              "data=" + encodeURIComponent("string" == typeof t ? t : zs(t)))(
              n,
            );
          return {
            contentType: "application/x-www-form-urlencoded",
            body: o,
            estimatedSize: new Blob([o]).size,
          };
        }
        var a = zs(i);
        return {
          contentType: "application/json",
          body: a,
          estimatedSize: new Blob([a]).size,
        };
      }
    },
    Bs = [];
  (l &&
    Bs.push({
      transport: "fetch",
      method: (t) => {
        var i,
          e,
          {
            contentType: r,
            body: s,
            estimatedSize: n,
          } = null !== (i = Us(t)) && void 0 !== i ? i : {},
          o = new Headers();
        (K(t.headers, function (t, i) {
          o.append(i, t);
        }),
          r && o.append("Content-Type", r));
        var a = t.url,
          h = null;
        if (u) {
          var d = new u();
          h = {
            signal: d.signal,
            timeout: setTimeout(() => d.abort(), t.timeout),
          };
        }
        l(
          a,
          f(
            {
              method: (null == t ? void 0 : t.method) || "GET",
              headers: o,
              keepalive: "POST" === t.method && (n || 0) < 52428.8,
              body: s,
              signal: null == (e = h) ? void 0 : e.signal,
            },
            t.fetchOptions,
          ),
        )
          .then((i) =>
            i.text().then((e) => {
              var r = { statusCode: i.status, text: e };
              if (200 === i.status)
                try {
                  r.json = JSON.parse(e);
                } catch (t) {
                  q.error(t);
                }
              null == t.callback || t.callback(r);
            }),
          )
          .catch((i) => {
            (q.error(i),
              null == t.callback || t.callback({ statusCode: 0, text: i }));
          })
          .finally(() => (h ? clearTimeout(h.timeout) : null));
      },
    }),
    h &&
      Bs.push({
        transport: "XHR",
        method: (t) => {
          var i,
            e = new h();
          e.open(t.method || "GET", t.url, !0);
          var { contentType: r, body: s } =
            null !== (i = Us(t)) && void 0 !== i ? i : {};
          (K(t.headers, function (t, i) {
            e.setRequestHeader(i, t);
          }),
            r && e.setRequestHeader("Content-Type", r),
            t.timeout && (e.timeout = t.timeout),
            (e.withCredentials = !0),
            (e.onreadystatechange = () => {
              if (4 === e.readyState) {
                var i = { statusCode: e.status, text: e.responseText };
                if (200 === e.status)
                  try {
                    i.json = JSON.parse(e.responseText);
                  } catch (t) {}
                null == t.callback || t.callback(i);
              }
            }),
            e.send(s));
        },
      }),
    null != n &&
      n.sendBeacon &&
      Bs.push({
        transport: "sendBeacon",
        method: (t) => {
          var i = Ns(t.url, { beacon: "1" });
          try {
            var e,
              { contentType: r, body: s } =
                null !== (e = Us(t)) && void 0 !== e ? e : {},
              o = "string" == typeof s ? new Blob([s], { type: r }) : s;
            n.sendBeacon(i, o);
          } catch (t) {}
        },
      }));
  var qs = function (t, i) {
    if (
      !(function (t) {
        try {
          new RegExp(t);
        } catch (t) {
          return !1;
        }
        return !0;
      })(i)
    )
      return !1;
    try {
      return new RegExp(i).test(t);
    } catch (t) {
      return !1;
    }
  };
  function Hs(t, i, e) {
    return zs({
      distinct_id: t,
      userPropertiesToSet: i,
      userPropertiesToSetOnce: e,
    });
  }
  var Ws = {
      exact: (t, i) => i.some((i) => t.some((t) => i === t)),
      is_not: (t, i) => i.every((i) => t.every((t) => i !== t)),
      regex: (t, i) => i.some((i) => t.some((t) => qs(i, t))),
      not_regex: (t, i) => i.every((i) => t.every((t) => !qs(i, t))),
      icontains: (t, i) =>
        i.map(Gs).some((i) => t.map(Gs).some((t) => i.includes(t))),
      not_icontains: (t, i) =>
        i.map(Gs).every((i) => t.map(Gs).every((t) => !i.includes(t))),
    },
    Gs = (t) => t.toLowerCase(),
    Js = H("[Error tracking]");
  class Vs {
    constructor(t) {
      var i, e;
      ((this.ge = []),
        (this._instance = t),
        (this.ge =
          null !==
            (i =
              null == (e = this._instance.persistence)
                ? void 0
                : e.get_property(ct)) && void 0 !== i
            ? i
            : []));
    }
    onRemoteConfig(t) {
      var i,
        e,
        r,
        s =
          null !==
            (i = null == (e = t.errorTracking) ? void 0 : e.suppressionRules) &&
          void 0 !== i
            ? i
            : [],
        n =
          null == (r = t.errorTracking) ? void 0 : r.captureExtensionExceptions;
      ((this.ge = s),
        this._instance.persistence &&
          this._instance.persistence.register({ [ct]: this.ge, [ft]: n }));
    }
    get _e() {
      var t,
        i = !!this._instance.get_property(ft),
        e = this._instance.config.error_tracking.captureExtensionExceptions;
      return null !== (t = null != e ? e : i) && void 0 !== t && t;
    }
    sendExceptionEvent(t) {
      if (this.me(t))
        Js.info(
          "Skipping exception capture because a suppression rule matched",
        );
      else {
        if (this._e || !this.be(t))
          return this._instance.capture("$exception", t, {
            _noTruncate: !0,
            _batchKey: "exceptionEvent",
          });
        Js.info(
          "Skipping exception capture because it was thrown by an extension",
        );
      }
    }
    me(t) {
      var i = t.$exception_list;
      if (!i || !x(i) || 0 === i.length) return !1;
      var e = i.reduce(
        (t, i) => {
          var { type: e, value: r } = i;
          return (
            R(e) && e.length > 0 && t.$exception_types.push(e),
            R(r) && r.length > 0 && t.$exception_values.push(r),
            t
          );
        },
        { $exception_types: [], $exception_values: [] },
      );
      return this.ge.some((t) => {
        var i = t.values.map((t) => {
          var i,
            r = Ws[t.operator],
            s = x(t.value) ? t.value : [t.value],
            n = null !== (i = e[t.key]) && void 0 !== i ? i : [];
          return s.length > 0 && r(s, n);
        });
        return "OR" === t.type ? i.some(Boolean) : i.every(Boolean);
      });
    }
    be(t) {
      var i = t.$exception_list;
      return (
        !(!i || !x(i)) &&
        i
          .flatMap((t) => {
            var i, e;
            return null !==
              (i = null == (e = t.stacktrace) ? void 0 : e.frames) &&
              void 0 !== i
              ? i
              : [];
          })
          .some(
            (t) => t.filename && t.filename.startsWith("chrome-extension://"),
          )
      );
    }
  }
  var Ks = "Mobile",
    Ys = "iOS",
    Xs = "Android",
    Qs = "Tablet",
    Zs = Xs + " " + Qs,
    tn = "iPad",
    en = "Apple",
    rn = en + " Watch",
    sn = "Safari",
    nn = "BlackBerry",
    on = "Samsung",
    an = on + "Browser",
    ln = on + " Internet",
    hn = "Chrome",
    un = hn + " OS",
    dn = hn + " " + Ys,
    vn = "Internet Explorer",
    cn = vn + " " + Ks,
    fn = "Opera",
    pn = fn + " Mini",
    gn = "Edge",
    _n = "Microsoft " + gn,
    mn = "Firefox",
    bn = mn + " " + Ys,
    yn = "Nintendo",
    wn = "PlayStation",
    Sn = "Xbox",
    $n = Xs + " " + Ks,
    xn = Ks + " " + sn,
    kn = "Windows",
    En = kn + " Phone",
    In = "Nokia",
    Pn = "Ouya",
    Rn = "Generic",
    Tn = Rn + " " + Ks.toLowerCase(),
    Cn = Rn + " " + Qs.toLowerCase(),
    Mn = "Konqueror",
    Fn = "(\\d+(\\.\\d+)?)",
    On = new RegExp("Version/" + Fn),
    An = new RegExp(Sn, "i"),
    Dn = new RegExp(wn + " \\w+", "i"),
    jn = new RegExp(yn + " \\w+", "i"),
    Ln = new RegExp(nn + "|PlayBook|BB10", "i"),
    Nn = {
      "NT3.51": "NT 3.11",
      "NT4.0": "NT 4.0",
      "5.0": "2000",
      5.1: "XP",
      5.2: "XP",
      "6.0": "Vista",
      6.1: "7",
      6.2: "8",
      6.3: "8.1",
      6.4: "10",
      "10.0": "10",
    };
  var zn = (t, i) =>
      (i && _(i, en)) ||
      (function (t) {
        return _(t, sn) && !_(t, hn) && !_(t, Xs);
      })(t),
    Un = function (t, i) {
      return (
        (i = i || ""),
        _(t, " OPR/") && _(t, "Mini")
          ? pn
          : _(t, " OPR/")
            ? fn
            : Ln.test(t)
              ? nn
              : _(t, "IE" + Ks) || _(t, "WPDesktop")
                ? cn
                : _(t, an)
                  ? ln
                  : _(t, gn) || _(t, "Edg/")
                    ? _n
                    : _(t, "FBIOS")
                      ? "Facebook " + Ks
                      : _(t, "UCWEB") || _(t, "UCBrowser")
                        ? "UC Browser"
                        : _(t, "CriOS")
                          ? dn
                          : _(t, "CrMo") || _(t, hn)
                            ? hn
                            : _(t, Xs) && _(t, sn)
                              ? $n
                              : _(t, "FxiOS")
                                ? bn
                                : _(t.toLowerCase(), Mn.toLowerCase())
                                  ? Mn
                                  : zn(t, i)
                                    ? _(t, Ks)
                                      ? xn
                                      : sn
                                    : _(t, mn)
                                      ? mn
                                      : _(t, "MSIE") || _(t, "Trident/")
                                        ? vn
                                        : _(t, "Gecko")
                                          ? mn
                                          : ""
      );
    },
    Bn = {
      [cn]: [new RegExp("rv:" + Fn)],
      [_n]: [new RegExp(gn + "?\\/" + Fn)],
      [hn]: [new RegExp("(" + hn + "|CrMo)\\/" + Fn)],
      [dn]: [new RegExp("CriOS\\/" + Fn)],
      "UC Browser": [new RegExp("(UCBrowser|UCWEB)\\/" + Fn)],
      [sn]: [On],
      [xn]: [On],
      [fn]: [new RegExp("(Opera|OPR)\\/" + Fn)],
      [mn]: [new RegExp(mn + "\\/" + Fn)],
      [bn]: [new RegExp("FxiOS\\/" + Fn)],
      [Mn]: [new RegExp("Konqueror[:/]?" + Fn, "i")],
      [nn]: [new RegExp(nn + " " + Fn), On],
      [$n]: [new RegExp("android\\s" + Fn, "i")],
      [ln]: [new RegExp(an + "\\/" + Fn)],
      [vn]: [new RegExp("(rv:|MSIE )" + Fn)],
      Mozilla: [new RegExp("rv:" + Fn)],
    },
    qn = function (t, i) {
      var e = Un(t, i),
        r = Bn[e];
      if (P(r)) return null;
      for (var s = 0; s < r.length; s++) {
        var n = r[s],
          o = t.match(n);
        if (o) return parseFloat(o[o.length - 2]);
      }
      return null;
    },
    Hn = [
      [
        new RegExp(Sn + "; " + Sn + " (.*?)[);]", "i"),
        (t) => [Sn, (t && t[1]) || ""],
      ],
      [new RegExp(yn, "i"), [yn, ""]],
      [new RegExp(wn, "i"), [wn, ""]],
      [Ln, [nn, ""]],
      [
        new RegExp(kn, "i"),
        (t, i) => {
          if (/Phone/.test(i) || /WPDesktop/.test(i)) return [En, ""];
          if (new RegExp(Ks).test(i) && !/IEMobile\b/.test(i))
            return [kn + " " + Ks, ""];
          var e = /Windows NT ([0-9.]+)/i.exec(i);
          if (e && e[1]) {
            var r = e[1],
              s = Nn[r] || "";
            return (/arm/i.test(i) && (s = "RT"), [kn, s]);
          }
          return [kn, ""];
        },
      ],
      [
        /((iPhone|iPad|iPod).*?OS (\d+)_(\d+)_?(\d+)?|iPhone)/,
        (t) => {
          if (t && t[3]) {
            var i = [t[3], t[4], t[5] || "0"];
            return [Ys, i.join(".")];
          }
          return [Ys, ""];
        },
      ],
      [
        /(watch.*\/(\d+\.\d+\.\d+)|watch os,(\d+\.\d+),)/i,
        (t) => {
          var i = "";
          return (
            t && t.length >= 3 && (i = P(t[2]) ? t[3] : t[2]),
            ["watchOS", i]
          );
        },
      ],
      [
        new RegExp("(" + Xs + " (\\d+)\\.(\\d+)\\.?(\\d+)?|" + Xs + ")", "i"),
        (t) => {
          if (t && t[2]) {
            var i = [t[2], t[3], t[4] || "0"];
            return [Xs, i.join(".")];
          }
          return [Xs, ""];
        },
      ],
      [
        /Mac OS X (\d+)[_.](\d+)[_.]?(\d+)?/i,
        (t) => {
          var i = ["Mac OS X", ""];
          if (t && t[1]) {
            var e = [t[1], t[2], t[3] || "0"];
            i[1] = e.join(".");
          }
          return i;
        },
      ],
      [/Mac/i, ["Mac OS X", ""]],
      [/CrOS/, [un, ""]],
      [/Linux|debian/i, ["Linux", ""]],
    ],
    Wn = function (t) {
      return jn.test(t)
        ? yn
        : Dn.test(t)
          ? wn
          : An.test(t)
            ? Sn
            : new RegExp(Pn, "i").test(t)
              ? Pn
              : new RegExp("(" + En + "|WPDesktop)", "i").test(t)
                ? En
                : /iPad/.test(t)
                  ? tn
                  : /iPod/.test(t)
                    ? "iPod Touch"
                    : /iPhone/.test(t)
                      ? "iPhone"
                      : /(watch)(?: ?os[,/]|\d,\d\/)[\d.]+/i.test(t)
                        ? rn
                        : Ln.test(t)
                          ? nn
                          : /(kobo)\s(ereader|touch)/i.test(t)
                            ? "Kobo"
                            : new RegExp(In, "i").test(t)
                              ? In
                              : /(kf[a-z]{2}wi|aeo[c-r]{2})( bui|\))/i.test(
                                    t,
                                  ) || /(kf[a-z]+)( bui|\)).+silk\//i.test(t)
                                ? "Kindle Fire"
                                : /(Android|ZTE)/i.test(t)
                                  ? !new RegExp(Ks).test(t) ||
                                    /(9138B|TB782B|Nexus [97]|pixel c|HUAWEISHT|BTV|noble nook|smart ultra 6)/i.test(
                                      t,
                                    )
                                    ? (/pixel[\daxl ]{1,6}/i.test(t) &&
                                        !/pixel c/i.test(t)) ||
                                      /(huaweimed-al00|tah-|APA|SM-G92|i980|zte|U304AA)/i.test(
                                        t,
                                      ) ||
                                      (/lmy47v/i.test(t) && !/QTAQZ3/i.test(t))
                                      ? Xs
                                      : Zs
                                    : Xs
                                  : new RegExp("(pda|" + Ks + ")", "i").test(t)
                                    ? Tn
                                    : new RegExp(Qs, "i").test(t) &&
                                        !new RegExp(Qs + " pc", "i").test(t)
                                      ? Cn
                                      : "";
    },
    Gn = "https?://(.*)",
    Jn = [
      "gclid",
      "gclsrc",
      "dclid",
      "gbraid",
      "wbraid",
      "fbclid",
      "msclkid",
      "twclid",
      "li_fat_id",
      "igshid",
      "ttclid",
      "rdt_cid",
      "epik",
      "qclid",
      "sccid",
      "irclid",
      "_kx",
    ],
    Vn = X(
      [
        "utm_source",
        "utm_medium",
        "utm_campaign",
        "utm_content",
        "utm_term",
        "gad_source",
        "mc_cid",
      ],
      Jn,
    ),
    Kn = "<masked>",
    Yn = ["li_fat_id"];
  function Xn(t, i, e) {
    if (!o) return {};
    var r,
      s = i ? X([], Jn, e || []) : [],
      n = Qn(Ti(o.URL, s, Kn), t),
      a =
        ((r = {}),
        K(Yn, function (t) {
          var i = Ki.V(t);
          r[t] = i || null;
        }),
        r);
    return Y(a, n);
  }
  function Qn(t, i) {
    var e = Vn.concat(i || []),
      r = {};
    return (
      K(e, function (i) {
        var e = Ri(t, i);
        r[i] = e || null;
      }),
      r
    );
  }
  function Zn(t) {
    var i = (function (t) {
        return t
          ? 0 === t.search(Gn + "google.([^/?]*)")
            ? "google"
            : 0 === t.search(Gn + "bing.com")
              ? "bing"
              : 0 === t.search(Gn + "yahoo.com")
                ? "yahoo"
                : 0 === t.search(Gn + "duckduckgo.com")
                  ? "duckduckgo"
                  : null
          : null;
      })(t),
      e = "yahoo" != i ? "q" : "p",
      r = {};
    if (!C(i)) {
      r.$search_engine = i;
      var s = o ? Ri(o.referrer, e) : "";
      s.length && (r.ph_keyword = s);
    }
    return r;
  }
  function to() {
    return navigator.language || navigator.userLanguage;
  }
  function io() {
    return (null == o ? void 0 : o.referrer) || "$direct";
  }
  function eo(t, i) {
    var e = t ? X([], Jn, i || []) : [],
      r = null == a ? void 0 : a.href.substring(0, 1e3);
    return { r: io().substring(0, 1e3), u: r ? Ti(r, e, Kn) : void 0 };
  }
  function ro(t) {
    var i,
      { r: e, u: r } = t,
      s = {
        $referrer: e,
        $referring_domain:
          null == e
            ? void 0
            : "$direct" == e
              ? "$direct"
              : null == (i = Ii(e))
                ? void 0
                : i.host,
      };
    if (r) {
      s.$current_url = r;
      var n = Ii(r);
      ((s.$host = null == n ? void 0 : n.host),
        (s.$pathname = null == n ? void 0 : n.pathname));
      var o = Qn(r);
      Y(s, o);
    }
    if (e) {
      var a = Zn(e);
      Y(s, a);
    }
    return s;
  }
  function so() {
    try {
      return Intl.DateTimeFormat().resolvedOptions().timeZone;
    } catch (t) {
      return;
    }
  }
  function no() {
    try {
      return new Date().getTimezoneOffset();
    } catch (t) {
      return;
    }
  }
  function oo(i, e) {
    if (!d) return {};
    var r,
      s,
      n,
      o = i ? X([], Jn, e || []) : [],
      [l, h] = (function (t) {
        for (var i = 0; i < Hn.length; i++) {
          var [e, r] = Hn[i],
            s = e.exec(t),
            n = s && (k(r) ? r(s, t) : r);
          if (n) return n;
        }
        return ["", ""];
      })(d);
    return Y(
      it({
        $os: l,
        $os_version: h,
        $browser: Un(d, navigator.vendor),
        $device: Wn(d),
        $device_type:
          ((s = d),
          (n = Wn(s)),
          n === tn ||
          n === Zs ||
          "Kobo" === n ||
          "Kindle Fire" === n ||
          n === Cn
            ? Qs
            : n === yn || n === Sn || n === wn || n === Pn
              ? "Console"
              : n === rn
                ? "Wearable"
                : n
                  ? Ks
                  : "Desktop"),
        $timezone: so(),
        $timezone_offset: no(),
      }),
      {
        $current_url: Ti(null == a ? void 0 : a.href, o, Kn),
        $host: null == a ? void 0 : a.host,
        $pathname: null == a ? void 0 : a.pathname,
        $raw_user_agent: d.length > 1e3 ? d.substring(0, 997) + "..." : d,
        $browser_version: qn(d, navigator.vendor),
        $browser_language: to(),
        $browser_language_prefix:
          ((r = to()), "string" == typeof r ? r.split("-")[0] : void 0),
        $screen_height: null == t ? void 0 : t.screen.height,
        $screen_width: null == t ? void 0 : t.screen.width,
        $viewport_height: null == t ? void 0 : t.innerHeight,
        $viewport_width: null == t ? void 0 : t.innerWidth,
        $lib: "web",
        $lib_version: c.LIB_VERSION,
        $insert_id:
          Math.random().toString(36).substring(2, 10) +
          Math.random().toString(36).substring(2, 10),
        $time: Date.now() / 1e3,
      },
    );
  }
  var ao = H("[FeatureFlags]"),
    lo = "$active_feature_flags",
    ho = "$override_feature_flags",
    uo = "$feature_flag_payloads",
    vo = "$override_feature_flag_payloads",
    co = "$feature_flag_request_id",
    fo = (t) => {
      var i = {};
      for (var [e, r] of Q(t || {})) r && (i[e] = r);
      return i;
    },
    po = (t) => {
      var i = t.flags;
      return (
        i
          ? ((t.featureFlags = Object.fromEntries(
              Object.keys(i).map((t) => {
                var e;
                return [
                  t,
                  null !== (e = i[t].variant) && void 0 !== e
                    ? e
                    : i[t].enabled,
                ];
              }),
            )),
            (t.featureFlagPayloads = Object.fromEntries(
              Object.keys(i)
                .filter((t) => i[t].enabled)
                .filter((t) => {
                  var e;
                  return null == (e = i[t].metadata) ? void 0 : e.payload;
                })
                .map((t) => {
                  var e;
                  return [t, null == (e = i[t].metadata) ? void 0 : e.payload];
                }),
            )))
          : ao.warn(
              "Using an older version of the feature flags endpoint. Please upgrade your PostHog server to the latest version",
            ),
        t
      );
    },
    go = (function (t) {
      return (
        (t.FeatureFlags = "feature_flags"),
        (t.Recordings = "recordings"),
        t
      );
    })({});
  class _o {
    constructor(t) {
      ((this.ye = !1),
        (this.we = !1),
        (this.Se = !1),
        (this.$e = !1),
        (this.xe = !1),
        (this.ke = !1),
        (this.Ee = !1),
        (this._instance = t),
        (this.featureFlagEventHandlers = []));
    }
    flags() {
      if (this._instance.config.__preview_remote_config) this.ke = !0;
      else {
        var t =
          !this.Ie &&
          (this._instance.config.advanced_disable_feature_flags ||
            this._instance.config.advanced_disable_feature_flags_on_first_load);
        this.Pe({ disableFlags: t });
      }
    }
    get hasLoadedFlags() {
      return this.we;
    }
    getFlags() {
      return Object.keys(this.getFlagVariants());
    }
    getFlagsWithDetails() {
      var t = this._instance.get_property(Mt),
        i = this._instance.get_property(ho),
        e = this._instance.get_property(vo);
      if (!e && !i) return t || {};
      var r = Y({}, t || {}),
        s = [...new Set([...Object.keys(e || {}), ...Object.keys(i || {})])];
      for (var n of s) {
        var o,
          a,
          l = r[n],
          h = null == i ? void 0 : i[n],
          u = P(h)
            ? null !== (o = null == l ? void 0 : l.enabled) && void 0 !== o && o
            : !!h,
          d = P(h) ? l.variant : "string" == typeof h ? h : void 0,
          v = null == e ? void 0 : e[n],
          c = f({}, l, {
            enabled: u,
            variant: u
              ? null != d
                ? d
                : null == l
                  ? void 0
                  : l.variant
              : void 0,
          });
        if (
          (u !== (null == l ? void 0 : l.enabled) &&
            (c.original_enabled = null == l ? void 0 : l.enabled),
          d !== (null == l ? void 0 : l.variant) &&
            (c.original_variant = null == l ? void 0 : l.variant),
          v)
        )
          c.metadata = f({}, null == l ? void 0 : l.metadata, {
            payload: v,
            original_payload:
              null == l || null == (a = l.metadata) ? void 0 : a.payload,
          });
        r[n] = c;
      }
      return (
        this.ye ||
          (ao.warn(" Overriding feature flag details!", {
            flagDetails: t,
            overriddenPayloads: e,
            finalDetails: r,
          }),
          (this.ye = !0)),
        r
      );
    }
    getFlagVariants() {
      var t = this._instance.get_property(Tt),
        i = this._instance.get_property(ho);
      if (!i) return t || {};
      for (var e = Y({}, t), r = Object.keys(i), s = 0; s < r.length; s++)
        e[r[s]] = i[r[s]];
      return (
        this.ye ||
          (ao.warn(" Overriding feature flags!", {
            enabledFlags: t,
            overriddenFlags: i,
            finalFlags: e,
          }),
          (this.ye = !0)),
        e
      );
    }
    getFlagPayloads() {
      var t = this._instance.get_property(uo),
        i = this._instance.get_property(vo);
      if (!i) return t || {};
      for (var e = Y({}, t || {}), r = Object.keys(i), s = 0; s < r.length; s++)
        e[r[s]] = i[r[s]];
      return (
        this.ye ||
          (ao.warn(" Overriding feature flag payloads!", {
            flagPayloads: t,
            overriddenPayloads: i,
            finalPayloads: e,
          }),
          (this.ye = !0)),
        e
      );
    }
    reloadFeatureFlags() {
      this.$e ||
        this._instance.config.advanced_disable_feature_flags ||
        this.Ie ||
        (this.Ie = setTimeout(() => {
          this.Pe();
        }, 5));
    }
    Re() {
      (clearTimeout(this.Ie), (this.Ie = void 0));
    }
    ensureFlagsLoaded() {
      this.we || this.Se || this.Ie || this.reloadFeatureFlags();
    }
    setAnonymousDistinctId(t) {
      this.$anon_distinct_id = t;
    }
    setReloadingPaused(t) {
      this.$e = t;
    }
    Pe(t) {
      var i;
      if ((this.Re(), !this._instance.L()))
        if (this.Se) this.xe = !0;
        else {
          var e = {
            token: this._instance.config.token,
            distinct_id: this._instance.get_distinct_id(),
            groups: this._instance.getGroups(),
            $anon_distinct_id: this.$anon_distinct_id,
            person_properties: f(
              {},
              (null == (i = this._instance.persistence)
                ? void 0
                : i.get_initial_props()) || {},
              this._instance.get_property(Ft) || {},
            ),
            group_properties: this._instance.get_property(Ot),
          };
          ((null != t && t.disableFlags) ||
            this._instance.config.advanced_disable_feature_flags) &&
            (e.disable_flags = !0);
          var r = this._instance.config.__preview_remote_config,
            s = r ? "/flags/?v=2" : "/flags/?v=2&config=true",
            n = this._instance.config
              .advanced_only_evaluate_survey_feature_flags
              ? "&only_evaluate_survey_feature_flags=true"
              : "",
            o = this._instance.requestRouter.endpointFor("api", s + n);
          (r && (e.timezone = so()),
            (this.Se = !0),
            this._instance.Te({
              method: "POST",
              url: o,
              data: e,
              compression: this._instance.config.disable_compression
                ? void 0
                : xi.Base64,
              timeout: this._instance.config.feature_flag_request_timeout_ms,
              callback: (t) => {
                var i,
                  r,
                  s = !0;
                (200 === t.statusCode &&
                  (this.xe || (this.$anon_distinct_id = void 0), (s = !1)),
                (this.Se = !1),
                this.ke) ||
                  ((this.ke = !0),
                  this._instance.Ce(
                    null !== (r = t.json) && void 0 !== r ? r : {},
                  ));
                if (!e.disable_flags || this.xe)
                  if (
                    ((this.Ee = !s),
                    t.json &&
                      null != (i = t.json.quotaLimited) &&
                      i.includes(go.FeatureFlags))
                  )
                    ao.warn(
                      "You have hit your feature flags quota limit, and will not be able to load feature flags until the quota is reset.  Please visit https://posthog.com/docs/billing/limits-alerts to learn more.",
                    );
                  else {
                    var n;
                    if (!e.disable_flags)
                      this.receivedFeatureFlags(
                        null !== (n = t.json) && void 0 !== n ? n : {},
                        s,
                      );
                    this.xe && ((this.xe = !1), this.Pe());
                  }
              },
            }));
        }
    }
    getFeatureFlag(t, i) {
      if (
        (void 0 === i && (i = {}),
        this.we || (this.getFlags() && this.getFlags().length > 0))
      ) {
        var e = this.getFlagVariants()[t],
          r = "" + e,
          s = this._instance.get_property(co) || void 0,
          n = this._instance.get_property(jt) || {};
        if (
          (i.send_event || !("send_event" in i)) &&
          (!(t in n) || !n[t].includes(r))
        ) {
          var o, a, l, h, u, d, v, c, f;
          (x(n[t]) ? n[t].push(r) : (n[t] = [r]),
            null == (o = this._instance.persistence) ||
              o.register({ [jt]: n }));
          var p = this.getFeatureFlagDetails(t),
            g = {
              $feature_flag: t,
              $feature_flag_response: e,
              $feature_flag_payload: this.getFeatureFlagPayload(t) || null,
              $feature_flag_request_id: s,
              $feature_flag_bootstrapped_response:
                (null == (a = this._instance.config.bootstrap) ||
                null == (a = a.featureFlags)
                  ? void 0
                  : a[t]) || null,
              $feature_flag_bootstrapped_payload:
                (null == (l = this._instance.config.bootstrap) ||
                null == (l = l.featureFlagPayloads)
                  ? void 0
                  : l[t]) || null,
              $used_bootstrap_value: !this.Ee,
            };
          P(null == p || null == (h = p.metadata) ? void 0 : h.version) ||
            (g.$feature_flag_version = p.metadata.version);
          var _,
            m =
              null !==
                (u =
                  null == p || null == (d = p.reason)
                    ? void 0
                    : d.description) && void 0 !== u
                ? u
                : null == p || null == (v = p.reason)
                  ? void 0
                  : v.code;
          if (
            (m && (g.$feature_flag_reason = m),
            null != p &&
              null != (c = p.metadata) &&
              c.id &&
              (g.$feature_flag_id = p.metadata.id),
            (P(null == p ? void 0 : p.original_variant) &&
              P(null == p ? void 0 : p.original_enabled)) ||
              (g.$feature_flag_original_response = P(p.original_variant)
                ? p.original_enabled
                : p.original_variant),
            null != p && null != (f = p.metadata) && f.original_payload)
          )
            g.$feature_flag_original_payload =
              null == p || null == (_ = p.metadata)
                ? void 0
                : _.original_payload;
          this._instance.capture("$feature_flag_called", g);
        }
        return e;
      }
      ao.warn(
        'getFeatureFlag for key "' +
          t +
          "\" failed. Feature flags didn't load in time.",
      );
    }
    getFeatureFlagDetails(t) {
      return this.getFlagsWithDetails()[t];
    }
    getFeatureFlagPayload(t) {
      return this.getFlagPayloads()[t];
    }
    getRemoteConfigPayload(t, i) {
      var e = this._instance.config.token;
      this._instance.Te({
        method: "POST",
        url: this._instance.requestRouter.endpointFor(
          "api",
          "/flags/?v=2&config=true",
        ),
        data: { distinct_id: this._instance.get_distinct_id(), token: e },
        compression: this._instance.config.disable_compression
          ? void 0
          : xi.Base64,
        timeout: this._instance.config.feature_flag_request_timeout_ms,
        callback: (e) => {
          var r,
            s = null == (r = e.json) ? void 0 : r.featureFlagPayloads;
          i((null == s ? void 0 : s[t]) || void 0);
        },
      });
    }
    isFeatureEnabled(t, i) {
      if (
        (void 0 === i && (i = {}),
        this.we || (this.getFlags() && this.getFlags().length > 0))
      )
        return !!this.getFeatureFlag(t, i);
      ao.warn(
        'isFeatureEnabled for key "' +
          t +
          "\" failed. Feature flags didn't load in time.",
      );
    }
    addFeatureFlagsHandler(t) {
      this.featureFlagEventHandlers.push(t);
    }
    removeFeatureFlagsHandler(t) {
      this.featureFlagEventHandlers = this.featureFlagEventHandlers.filter(
        (i) => i !== t,
      );
    }
    receivedFeatureFlags(t, i) {
      if (this._instance.persistence) {
        this.we = !0;
        var e = this.getFlagVariants(),
          r = this.getFlagPayloads(),
          s = this.getFlagsWithDetails();
        (!(function (t, i, e, r, s) {
          (void 0 === e && (e = {}),
            void 0 === r && (r = {}),
            void 0 === s && (s = {}));
          var n = po(t),
            o = n.flags,
            a = n.featureFlags,
            l = n.featureFlagPayloads;
          if (a) {
            var h = t.requestId;
            if (x(a)) {
              ao.warn(
                "v1 of the feature flags endpoint is deprecated. Please use the latest version.",
              );
              var u = {};
              if (a) for (var d = 0; d < a.length; d++) u[a[d]] = !0;
              i && i.register({ [lo]: a, [Tt]: u });
            } else {
              var v = a,
                c = l,
                p = o;
              (t.errorsWhileComputingFlags &&
                ((v = f({}, e, v)), (c = f({}, r, c)), (p = f({}, s, p))),
                i &&
                  i.register(
                    f(
                      {
                        [lo]: Object.keys(fo(v)),
                        [Tt]: v || {},
                        [uo]: c || {},
                        [Mt]: p || {},
                      },
                      h ? { [co]: h } : {},
                    ),
                  ));
            }
          }
        })(t, this._instance.persistence, e, r, s),
          this.Me(i));
      }
    }
    override(t, i) {
      (void 0 === i && (i = !1),
        ao.warn(
          "override is deprecated. Please use overrideFeatureFlags instead.",
        ),
        this.overrideFeatureFlags({ flags: t, suppressWarning: i }));
    }
    overrideFeatureFlags(t) {
      if (!this._instance.__loaded || !this._instance.persistence)
        return ao.uninitializedWarning(
          "posthog.featureFlags.overrideFeatureFlags",
        );
      if (!1 === t)
        return (
          this._instance.persistence.unregister(ho),
          this._instance.persistence.unregister(vo),
          void this.Me()
        );
      if (t && "object" == typeof t && ("flags" in t || "payloads" in t)) {
        var i,
          e = t;
        if (
          ((this.ye = Boolean(
            null !== (i = e.suppressWarning) && void 0 !== i && i,
          )),
          "flags" in e)
        )
          if (!1 === e.flags) this._instance.persistence.unregister(ho);
          else if (e.flags)
            if (x(e.flags)) {
              for (var r = {}, s = 0; s < e.flags.length; s++)
                r[e.flags[s]] = !0;
              this._instance.persistence.register({ [ho]: r });
            } else this._instance.persistence.register({ [ho]: e.flags });
        return (
          "payloads" in e &&
            (!1 === e.payloads
              ? this._instance.persistence.unregister(vo)
              : e.payloads &&
                this._instance.persistence.register({ [vo]: e.payloads })),
          void this.Me()
        );
      }
      this.Me();
    }
    onFeatureFlags(t) {
      if ((this.addFeatureFlagsHandler(t), this.we)) {
        var { flags: i, flagVariants: e } = this.Fe();
        t(i, e);
      }
      return () => this.removeFeatureFlagsHandler(t);
    }
    updateEarlyAccessFeatureEnrollment(t, i, e) {
      var r,
        s = (this._instance.get_property(Ct) || []).find(
          (i) => i.flagKey === t,
        ),
        n = { ["$feature_enrollment/" + t]: i },
        o = { $feature_flag: t, $feature_enrollment: i, $set: n };
      (s && (o.$early_access_feature_name = s.name),
        e && (o.$feature_enrollment_stage = e),
        this._instance.capture("$feature_enrollment_update", o),
        this.setPersonPropertiesForFlags(n, !1));
      var a = f({}, this.getFlagVariants(), { [t]: i });
      (null == (r = this._instance.persistence) ||
        r.register({ [lo]: Object.keys(fo(a)), [Tt]: a }),
        this.Me());
    }
    getEarlyAccessFeatures(t, i, e) {
      void 0 === i && (i = !1);
      var r = this._instance.get_property(Ct),
        s = e ? "&" + e.map((t) => "stage=" + t).join("&") : "";
      if (r && !i) return t(r);
      this._instance.Te({
        url: this._instance.requestRouter.endpointFor(
          "api",
          "/api/early_access_features/?token=" +
            this._instance.config.token +
            s,
        ),
        method: "GET",
        callback: (i) => {
          var e, r;
          if (i.json) {
            var s = i.json.earlyAccessFeatures;
            return (
              null == (e = this._instance.persistence) || e.unregister(Ct),
              null == (r = this._instance.persistence) ||
                r.register({ [Ct]: s }),
              t(s)
            );
          }
        },
      });
    }
    Fe() {
      var t = this.getFlags(),
        i = this.getFlagVariants();
      return {
        flags: t.filter((t) => i[t]),
        flagVariants: Object.keys(i)
          .filter((t) => i[t])
          .reduce((t, e) => ((t[e] = i[e]), t), {}),
      };
    }
    Me(t) {
      var { flags: i, flagVariants: e } = this.Fe();
      this.featureFlagEventHandlers.forEach((r) =>
        r(i, e, { errorsLoading: t }),
      );
    }
    setPersonPropertiesForFlags(t, i) {
      void 0 === i && (i = !0);
      var e = this._instance.get_property(Ft) || {};
      (this._instance.register({ [Ft]: f({}, e, t) }),
        i && this._instance.reloadFeatureFlags());
    }
    resetPersonPropertiesForFlags() {
      this._instance.unregister(Ft);
    }
    setGroupPropertiesForFlags(t, i) {
      void 0 === i && (i = !0);
      var e = this._instance.get_property(Ot) || {};
      (0 !== Object.keys(e).length &&
        Object.keys(e).forEach((i) => {
          ((e[i] = f({}, e[i], t[i])), delete t[i]);
        }),
        this._instance.register({ [Ot]: f({}, e, t) }),
        i && this._instance.reloadFeatureFlags());
    }
    resetGroupPropertiesForFlags(t) {
      if (t) {
        var i = this._instance.get_property(Ot) || {};
        this._instance.register({ [Ot]: f({}, i, { [t]: {} }) });
      } else this._instance.unregister(Ot);
    }
    reset() {
      ((this.we = !1),
        (this.Se = !1),
        (this.$e = !1),
        (this.xe = !1),
        (this.ke = !1),
        (this.Ee = !1),
        (this.$anon_distinct_id = void 0),
        this.Re(),
        (this.ye = !1));
    }
  }
  var mo = [
    "cookie",
    "localstorage",
    "localstorage+cookie",
    "sessionstorage",
    "memory",
  ];
  class bo {
    constructor(t, i) {
      ((this.A = t),
        (this.props = {}),
        (this.Oe = !1),
        (this.Ae = ((t) => {
          var i = "";
          return (
            t.token &&
              (i = t.token
                .replace(/\+/g, "PL")
                .replace(/\//g, "SL")
                .replace(/=/g, "EQ")),
            t.persistence_name
              ? "ph_" + t.persistence_name
              : "ph_" + i + "_posthog"
          );
        })(t)),
        (this.it = this.De(t)),
        this.load(),
        t.debug &&
          q.info("Persistence loaded", t.persistence, f({}, this.props)),
        this.update_config(t, t, i),
        this.save());
    }
    isDisabled() {
      return !!this.je;
    }
    De(t) {
      -1 === mo.indexOf(t.persistence.toLowerCase()) &&
        (q.critical(
          "Unknown persistence type " +
            t.persistence +
            "; falling back to localStorage+cookie",
        ),
        (t.persistence = "localStorage+cookie"));
      var i = t.persistence.toLowerCase();
      return "localstorage" === i && Xi.G()
        ? Xi
        : "localstorage+cookie" === i && Zi.G()
          ? Zi
          : "sessionstorage" === i && re.G()
            ? re
            : "memory" === i
              ? ie
              : "cookie" === i
                ? Ki
                : Zi.G()
                  ? Zi
                  : Ki;
    }
    properties() {
      var t = {};
      return (
        K(this.props, function (i, e) {
          if (e === Tt && E(i))
            for (var r = Object.keys(i), n = 0; n < r.length; n++)
              t["$feature/" + r[n]] = i[r[n]];
          else
            ((a = e),
              (l = !1),
              (C((o = Jt))
                ? l
                : s && o.indexOf === s
                  ? -1 != o.indexOf(a)
                  : (K(o, function (t) {
                      if (l || (l = t === a)) return J;
                    }),
                    l)) || (t[e] = i));
          var o, a, l;
        }),
        t
      );
    }
    load() {
      if (!this.je) {
        var t = this.it.K(this.Ae);
        t && (this.props = Y({}, t));
      }
    }
    save() {
      this.je ||
        this.it.Y(this.Ae, this.props, this.Le, this.Ne, this.ze, this.A.debug);
    }
    remove() {
      (this.it.X(this.Ae, !1), this.it.X(this.Ae, !0));
    }
    clear() {
      (this.remove(), (this.props = {}));
    }
    register_once(t, i, e) {
      if (E(t)) {
        (P(i) && (i = "None"), (this.Le = P(e) ? this.Ue : e));
        var r = !1;
        if (
          (K(t, (t, e) => {
            (this.props.hasOwnProperty(e) && this.props[e] !== i) ||
              ((this.props[e] = t), (r = !0));
          }),
          r)
        )
          return (this.save(), !0);
      }
      return !1;
    }
    register(t, i) {
      if (E(t)) {
        this.Le = P(i) ? this.Ue : i;
        var e = !1;
        if (
          (K(t, (i, r) => {
            t.hasOwnProperty(r) &&
              this.props[r] !== i &&
              ((this.props[r] = i), (e = !0));
          }),
          e)
        )
          return (this.save(), !0);
      }
      return !1;
    }
    unregister(t) {
      t in this.props && (delete this.props[t], this.save());
    }
    update_campaign_params() {
      if (!this.Oe) {
        var t = Xn(
          this.A.custom_campaign_params,
          this.A.mask_personal_data_properties,
          this.A.custom_personal_data_properties,
        );
        (I(it(t)) || this.register(t), (this.Oe = !0));
      }
    }
    update_search_keyword() {
      var t;
      this.register((t = null == o ? void 0 : o.referrer) ? Zn(t) : {});
    }
    update_referrer_info() {
      var t;
      this.register_once(
        {
          $referrer: io(),
          $referring_domain:
            (null != o &&
              o.referrer &&
              (null == (t = Ii(o.referrer)) ? void 0 : t.host)) ||
            "$direct",
        },
        void 0,
      );
    }
    set_initial_person_info() {
      this.props[Ut] ||
        this.props[Bt] ||
        this.register_once(
          {
            [qt]: eo(
              this.A.mask_personal_data_properties,
              this.A.custom_personal_data_properties,
            ),
          },
          void 0,
        );
    }
    get_initial_props() {
      var t = {};
      K([Bt, Ut], (i) => {
        var e = this.props[i];
        e &&
          K(e, function (i, e) {
            t["$initial_" + b(e)] = i;
          });
      });
      var i,
        e,
        r = this.props[qt];
      if (r) {
        var s =
          ((i = ro(r)),
          (e = {}),
          K(i, function (t, i) {
            e["$initial_" + b(i)] = t;
          }),
          e);
        Y(t, s);
      }
      return t;
    }
    safe_merge(t) {
      return (
        K(this.props, function (i, e) {
          e in t || (t[e] = i);
        }),
        t
      );
    }
    update_config(t, i, e) {
      if (
        ((this.Ue = this.Le = t.cookie_expiration),
        this.set_disabled(t.disable_persistence || !!e),
        this.set_cross_subdomain(t.cross_subdomain_cookie),
        this.set_secure(t.secure_cookie),
        t.persistence !== i.persistence)
      ) {
        var r = this.De(t),
          s = this.props;
        (this.clear(), (this.it = r), (this.props = s), this.save());
      }
    }
    set_disabled(t) {
      ((this.je = t), this.je ? this.remove() : this.save());
    }
    set_cross_subdomain(t) {
      t !== this.Ne && ((this.Ne = t), this.remove(), this.save());
    }
    set_secure(t) {
      t !== this.ze && ((this.ze = t), this.remove(), this.save());
    }
    set_event_timer(t, i) {
      var e = this.props[ht] || {};
      ((e[t] = i), (this.props[ht] = e), this.save());
    }
    remove_event_timer(t) {
      var i = (this.props[ht] || {})[t];
      return (P(i) || (delete this.props[ht][t], this.save()), i);
    }
    get_property(t) {
      return this.props[t];
    }
    set_property(t, i) {
      ((this.props[t] = i), this.save());
    }
  }
  class yo {
    constructor() {
      ((this.Be = {}), (this.Be = {}));
    }
    on(t, i) {
      return (
        this.Be[t] || (this.Be[t] = []),
        this.Be[t].push(i),
        () => {
          this.Be[t] = this.Be[t].filter((t) => t !== i);
        }
      );
    }
    emit(t, i) {
      for (var e of this.Be[t] || []) e(i);
      for (var r of this.Be["*"] || []) r(t, i);
    }
  }
  class wo {
    constructor(t) {
      ((this.qe = new yo()),
        (this.He = (t, i) => this.We(t, i) && this.Ge(t, i) && this.Je(t, i)),
        (this.We = (t, i) =>
          null == i ||
          !i.event ||
          (null == t ? void 0 : t.event) === (null == i ? void 0 : i.event)),
        (this._instance = t),
        (this.Ve = new Set()),
        (this.Ke = new Set()));
    }
    init() {
      var t;
      if (!P(null == (t = this._instance) ? void 0 : t.Ye)) {
        var i;
        null == (i = this._instance) ||
          i.Ye((t, i) => {
            this.on(t, i);
          });
      }
    }
    register(t) {
      var i, e;
      if (
        !P(null == (i = this._instance) ? void 0 : i.Ye) &&
        (t.forEach((t) => {
          var i, e;
          (null == (i = this.Ke) || i.add(t),
            null == (e = t.steps) ||
              e.forEach((t) => {
                var i;
                null == (i = this.Ve) ||
                  i.add((null == t ? void 0 : t.event) || "");
              }));
        }),
        null != (e = this._instance) && e.autocapture)
      ) {
        var r,
          s = new Set();
        (t.forEach((t) => {
          var i;
          null == (i = t.steps) ||
            i.forEach((t) => {
              null != t && t.selector && s.add(null == t ? void 0 : t.selector);
            });
        }),
          null == (r = this._instance) || r.autocapture.setElementSelectors(s));
      }
    }
    on(t, i) {
      var e;
      null != i &&
        0 != t.length &&
        (this.Ve.has(t) || this.Ve.has(null == i ? void 0 : i.event)) &&
        this.Ke &&
        (null == (e = this.Ke) ? void 0 : e.size) > 0 &&
        this.Ke.forEach((t) => {
          this.Xe(i, t) && this.qe.emit("actionCaptured", t.name);
        });
    }
    Qe(t) {
      this.onAction("actionCaptured", (i) => t(i));
    }
    Xe(t, i) {
      if (null == (null == i ? void 0 : i.steps)) return !1;
      for (var e of i.steps) if (this.He(t, e)) return !0;
      return !1;
    }
    onAction(t, i) {
      return this.qe.on(t, i);
    }
    Ge(t, i) {
      if (null != i && i.url) {
        var e,
          r = null == t || null == (e = t.properties) ? void 0 : e.$current_url;
        if (!r || "string" != typeof r) return !1;
        if (
          !wo.Ze(
            r,
            null == i ? void 0 : i.url,
            (null == i ? void 0 : i.url_matching) || "contains",
          )
        )
          return !1;
      }
      return !0;
    }
    static Ze(i, e, r) {
      switch (r) {
        case "regex":
          return !!t && qs(i, e);
        case "exact":
          return e === i;
        case "contains":
          var s = wo.tr(e).replace(/_/g, ".").replace(/%/g, ".*");
          return qs(i, s);
        default:
          return !1;
      }
    }
    static tr(t) {
      return t.replace(/[|\\{}()[\]^$+*?.]/g, "\\$&").replace(/-/g, "\\x2d");
    }
    Je(t, i) {
      if (
        ((null != i && i.href) ||
          (null != i && i.tag_name) ||
          (null != i && i.text)) &&
        !this.ir(t).some(
          (t) =>
            !(
              null != i &&
              i.href &&
              !wo.Ze(
                t.href || "",
                null == i ? void 0 : i.href,
                (null == i ? void 0 : i.href_matching) || "exact",
              )
            ) &&
            (null == i ||
              !i.tag_name ||
              t.tag_name === (null == i ? void 0 : i.tag_name)) &&
            !(
              null != i &&
              i.text &&
              !wo.Ze(
                t.text || "",
                null == i ? void 0 : i.text,
                (null == i ? void 0 : i.text_matching) || "exact",
              ) &&
              !wo.Ze(
                t.$el_text || "",
                null == i ? void 0 : i.text,
                (null == i ? void 0 : i.text_matching) || "exact",
              )
            ),
        )
      )
        return !1;
      if (null != i && i.selector) {
        var e,
          r =
            null == t || null == (e = t.properties)
              ? void 0
              : e.$element_selectors;
        if (!r) return !1;
        if (!r.includes(null == i ? void 0 : i.selector)) return !1;
      }
      return !0;
    }
    ir(t) {
      return null == (null == t ? void 0 : t.properties.$elements)
        ? []
        : null == t
          ? void 0
          : t.properties.$elements;
    }
  }
  var So = (function (t) {
      return (
        (t.Popover = "popover"),
        (t.API = "api"),
        (t.Widget = "widget"),
        (t.ExternalSurvey = "external_survey"),
        t
      );
    })({}),
    $o = (function (t) {
      return (
        (t.SHOWN = "survey shown"),
        (t.DISMISSED = "survey dismissed"),
        (t.SENT = "survey sent"),
        t
      );
    })({}),
    xo = (function (t) {
      return (
        (t.SURVEY_ID = "$survey_id"),
        (t.SURVEY_NAME = "$survey_name"),
        (t.SURVEY_RESPONSE = "$survey_response"),
        (t.SURVEY_ITERATION = "$survey_iteration"),
        (t.SURVEY_ITERATION_START_DATE = "$survey_iteration_start_date"),
        (t.SURVEY_PARTIALLY_COMPLETED = "$survey_partially_completed"),
        (t.SURVEY_SUBMISSION_ID = "$survey_submission_id"),
        (t.SURVEY_QUESTIONS = "$survey_questions"),
        (t.SURVEY_COMPLETED = "$survey_completed"),
        t
      );
    })({}),
    ko = H("[Surveys]");
  var Eo = "seenSurvey_",
    Io = (t, i) => {
      var e = "$survey_" + i + "/" + t.id;
      return (
        t.current_iteration &&
          t.current_iteration > 0 &&
          (e = "$survey_" + i + "/" + t.id + "/" + t.current_iteration),
        e
      );
    },
    Po = (t) => {
      var i = "" + Eo + t.id;
      return (
        t.current_iteration &&
          t.current_iteration > 0 &&
          (i = "" + Eo + t.id + "_" + t.current_iteration),
        i
      );
    },
    Ro = [So.Popover, So.Widget, So.API];
  class To {
    constructor(t) {
      ((this._instance = t), (this.er = new Map()), (this.rr = new Map()));
    }
    register(t) {
      var i;
      P(null == (i = this._instance) ? void 0 : i.Ye) ||
        (this.sr(t), this.nr(t));
    }
    nr(t) {
      var i = t.filter((t) => {
        var i, e;
        return (
          (null == (i = t.conditions) ? void 0 : i.actions) &&
          (null == (e = t.conditions) ||
          null == (e = e.actions) ||
          null == (e = e.values)
            ? void 0
            : e.length) > 0
        );
      });
      if (0 !== i.length) {
        if (null == this.ar) {
          ((this.ar = new wo(this._instance)), this.ar.init());
          this.ar.Qe((t) => {
            this.onAction(t);
          });
        }
        i.forEach((t) => {
          var i, e, r, s, n;
          t.conditions &&
            null != (i = t.conditions) &&
            i.actions &&
            null != (e = t.conditions) &&
            null != (e = e.actions) &&
            e.values &&
            (null == (r = t.conditions) ||
            null == (r = r.actions) ||
            null == (r = r.values)
              ? void 0
              : r.length) > 0 &&
            (null == (s = this.ar) || s.register(t.conditions.actions.values),
            null == (n = t.conditions) ||
              null == (n = n.actions) ||
              null == (n = n.values) ||
              n.forEach((i) => {
                if (i && i.name) {
                  var e = this.rr.get(i.name);
                  (e && e.push(t.id), this.rr.set(i.name, e || [t.id]));
                }
              }));
        });
      }
    }
    sr(t) {
      var i;
      if (
        0 !==
        t.filter((t) => {
          var i, e;
          return (
            (null == (i = t.conditions) ? void 0 : i.events) &&
            (null == (e = t.conditions) ||
            null == (e = e.events) ||
            null == (e = e.values)
              ? void 0
              : e.length) > 0
          );
        }).length
      ) {
        (null == (i = this._instance) ||
          i.Ye((t, i) => {
            this.onEvent(t, i);
          }),
          t.forEach((t) => {
            var i;
            null == (i = t.conditions) ||
              null == (i = i.events) ||
              null == (i = i.values) ||
              i.forEach((i) => {
                if (i && i.name) {
                  var e = this.er.get(i.name);
                  (e && e.push(t.id), this.er.set(i.name, e || [t.id]));
                }
              });
          }));
      }
    }
    onEvent(t, i) {
      var e,
        r =
          (null == (e = this._instance) || null == (e = e.persistence)
            ? void 0
            : e.props[Dt]) || [];
      if ("survey shown" === t && i && r.length > 0) {
        var s;
        ko.info(
          "survey event matched, removing survey from activated surveys",
          { event: t, eventPayload: i, existingActivatedSurveys: r },
        );
        var n = null == i || null == (s = i.properties) ? void 0 : s.$survey_id;
        if (n) {
          var o = r.indexOf(n);
          o >= 0 && (r.splice(o, 1), this.lr(r));
        }
      } else
        this.er.has(t) &&
          (ko.info("survey event matched, updating activated surveys", {
            event: t,
            surveys: this.er.get(t),
          }),
          this.lr(r.concat(this.er.get(t) || [])));
    }
    onAction(t) {
      var i,
        e =
          (null == (i = this._instance) || null == (i = i.persistence)
            ? void 0
            : i.props[Dt]) || [];
      this.rr.has(t) && this.lr(e.concat(this.rr.get(t) || []));
    }
    lr(t) {
      var i;
      null == (i = this._instance) ||
        null == (i = i.persistence) ||
        i.register({ [Dt]: [...new Set(t)] });
    }
    getSurveys() {
      var t,
        i =
          null == (t = this._instance) || null == (t = t.persistence)
            ? void 0
            : t.props[Dt];
      return i || [];
    }
    getEventToSurveys() {
      return this.er;
    }
    hr() {
      return this.ar;
    }
  }
  class Co {
    constructor(t) {
      ((this.ur = void 0),
        (this._surveyManager = null),
        (this.dr = !1),
        (this.vr = !1),
        (this.cr = []),
        (this._instance = t),
        (this._surveyEventReceiver = null));
    }
    onRemoteConfig(t) {
      var i = t.surveys;
      if (M(i)) return ko.warn("Flags not loaded yet. Not loading surveys.");
      var e = x(i);
      ((this.ur = e ? i.length > 0 : i),
        ko.info("flags response received, isSurveysEnabled: " + this.ur),
        this.loadIfEnabled());
    }
    reset() {
      localStorage.removeItem("lastSeenSurveyDate");
      for (var t = [], i = 0; i < localStorage.length; i++) {
        var e = localStorage.key(i);
        ((null != e && e.startsWith(Eo)) ||
          (null != e && e.startsWith("inProgressSurvey_"))) &&
          t.push(e);
      }
      t.forEach((t) => localStorage.removeItem(t));
    }
    loadIfEnabled() {
      if (!this._surveyManager)
        if (this.vr) ko.info("Already initializing surveys, skipping...");
        else if (this._instance.config.disable_surveys)
          ko.info("Disabled. Not loading surveys.");
        else if (this._instance.config.cookieless_mode)
          ko.info("Not loading surveys in cookieless mode.");
        else {
          var t = null == v ? void 0 : v.__PosthogExtensions__;
          if (t) {
            if (!P(this.ur) || this._instance.config.advanced_enable_surveys) {
              var i = this.ur || this._instance.config.advanced_enable_surveys;
              this.vr = !0;
              try {
                var e = t.generateSurveys;
                if (e) return void this.pr(e, i);
                var r = t.loadExternalDependency;
                if (!r)
                  return void this.gr(
                    "PostHog loadExternalDependency extension not found.",
                  );
                r(this._instance, "surveys", (e) => {
                  e || !t.generateSurveys
                    ? this.gr("Could not load surveys script", e)
                    : this.pr(t.generateSurveys, i);
                });
              } catch (t) {
                throw (this.gr("Error initializing surveys", t), t);
              } finally {
                this.vr = !1;
              }
            }
          } else ko.error("PostHog Extensions not found.");
        }
    }
    pr(t, i) {
      ((this._surveyManager = t(this._instance, i)),
        (this._surveyEventReceiver = new To(this._instance)),
        ko.info("Surveys loaded successfully"),
        this._r({ isLoaded: !0 }));
    }
    gr(t, i) {
      (ko.error(t, i), this._r({ isLoaded: !1, error: t }));
    }
    onSurveysLoaded(t) {
      return (
        this.cr.push(t),
        this._surveyManager && this._r({ isLoaded: !0 }),
        () => {
          this.cr = this.cr.filter((i) => i !== t);
        }
      );
    }
    getSurveys(t, i) {
      if ((void 0 === i && (i = !1), this._instance.config.disable_surveys))
        return (ko.info("Disabled. Not loading surveys."), t([]));
      var e = this._instance.get_property(At);
      if (e && !i) return t(e, { isLoaded: !0 });
      if (this.dr)
        return t([], {
          isLoaded: !1,
          error: "Surveys are already being loaded",
        });
      try {
        ((this.dr = !0),
          this._instance.Te({
            url: this._instance.requestRouter.endpointFor(
              "api",
              "/api/surveys/?token=" + this._instance.config.token,
            ),
            method: "GET",
            timeout: this._instance.config.surveys_request_timeout_ms,
            callback: (i) => {
              var e;
              this.dr = !1;
              var r = i.statusCode;
              if (200 !== r || !i.json) {
                var s = "Surveys API could not be loaded, status: " + r;
                return (ko.error(s), t([], { isLoaded: !1, error: s }));
              }
              var n,
                o = i.json.surveys || [],
                a = o.filter(
                  (t) =>
                    (function (t) {
                      return !(!t.start_date || t.end_date);
                    })(t) &&
                    ((function (t) {
                      var i;
                      return !(
                        null == (i = t.conditions) ||
                        null == (i = i.events) ||
                        null == (i = i.values) ||
                        !i.length
                      );
                    })(t) ||
                      (function (t) {
                        var i;
                        return !(
                          null == (i = t.conditions) ||
                          null == (i = i.actions) ||
                          null == (i = i.values) ||
                          !i.length
                        );
                      })(t)),
                );
              a.length > 0 &&
                (null == (n = this._surveyEventReceiver) || n.register(a));
              return (
                null == (e = this._instance.persistence) ||
                  e.register({ [At]: o }),
                t(o, { isLoaded: !0 })
              );
            },
          }));
      } catch (t) {
        throw ((this.dr = !1), t);
      }
    }
    _r(t) {
      for (var i of this.cr)
        try {
          if (!t.isLoaded) return i([], t);
          this.getSurveys(i);
        } catch (t) {
          ko.error("Error in survey callback", t);
        }
    }
    getActiveMatchingSurveys(t, i) {
      if ((void 0 === i && (i = !1), !M(this._surveyManager)))
        return this._surveyManager.getActiveMatchingSurveys(t, i);
      ko.warn("init was not called");
    }
    mr(t) {
      var i = null;
      return (
        this.getSurveys((e) => {
          var r;
          i =
            null !== (r = e.find((i) => i.id === t)) && void 0 !== r ? r : null;
        }),
        i
      );
    }
    br(t) {
      if (M(this._surveyManager))
        return {
          eligible: !1,
          reason:
            "SDK is not enabled or survey functionality is not yet loaded",
        };
      var i = "string" == typeof t ? this.mr(t) : t;
      return i
        ? this._surveyManager.checkSurveyEligibility(i)
        : { eligible: !1, reason: "Survey not found" };
    }
    canRenderSurvey(t) {
      if (M(this._surveyManager))
        return (
          ko.warn("init was not called"),
          {
            visible: !1,
            disabledReason:
              "SDK is not enabled or survey functionality is not yet loaded",
          }
        );
      var i = this.br(t);
      return { visible: i.eligible, disabledReason: i.reason };
    }
    canRenderSurveyAsync(t, i) {
      return M(this._surveyManager)
        ? (ko.warn("init was not called"),
          Promise.resolve({
            visible: !1,
            disabledReason:
              "SDK is not enabled or survey functionality is not yet loaded",
          }))
        : new Promise((e) => {
            this.getSurveys((i) => {
              var r,
                s =
                  null !== (r = i.find((i) => i.id === t)) && void 0 !== r
                    ? r
                    : null;
              if (s) {
                var n = this.br(s);
                e({ visible: n.eligible, disabledReason: n.reason });
              } else e({ visible: !1, disabledReason: "Survey not found" });
            }, i);
          });
    }
    renderSurvey(t, i) {
      if (M(this._surveyManager)) ko.warn("init was not called");
      else {
        var e = this.mr(t);
        if (e)
          if (Ro.includes(e.type)) {
            var r = null == o ? void 0 : o.querySelector(i);
            r
              ? this._surveyManager.renderSurvey(e, r)
              : ko.warn("Survey element not found");
          } else
            ko.warn(
              "Surveys of type " + e.type + " cannot be rendered in the app",
            );
        else ko.warn("Survey not found");
      }
    }
  }
  var Mo = H("[RateLimiter]");
  class Fo {
    constructor(t) {
      var i, e;
      ((this.serverLimits = {}),
        (this.lastEventRateLimited = !1),
        (this.checkForLimiting = (t) => {
          var i = t.text;
          if (i && i.length)
            try {
              (JSON.parse(i).quota_limited || []).forEach((t) => {
                (Mo.info((t || "events") + " is quota limited."),
                  (this.serverLimits[t] = new Date().getTime() + 6e4));
              });
            } catch (t) {
              return void Mo.warn(
                'could not rate limit - continuing. Error: "' +
                  (null == t ? void 0 : t.message) +
                  '"',
                { text: i },
              );
            }
        }),
        (this.instance = t),
        (this.captureEventsPerSecond =
          (null == (i = t.config.rate_limiting)
            ? void 0
            : i.events_per_second) || 10),
        (this.captureEventsBurstLimit = Math.max(
          (null == (e = t.config.rate_limiting)
            ? void 0
            : e.events_burst_limit) || 10 * this.captureEventsPerSecond,
          this.captureEventsPerSecond,
        )),
        (this.lastEventRateLimited =
          this.clientRateLimitContext(!0).isRateLimited));
    }
    clientRateLimitContext(t) {
      var i, e, r;
      void 0 === t && (t = !1);
      var s = new Date().getTime(),
        n =
          null !==
            (i =
              null == (e = this.instance.persistence)
                ? void 0
                : e.get_property(zt)) && void 0 !== i
            ? i
            : { tokens: this.captureEventsBurstLimit, last: s };
      ((n.tokens += ((s - n.last) / 1e3) * this.captureEventsPerSecond),
        (n.last = s),
        n.tokens > this.captureEventsBurstLimit &&
          (n.tokens = this.captureEventsBurstLimit));
      var o = n.tokens < 1;
      return (
        o || t || (n.tokens = Math.max(0, n.tokens - 1)),
        !o ||
          this.lastEventRateLimited ||
          t ||
          this.instance.capture(
            "$$client_ingestion_warning",
            {
              $$client_ingestion_warning_message:
                "posthog-js client rate limited. Config is set to " +
                this.captureEventsPerSecond +
                " events per second and " +
                this.captureEventsBurstLimit +
                " events burst limit.",
            },
            { skip_client_rate_limiting: !0 },
          ),
        (this.lastEventRateLimited = o),
        null == (r = this.instance.persistence) || r.set_property(zt, n),
        { isRateLimited: o, remainingTokens: n.tokens }
      );
    }
    isServerRateLimited(t) {
      var i = this.serverLimits[t || "events"] || !1;
      return !1 !== i && new Date().getTime() < i;
    }
  }
  var Oo = H("[RemoteConfig]");
  class Ao {
    constructor(t) {
      this._instance = t;
    }
    get remoteConfig() {
      var t;
      return null == (t = v._POSTHOG_REMOTE_CONFIG) ||
        null == (t = t[this._instance.config.token])
        ? void 0
        : t.config;
    }
    yr(t) {
      var i, e;
      null != (i = v.__PosthogExtensions__) && i.loadExternalDependency
        ? null == (e = v.__PosthogExtensions__) ||
          null == e.loadExternalDependency ||
          e.loadExternalDependency(this._instance, "remote-config", () =>
            t(this.remoteConfig),
          )
        : (Oo.error("PostHog Extensions not found. Cannot load remote config."),
          t());
    }
    wr(t) {
      this._instance.Te({
        method: "GET",
        url: this._instance.requestRouter.endpointFor(
          "assets",
          "/array/" + this._instance.config.token + "/config",
        ),
        callback: (i) => {
          t(i.json);
        },
      });
    }
    load() {
      try {
        if (this.remoteConfig)
          return (
            Oo.info("Using preloaded remote config", this.remoteConfig),
            void this.Ce(this.remoteConfig)
          );
        if (this._instance.L())
          return void Oo.warn(
            "Remote config is disabled. Falling back to local config.",
          );
        this.yr((t) => {
          if (!t)
            return (
              Oo.info(
                "No config found after loading remote JS config. Falling back to JSON.",
              ),
              void this.wr((t) => {
                this.Ce(t);
              })
            );
          this.Ce(t);
        });
      } catch (t) {
        Oo.error("Error loading remote config", t);
      }
    }
    Ce(t) {
      t
        ? this._instance.config.__preview_remote_config
          ? (this._instance.Ce(t),
            !1 !== t.hasFeatureFlags &&
              this._instance.featureFlags.ensureFlagsLoaded())
          : Oo.info(
              "__preview_remote_config is disabled. Logging config instead",
              t,
            )
        : Oo.error("Failed to fetch remote config from PostHog.");
    }
  }
  var Do = 3e3;
  class jo {
    constructor(t, i) {
      ((this.Sr = !0),
        (this.$r = []),
        (this.kr = z(
          (null == i ? void 0 : i.flush_interval_ms) || Do,
          250,
          5e3,
          q.createLogger("flush interval"),
          Do,
        )),
        (this.Er = t));
    }
    enqueue(t) {
      (this.$r.push(t), this.Ir || this.Pr());
    }
    unload() {
      this.Rr();
      var t = this.$r.length > 0 ? this.Tr() : {},
        i = Object.values(t);
      [
        ...i.filter((t) => 0 === t.url.indexOf("/e")),
        ...i.filter((t) => 0 !== t.url.indexOf("/e")),
      ].map((t) => {
        this.Er(f({}, t, { transport: "sendBeacon" }));
      });
    }
    enable() {
      ((this.Sr = !1), this.Pr());
    }
    Pr() {
      var t = this;
      this.Sr ||
        (this.Ir = setTimeout(() => {
          if ((this.Rr(), this.$r.length > 0)) {
            var i = this.Tr(),
              e = function () {
                var e = i[r],
                  s = new Date().getTime();
                (e.data &&
                  x(e.data) &&
                  K(e.data, (t) => {
                    ((t.offset = Math.abs(t.timestamp - s)),
                      delete t.timestamp);
                  }),
                  t.Er(e));
              };
            for (var r in i) e();
          }
        }, this.kr));
    }
    Rr() {
      (clearTimeout(this.Ir), (this.Ir = void 0));
    }
    Tr() {
      var t = {};
      return (
        K(this.$r, (i) => {
          var e,
            r = i,
            s = (r ? r.batchKey : null) || r.url;
          (P(t[s]) && (t[s] = f({}, r, { data: [] })),
            null == (e = t[s].data) || e.push(r.data));
        }),
        (this.$r = []),
        t
      );
    }
  }
  var Lo = ["retriesPerformedSoFar"];
  class No {
    constructor(i) {
      ((this.Cr = !1),
        (this.Mr = 3e3),
        (this.$r = []),
        (this._instance = i),
        (this.$r = []),
        (this.Fr = !0),
        !P(t) &&
          "onLine" in t.navigator &&
          ((this.Fr = t.navigator.onLine),
          ot(t, "online", () => {
            ((this.Fr = !0), this.oe());
          }),
          ot(t, "offline", () => {
            this.Fr = !1;
          })));
    }
    get length() {
      return this.$r.length;
    }
    retriableRequest(t) {
      var { retriesPerformedSoFar: i } = t,
        e = p(t, Lo);
      (F(i) && i > 0 && (e.url = Ns(e.url, { retry_count: i })),
        this._instance.Te(
          f({}, e, {
            callback: (t) => {
              200 !== t.statusCode &&
              (t.statusCode < 400 || t.statusCode >= 500) &&
              (null != i ? i : 0) < 10
                ? this.Or(f({ retriesPerformedSoFar: i }, e))
                : null == e.callback || e.callback(t);
            },
          }),
        ));
    }
    Or(t) {
      var i = t.retriesPerformedSoFar || 0;
      t.retriesPerformedSoFar = i + 1;
      var e = (function (t) {
          var i = 3e3 * Math.pow(2, t),
            e = i / 2,
            r = Math.min(18e5, i),
            s = (Math.random() - 0.5) * (r - e);
          return Math.ceil(r + s);
        })(i),
        r = Date.now() + e;
      this.$r.push({ retryAt: r, requestOptions: t });
      var s = "Enqueued failed request for retry in " + e;
      (navigator.onLine || (s += " (Browser is offline)"),
        q.warn(s),
        this.Cr || ((this.Cr = !0), this.Ar()));
    }
    Ar() {
      (this.Dr && clearTimeout(this.Dr),
        (this.Dr = setTimeout(() => {
          (this.Fr && this.$r.length > 0 && this.oe(), this.Ar());
        }, this.Mr)));
    }
    oe() {
      var t = Date.now(),
        i = [],
        e = this.$r.filter((e) => e.retryAt < t || (i.push(e), !1));
      if (((this.$r = i), e.length > 0))
        for (var { requestOptions: r } of e) this.retriableRequest(r);
    }
    unload() {
      for (var { requestOptions: t } of (this.Dr &&
        (clearTimeout(this.Dr), (this.Dr = void 0)),
      this.$r))
        try {
          this._instance.Te(f({}, t, { transport: "sendBeacon" }));
        } catch (t) {
          q.error(t);
        }
      this.$r = [];
    }
  }
  class zo {
    constructor(t) {
      ((this.jr = () => {
        var t, i, e, r;
        this.Lr || (this.Lr = {});
        var s = this.scrollElement(),
          n = this.scrollY(),
          o = s ? Math.max(0, s.scrollHeight - s.clientHeight) : 0,
          a = n + ((null == s ? void 0 : s.clientHeight) || 0),
          l = (null == s ? void 0 : s.scrollHeight) || 0;
        ((this.Lr.lastScrollY = Math.ceil(n)),
          (this.Lr.maxScrollY = Math.max(
            n,
            null !== (t = this.Lr.maxScrollY) && void 0 !== t ? t : 0,
          )),
          (this.Lr.maxScrollHeight = Math.max(
            o,
            null !== (i = this.Lr.maxScrollHeight) && void 0 !== i ? i : 0,
          )),
          (this.Lr.lastContentY = a),
          (this.Lr.maxContentY = Math.max(
            a,
            null !== (e = this.Lr.maxContentY) && void 0 !== e ? e : 0,
          )),
          (this.Lr.maxContentHeight = Math.max(
            l,
            null !== (r = this.Lr.maxContentHeight) && void 0 !== r ? r : 0,
          )));
      }),
        (this._instance = t));
    }
    getContext() {
      return this.Lr;
    }
    resetContext() {
      var t = this.Lr;
      return (setTimeout(this.jr, 0), t);
    }
    startMeasuringScrollPosition() {
      (ot(t, "scroll", this.jr, { capture: !0 }),
        ot(t, "scrollend", this.jr, { capture: !0 }),
        ot(t, "resize", this.jr));
    }
    scrollElement() {
      if (!this._instance.config.scroll_root_selector)
        return null == t ? void 0 : t.document.documentElement;
      var i = x(this._instance.config.scroll_root_selector)
        ? this._instance.config.scroll_root_selector
        : [this._instance.config.scroll_root_selector];
      for (var e of i) {
        var r = null == t ? void 0 : t.document.querySelector(e);
        if (r) return r;
      }
    }
    scrollY() {
      if (this._instance.config.scroll_root_selector) {
        var i = this.scrollElement();
        return (i && i.scrollTop) || 0;
      }
      return (
        (t &&
          (t.scrollY ||
            t.pageYOffset ||
            t.document.documentElement.scrollTop)) ||
        0
      );
    }
    scrollX() {
      if (this._instance.config.scroll_root_selector) {
        var i = this.scrollElement();
        return (i && i.scrollLeft) || 0;
      }
      return (
        (t &&
          (t.scrollX ||
            t.pageXOffset ||
            t.document.documentElement.scrollLeft)) ||
        0
      );
    }
  }
  var Uo = (t) =>
    eo(
      null == t ? void 0 : t.config.mask_personal_data_properties,
      null == t ? void 0 : t.config.custom_personal_data_properties,
    );
  class Bo {
    constructor(t, i, e, r) {
      ((this.Nr = (t) => {
        var i = this.zr();
        if (!i || i.sessionId !== t) {
          var e = { sessionId: t, props: this.Ur(this._instance) };
          this.Br.register({ [Nt]: e });
        }
      }),
        (this._instance = t),
        (this.qr = i),
        (this.Br = e),
        (this.Ur = r || Uo),
        this.qr.onSessionId(this.Nr));
    }
    zr() {
      return this.Br.props[Nt];
    }
    getSetOnceProps() {
      var t,
        i = null == (t = this.zr()) ? void 0 : t.props;
      return i
        ? "r" in i
          ? ro(i)
          : {
              $referring_domain: i.referringDomain,
              $pathname: i.initialPathName,
              utm_source: i.utm_source,
              utm_campaign: i.utm_campaign,
              utm_medium: i.utm_medium,
              utm_content: i.utm_content,
              utm_term: i.utm_term,
            }
        : {};
    }
    getSessionProps() {
      var t = {};
      return (
        K(it(this.getSetOnceProps()), (i, e) => {
          ("$current_url" === e && (e = "url"),
            (t["$session_entry_" + b(e)] = i));
        }),
        t
      );
    }
  }
  var qo = H("[SessionId]");
  class Ho {
    constructor(t, i, e) {
      var r;
      if (
        ((this.Hr = []),
        (this.Wr = (t, i) => Math.abs(t - i) > this.sessionTimeoutMs),
        !t.persistence)
      )
        throw new Error(
          "SessionIdManager requires a PostHogPersistence instance",
        );
      if ("always" === t.config.cookieless_mode)
        throw new Error(
          'SessionIdManager cannot be used with cookieless_mode="always"',
        );
      ((this.A = t.config),
        (this.Br = t.persistence),
        (this.gi = void 0),
        (this.Ot = void 0),
        (this._sessionStartTimestamp = null),
        (this._sessionActivityTimestamp = null),
        (this.Gr = i || Hi),
        (this.Jr = e || Hi));
      var s = this.A.persistence_name || this.A.token,
        n = this.A.session_idle_timeout_seconds || 1800;
      if (
        ((this._sessionTimeoutMs =
          1e3 *
          z(
            n,
            60,
            36e3,
            qo.createLogger("session_idle_timeout_seconds"),
            1800,
          )),
        t.register({ $configured_session_timeout_ms: this._sessionTimeoutMs }),
        this.Vr(),
        (this.Kr = "ph_" + s + "_window_id"),
        (this.Yr = "ph_" + s + "_primary_window_exists"),
        this.Xr())
      ) {
        var o = re.K(this.Kr),
          a = re.K(this.Yr);
        (o && !a ? (this.gi = o) : re.X(this.Kr), re.Y(this.Yr, !0));
      }
      if (null != (r = this.A.bootstrap) && r.sessionID)
        try {
          var l = ((t) => {
            var i = t.replace(/-/g, "");
            if (32 !== i.length) throw new Error("Not a valid UUID");
            if ("7" !== i[12]) throw new Error("Not a UUIDv7");
            return parseInt(i.substring(0, 12), 16);
          })(this.A.bootstrap.sessionID);
          this.Qr(this.A.bootstrap.sessionID, new Date().getTime(), l);
        } catch (t) {
          qo.error("Invalid sessionID in bootstrap", t);
        }
      this.Zr();
    }
    get sessionTimeoutMs() {
      return this._sessionTimeoutMs;
    }
    onSessionId(t) {
      return (
        P(this.Hr) && (this.Hr = []),
        this.Hr.push(t),
        this.Ot && t(this.Ot, this.gi),
        () => {
          this.Hr = this.Hr.filter((i) => i !== t);
        }
      );
    }
    Xr() {
      return "memory" !== this.A.persistence && !this.Br.je && re.G();
    }
    ts(t) {
      t !== this.gi && ((this.gi = t), this.Xr() && re.Y(this.Kr, t));
    }
    es() {
      return this.gi ? this.gi : this.Xr() ? re.K(this.Kr) : null;
    }
    Qr(t, i, e) {
      (t === this.Ot &&
        i === this._sessionActivityTimestamp &&
        e === this._sessionStartTimestamp) ||
        ((this._sessionStartTimestamp = e),
        (this._sessionActivityTimestamp = i),
        (this.Ot = t),
        this.Br.register({ [Et]: [i, t, e] }));
    }
    rs() {
      if (
        this.Ot &&
        this._sessionActivityTimestamp &&
        this._sessionStartTimestamp
      )
        return [
          this._sessionActivityTimestamp,
          this.Ot,
          this._sessionStartTimestamp,
        ];
      var t = this.Br.props[Et];
      return (x(t) && 2 === t.length && t.push(t[0]), t || [0, null, 0]);
    }
    resetSessionId() {
      this.Qr(null, null, null);
    }
    Zr() {
      ot(
        t,
        "beforeunload",
        () => {
          this.Xr() && re.X(this.Yr);
        },
        { capture: !1 },
      );
    }
    checkAndGetSessionAndWindowId(t, i) {
      if (
        (void 0 === t && (t = !1),
        void 0 === i && (i = null),
        "always" === this.A.cookieless_mode)
      )
        throw new Error(
          'checkAndGetSessionAndWindowId should not be called with cookieless_mode="always"',
        );
      var e = i || new Date().getTime(),
        [r, s, n] = this.rs(),
        o = this.es(),
        a = F(n) && n > 0 && Math.abs(e - n) > 864e5,
        l = !1,
        h = !s,
        u = !t && this.Wr(e, r);
      h || u || a
        ? ((s = this.Gr()),
          (o = this.Jr()),
          qo.info("new session ID generated", {
            sessionId: s,
            windowId: o,
            changeReason: {
              noSessionId: h,
              activityTimeout: u,
              sessionPastMaximumLength: a,
            },
          }),
          (n = e),
          (l = !0))
        : o || ((o = this.Jr()), (l = !0));
      var d = 0 === r || !t || a ? e : r,
        v = 0 === n ? new Date().getTime() : n;
      return (
        this.ts(o),
        this.Qr(s, d, v),
        t || this.Vr(),
        l &&
          this.Hr.forEach((t) =>
            t(
              s,
              o,
              l
                ? {
                    noSessionId: h,
                    activityTimeout: u,
                    sessionPastMaximumLength: a,
                  }
                : void 0,
            ),
          ),
        {
          sessionId: s,
          windowId: o,
          sessionStartTimestamp: v,
          changeReason: l
            ? {
                noSessionId: h,
                activityTimeout: u,
                sessionPastMaximumLength: a,
              }
            : void 0,
          lastActivityTimestamp: r,
        }
      );
    }
    Vr() {
      (clearTimeout(this.ss),
        (this.ss = setTimeout(() => {
          var [t] = this.rs();
          this.Wr(new Date().getTime(), t) && this.resetSessionId();
        }, 1.1 * this.sessionTimeoutMs)));
    }
  }
  var Wo = ["$set_once", "$set"],
    Go = H("[SiteApps]");
  class Jo {
    constructor(t) {
      ((this._instance = t), (this.ns = []), (this.apps = {}));
    }
    get isEnabled() {
      return !!this._instance.config.opt_in_site_apps;
    }
    os(t, i) {
      if (i) {
        var e = this.globalsForEvent(i);
        (this.ns.push(e),
          this.ns.length > 1e3 && (this.ns = this.ns.slice(10)));
      }
    }
    get siteAppLoaders() {
      var t;
      return null == (t = v._POSTHOG_REMOTE_CONFIG) ||
        null == (t = t[this._instance.config.token])
        ? void 0
        : t.siteApps;
    }
    init() {
      if (this.isEnabled) {
        var t = this._instance.Ye(this.os.bind(this));
        this.ls = () => {
          (t(), (this.ns = []), (this.ls = void 0));
        };
      }
    }
    globalsForEvent(t) {
      var i, e, r, s, n, o, a;
      if (!t) throw new Error("Event payload is required");
      var l = {},
        h = this._instance.get_property("$groups") || [],
        u = this._instance.get_property("$stored_group_properties") || {};
      for (var [d, v] of Object.entries(u))
        l[d] = { id: h[d], type: d, properties: v };
      var { $set_once: c, $set: g } = t;
      return {
        event: f({}, p(t, Wo), {
          properties: f(
            {},
            t.properties,
            g
              ? {
                  $set: f(
                    {},
                    null !==
                      (i = null == (e = t.properties) ? void 0 : e.$set) &&
                      void 0 !== i
                      ? i
                      : {},
                    g,
                  ),
                }
              : {},
            c
              ? {
                  $set_once: f(
                    {},
                    null !==
                      (r = null == (s = t.properties) ? void 0 : s.$set_once) &&
                      void 0 !== r
                      ? r
                      : {},
                    c,
                  ),
                }
              : {},
          ),
          elements_chain:
            null !==
              (n = null == (o = t.properties) ? void 0 : o.$elements_chain) &&
            void 0 !== n
              ? n
              : "",
          distinct_id: null == (a = t.properties) ? void 0 : a.distinct_id,
        }),
        person: {
          properties: this._instance.get_property("$stored_person_properties"),
        },
        groups: l,
      };
    }
    setupSiteApp(t) {
      var i = this.apps[t.id],
        e = () => {
          var e;
          (!i.errored &&
            this.ns.length &&
            (Go.info(
              "Processing " +
                this.ns.length +
                " events for site app with id " +
                t.id,
            ),
            this.ns.forEach((t) =>
              null == i.processEvent ? void 0 : i.processEvent(t),
            ),
            (i.processedBuffer = !0)),
          Object.values(this.apps).every(
            (t) => t.processedBuffer || t.errored,
          )) &&
            (null == (e = this.ls) || e.call(this));
        },
        r = !1,
        s = (s) => {
          ((i.errored = !s),
            (i.loaded = !0),
            Go.info(
              "Site app with id " + t.id + " " + (s ? "loaded" : "errored"),
            ),
            r && e());
        };
      try {
        var { processEvent: n } = t.init({
          posthog: this._instance,
          callback: (t) => {
            s(t);
          },
        });
        (n && (i.processEvent = n), (r = !0));
      } catch (i) {
        (Go.error(
          "Error while initializing PostHog app with config id " + t.id,
          i,
        ),
          s(!1));
      }
      if (r && i.loaded)
        try {
          e();
        } catch (e) {
          (Go.error(
            "Error while processing buffered events PostHog app with config id " +
              t.id,
            e,
          ),
            (i.errored = !0));
        }
    }
    hs() {
      var t = this.siteAppLoaders || [];
      for (var i of t)
        this.apps[i.id] = {
          id: i.id,
          loaded: !1,
          errored: !1,
          processedBuffer: !1,
        };
      for (var e of t) this.setupSiteApp(e);
    }
    us(t) {
      if (0 !== Object.keys(this.apps).length) {
        var i = this.globalsForEvent(t);
        for (var e of Object.values(this.apps))
          try {
            null == e.processEvent || e.processEvent(i);
          } catch (i) {
            Go.error(
              "Error while processing event " +
                t.event +
                " for site app " +
                e.id,
              i,
            );
          }
      }
    }
    onRemoteConfig(t) {
      var i,
        e,
        r,
        s = this;
      if (null != (i = this.siteAppLoaders) && i.length)
        return this.isEnabled
          ? (this.hs(),
            void this._instance.on("eventCaptured", (t) => this.us(t)))
          : void Go.error(
              'PostHog site apps are disabled. Enable the "opt_in_site_apps" config to proceed.',
            );
      if (
        (null == (e = this.ls) || e.call(this),
        null != (r = t.siteApps) && r.length)
      )
        if (this.isEnabled) {
          var n = function (t) {
            var i;
            ((v["__$$ph_site_app_" + t] = s._instance),
              null == (i = v.__PosthogExtensions__) ||
                null == i.loadSiteApp ||
                i.loadSiteApp(s._instance, a, (i) => {
                  if (i)
                    return Go.error(
                      "Error while initializing PostHog app with config id " +
                        t,
                      i,
                    );
                }));
          };
          for (var { id: o, url: a } of t.siteApps) n(o);
        } else
          Go.error(
            'PostHog site apps are disabled. Enable the "opt_in_site_apps" config to proceed.',
          );
    }
  }
  var Vo = [
      "amazonbot",
      "amazonproductbot",
      "app.hypefactors.com",
      "applebot",
      "archive.org_bot",
      "awariobot",
      "backlinksextendedbot",
      "baiduspider",
      "bingbot",
      "bingpreview",
      "chrome-lighthouse",
      "dataforseobot",
      "deepscan",
      "duckduckbot",
      "facebookexternal",
      "facebookcatalog",
      "http://yandex.com/bots",
      "hubspot",
      "ia_archiver",
      "leikibot",
      "linkedinbot",
      "meta-externalagent",
      "mj12bot",
      "msnbot",
      "nessus",
      "petalbot",
      "pinterest",
      "prerender",
      "rogerbot",
      "screaming frog",
      "sebot-wa",
      "sitebulb",
      "slackbot",
      "slurp",
      "trendictionbot",
      "turnitin",
      "twitterbot",
      "vercel-screenshot",
      "vercelbot",
      "yahoo! slurp",
      "yandexbot",
      "zoombot",
      "bot.htm",
      "bot.php",
      "(bot;",
      "bot/",
      "crawler",
      "ahrefsbot",
      "ahrefssiteaudit",
      "semrushbot",
      "siteauditbot",
      "splitsignalbot",
      "gptbot",
      "oai-searchbot",
      "chatgpt-user",
      "perplexitybot",
      "better uptime bot",
      "sentryuptimebot",
      "uptimerobot",
      "headlesschrome",
      "cypress",
      "google-hoteladsverifier",
      "adsbot-google",
      "apis-google",
      "duplexweb-google",
      "feedfetcher-google",
      "google favicon",
      "google web preview",
      "google-read-aloud",
      "googlebot",
      "googleother",
      "google-cloudvertexbot",
      "googleweblight",
      "mediapartners-google",
      "storebot-google",
      "google-inspectiontool",
      "bytespider",
    ],
    Ko = function (t, i) {
      if (!t) return !1;
      var e = t.toLowerCase();
      return Vo.concat(i || []).some((t) => {
        var i = t.toLowerCase();
        return -1 !== e.indexOf(i);
      });
    },
    Yo = function (t, i) {
      if (!t) return !1;
      var e = t.userAgent;
      if (e && Ko(e, i)) return !0;
      try {
        var r = null == t ? void 0 : t.userAgentData;
        if (
          null != r &&
          r.brands &&
          r.brands.some((t) => Ko(null == t ? void 0 : t.brand, i))
        )
          return !0;
      } catch (t) {}
      return !!t.webdriver;
    },
    Xo = (function (t) {
      return ((t.US = "us"), (t.EU = "eu"), (t.CUSTOM = "custom"), t);
    })({}),
    Qo = "i.posthog.com";
  class Zo {
    constructor(t) {
      ((this.ds = {}), (this.instance = t));
    }
    get apiHost() {
      var t = this.instance.config.api_host.trim().replace(/\/$/, "");
      return "https://app.posthog.com" === t ? "https://us.i.posthog.com" : t;
    }
    get uiHost() {
      var t,
        i =
          null == (t = this.instance.config.ui_host)
            ? void 0
            : t.replace(/\/$/, "");
      return (
        i || (i = this.apiHost.replace("." + Qo, ".posthog.com")),
        "https://app.posthog.com" === i ? "https://us.posthog.com" : i
      );
    }
    get region() {
      return (
        this.ds[this.apiHost] ||
          (/https:\/\/(app|us|us-assets)(\.i)?\.posthog\.com/i.test(
            this.apiHost,
          )
            ? (this.ds[this.apiHost] = Xo.US)
            : /https:\/\/(eu|eu-assets)(\.i)?\.posthog\.com/i.test(this.apiHost)
              ? (this.ds[this.apiHost] = Xo.EU)
              : (this.ds[this.apiHost] = Xo.CUSTOM)),
        this.ds[this.apiHost]
      );
    }
    endpointFor(t, i) {
      if (
        (void 0 === i && (i = ""),
        i && (i = "/" === i[0] ? i : "/" + i),
        "ui" === t)
      )
        return this.uiHost + i;
      if (this.region === Xo.CUSTOM) return this.apiHost + i;
      var e = Qo + i;
      switch (t) {
        case "assets":
          return "https://" + this.region + "-assets." + e;
        case "api":
          return "https://" + this.region + "." + e;
      }
    }
  }
  var ta = {
    icontains: (i, e) =>
      !!t && e.href.toLowerCase().indexOf(i.toLowerCase()) > -1,
    not_icontains: (i, e) =>
      !!t && -1 === e.href.toLowerCase().indexOf(i.toLowerCase()),
    regex: (i, e) => !!t && qs(e.href, i),
    not_regex: (i, e) => !!t && !qs(e.href, i),
    exact: (t, i) => i.href === t,
    is_not: (t, i) => i.href !== t,
  };
  class ia {
    constructor(t) {
      var i = this;
      ((this.getWebExperimentsAndEvaluateDisplayLogic = function (t) {
        (void 0 === t && (t = !1),
          i.getWebExperiments((t) => {
            (ia.vs("retrieved web experiments from the server"),
              (i.cs = new Map()),
              t.forEach((t) => {
                if (t.feature_flag_key) {
                  var e;
                  if (i.cs)
                    (ia.vs(
                      "setting flag key ",
                      t.feature_flag_key,
                      " to web experiment ",
                      t,
                    ),
                      null == (e = i.cs) || e.set(t.feature_flag_key, t));
                  var r = i._instance.getFeatureFlag(t.feature_flag_key);
                  R(r) &&
                    t.variants[r] &&
                    i.fs(t.name, r, t.variants[r].transforms);
                } else if (t.variants)
                  for (var s in t.variants) {
                    var n = t.variants[s];
                    ia.ps(n) && i.fs(t.name, s, n.transforms);
                  }
              }));
          }, t));
      }),
        (this._instance = t),
        this._instance.onFeatureFlags((t) => {
          this.onFeatureFlags(t);
        }));
    }
    onFeatureFlags(t) {
      if (this._is_bot())
        ia.vs(
          "Refusing to render web experiment since the viewer is a likely bot",
        );
      else if (!this._instance.config.disable_web_experiments) {
        if (M(this.cs))
          return (
            (this.cs = new Map()),
            this.loadIfEnabled(),
            void this.previewWebExperiment()
          );
        (ia.vs("applying feature flags", t),
          t.forEach((t) => {
            var i;
            if (this.cs && null != (i = this.cs) && i.has(t)) {
              var e,
                r = this._instance.getFeatureFlag(t),
                s = null == (e = this.cs) ? void 0 : e.get(t);
              r &&
                null != s &&
                s.variants[r] &&
                this.fs(s.name, r, s.variants[r].transforms);
            }
          }));
      }
    }
    previewWebExperiment() {
      var t = ia.getWindowLocation();
      if (null != t && t.search) {
        var i = Ri(null == t ? void 0 : t.search, "__experiment_id"),
          e = Ri(null == t ? void 0 : t.search, "__experiment_variant");
        i &&
          e &&
          (ia.vs("previewing web experiments " + i + " && " + e),
          this.getWebExperiments(
            (t) => {
              this.gs(parseInt(i), e, t);
            },
            !1,
            !0,
          ));
      }
    }
    loadIfEnabled() {
      this._instance.config.disable_web_experiments ||
        this.getWebExperimentsAndEvaluateDisplayLogic();
    }
    getWebExperiments(t, i, e) {
      if (this._instance.config.disable_web_experiments && !e) return t([]);
      var r = this._instance.get_property("$web_experiments");
      if (r && !i) return t(r);
      this._instance.Te({
        url: this._instance.requestRouter.endpointFor(
          "api",
          "/api/web_experiments/?token=" + this._instance.config.token,
        ),
        method: "GET",
        callback: (i) => {
          if (200 !== i.statusCode || !i.json) return t([]);
          var e = i.json.experiments || [];
          return t(e);
        },
      });
    }
    gs(t, i, e) {
      var r = e.filter((i) => i.id === t);
      r &&
        r.length > 0 &&
        (ia.vs(
          "Previewing web experiment [" +
            r[0].name +
            "] with variant [" +
            i +
            "]",
        ),
        this.fs(r[0].name, i, r[0].variants[i].transforms));
    }
    static ps(t) {
      return !M(t.conditions) && ia._s(t) && ia.bs(t);
    }
    static _s(t) {
      var i;
      if (M(t.conditions) || M(null == (i = t.conditions) ? void 0 : i.url))
        return !0;
      var e,
        r,
        s,
        n = ia.getWindowLocation();
      return (
        !!n &&
        (null == (e = t.conditions) ||
          !e.url ||
          ta[
            null !==
              (r = null == (s = t.conditions) ? void 0 : s.urlMatchType) &&
            void 0 !== r
              ? r
              : "icontains"
          ](t.conditions.url, n))
      );
    }
    static getWindowLocation() {
      return null == t ? void 0 : t.location;
    }
    static bs(t) {
      var i;
      if (M(t.conditions) || M(null == (i = t.conditions) ? void 0 : i.utm))
        return !0;
      var e = Xn();
      if (e.utm_source) {
        var r,
          s,
          n,
          o,
          a,
          l,
          h,
          u,
          d =
            null == (r = t.conditions) ||
            null == (r = r.utm) ||
            !r.utm_campaign ||
            (null == (s = t.conditions) || null == (s = s.utm)
              ? void 0
              : s.utm_campaign) == e.utm_campaign,
          v =
            null == (n = t.conditions) ||
            null == (n = n.utm) ||
            !n.utm_source ||
            (null == (o = t.conditions) || null == (o = o.utm)
              ? void 0
              : o.utm_source) == e.utm_source,
          c =
            null == (a = t.conditions) ||
            null == (a = a.utm) ||
            !a.utm_medium ||
            (null == (l = t.conditions) || null == (l = l.utm)
              ? void 0
              : l.utm_medium) == e.utm_medium,
          f =
            null == (h = t.conditions) ||
            null == (h = h.utm) ||
            !h.utm_term ||
            (null == (u = t.conditions) || null == (u = u.utm)
              ? void 0
              : u.utm_term) == e.utm_term;
        return d && c && f && v;
      }
      return !1;
    }
    static vs(t) {
      for (
        var i = arguments.length, e = new Array(i > 1 ? i - 1 : 0), r = 1;
        r < i;
        r++
      )
        e[r - 1] = arguments[r];
      q.info("[WebExperiments] " + t, e);
    }
    fs(t, i, e) {
      this._is_bot()
        ? ia.vs(
            "Refusing to render web experiment since the viewer is a likely bot",
          )
        : "control" !== i
          ? e.forEach((e) => {
              if (e.selector) {
                var r;
                ia.vs(
                  "applying transform of variant " +
                    i +
                    " for experiment " +
                    t +
                    " ",
                  e,
                );
                var s =
                  null == (r = document)
                    ? void 0
                    : r.querySelectorAll(e.selector);
                null == s ||
                  s.forEach((t) => {
                    var i = t;
                    (e.html && (i.innerHTML = e.html),
                      e.css && i.setAttribute("style", e.css));
                  });
              }
            })
          : ia.vs("Control variants leave the page unmodified.");
    }
    _is_bot() {
      return n && this._instance
        ? Yo(n, this._instance.config.custom_blocked_useragents)
        : void 0;
    }
  }
  var ea = H("[PostHog ExternalIntegrations]"),
    ra = {
      intercom: "intercom-integration",
      crispChat: "crisp-chat-integration",
    };
  class sa {
    constructor(t) {
      this._instance = t;
    }
    nt(t, i) {
      var e;
      null == (e = v.__PosthogExtensions__) ||
        null == e.loadExternalDependency ||
        e.loadExternalDependency(this._instance, t, (t) => {
          if (t) return ea.error("failed to load script", t);
          i();
        });
    }
    startIfEnabledOrStop() {
      var t = this,
        i = function (i) {
          var e, s, n;
          (!r ||
            (null != (e = v.__PosthogExtensions__) &&
              null != (e = e.integrations) &&
              e[i]) ||
            t.nt(ra[i], () => {
              var e;
              null == (e = v.__PosthogExtensions__) ||
                null == (e = e.integrations) ||
                null == (e = e[i]) ||
                e.start(t._instance);
            }),
          !r &&
            null != (s = v.__PosthogExtensions__) &&
            null != (s = s.integrations) &&
            s[i]) &&
            (null == (n = v.__PosthogExtensions__) ||
              null == (n = n.integrations) ||
              null == (n = n[i]) ||
              n.stop());
        };
      for (var [e, r] of Object.entries(
        null !== (s = this._instance.config.integrations) && void 0 !== s
          ? s
          : {},
      )) {
        var s;
        i(e);
      }
    }
  }
  var na = {},
    oa = () => {},
    aa = "posthog",
    la =
      !js &&
      -1 === (null == d ? void 0 : d.indexOf("MSIE")) &&
      -1 === (null == d ? void 0 : d.indexOf("Mozilla")),
    ha = (i) => {
      var e;
      return {
        api_host: "https://us.i.posthog.com",
        ui_host: null,
        token: "",
        autocapture: !0,
        rageclick: !0,
        cross_subdomain_cookie: st(null == o ? void 0 : o.location),
        persistence: "localStorage+cookie",
        persistence_name: "",
        loaded: oa,
        save_campaign_params: !0,
        custom_campaign_params: [],
        custom_blocked_useragents: [],
        save_referrer: !0,
        capture_pageview: "2025-05-24" !== i || "history_change",
        capture_pageleave: "if_capture_pageview",
        defaults: null != i ? i : "unset",
        debug:
          (a &&
            R(null == a ? void 0 : a.search) &&
            -1 !== a.search.indexOf("__posthog_debug=true")) ||
          !1,
        cookie_expiration: 365,
        upgrade: !1,
        disable_session_recording: !1,
        disable_persistence: !1,
        disable_web_experiments: !0,
        disable_surveys: !1,
        disable_surveys_automatic_display: !1,
        disable_external_dependency_loading: !1,
        enable_recording_console_log: void 0,
        secure_cookie:
          "https:" ===
          (null == t || null == (e = t.location) ? void 0 : e.protocol),
        ip: !1,
        opt_out_capturing_by_default: !1,
        opt_out_persistence_by_default: !1,
        opt_out_useragent_filter: !1,
        opt_out_capturing_persistence_type: "localStorage",
        consent_persistence_name: null,
        opt_out_capturing_cookie_prefix: null,
        opt_in_site_apps: !1,
        property_denylist: [],
        respect_dnt: !1,
        sanitize_properties: null,
        request_headers: {},
        request_batching: !0,
        properties_string_max_length: 65535,
        session_recording: {},
        mask_all_element_attributes: !1,
        mask_all_text: !1,
        mask_personal_data_properties: !1,
        custom_personal_data_properties: [],
        advanced_disable_flags: !1,
        advanced_disable_decide: !1,
        advanced_disable_feature_flags: !1,
        advanced_disable_feature_flags_on_first_load: !1,
        advanced_only_evaluate_survey_feature_flags: !1,
        advanced_enable_surveys: !1,
        advanced_disable_toolbar_metrics: !1,
        feature_flag_request_timeout_ms: 3e3,
        surveys_request_timeout_ms: 1e4,
        on_request_error: (t) => {
          var i = "Bad HTTP status: " + t.statusCode + " " + t.text;
          q.error(i);
        },
        get_device_id: (t) => t,
        capture_performance: void 0,
        name: "posthog",
        bootstrap: {},
        disable_compression: !1,
        session_idle_timeout_seconds: 1800,
        person_profiles: "identified_only",
        before_send: void 0,
        request_queue_config: { flush_interval_ms: Do },
        error_tracking: {},
        _onCapture: oa,
      };
    },
    ua = (t) => {
      var i = {};
      (P(t.process_person) || (i.person_profiles = t.process_person),
        P(t.xhr_headers) || (i.request_headers = t.xhr_headers),
        P(t.cookie_name) || (i.persistence_name = t.cookie_name),
        P(t.disable_cookie) || (i.disable_persistence = t.disable_cookie),
        P(t.store_google) || (i.save_campaign_params = t.store_google),
        P(t.verbose) || (i.debug = t.verbose));
      var e = Y({}, i, t);
      return (
        x(t.property_blacklist) &&
          (P(t.property_denylist)
            ? (e.property_denylist = t.property_blacklist)
            : x(t.property_denylist)
              ? (e.property_denylist = [
                  ...t.property_blacklist,
                  ...t.property_denylist,
                ])
              : q.error(
                  "Invalid value for property_denylist config: " +
                    t.property_denylist,
                )),
        e
      );
    };
  class da {
    constructor() {
      this.__forceAllowLocalhost = !1;
    }
    get ys() {
      return this.__forceAllowLocalhost;
    }
    set ys(t) {
      (q.error(
        "WebPerformanceObserver is deprecated and has no impact on network capture. Use `_forceAllowLocalhostNetworkCapture` on `posthog.sessionRecording`",
      ),
        (this.__forceAllowLocalhost = t));
    }
  }
  class va {
    get decideEndpointWasHit() {
      var t, i;
      return (
        null !==
          (t = null == (i = this.featureFlags) ? void 0 : i.hasLoadedFlags) &&
        void 0 !== t &&
        t
      );
    }
    get flagsEndpointWasHit() {
      var t, i;
      return (
        null !==
          (t = null == (i = this.featureFlags) ? void 0 : i.hasLoadedFlags) &&
        void 0 !== t &&
        t
      );
    }
    constructor() {
      ((this.webPerformance = new da()),
        (this.ws = !1),
        (this.version = c.LIB_VERSION),
        (this.Ss = new yo()),
        (this._calculate_event_properties =
          this.calculateEventProperties.bind(this)),
        (this.config = ha()),
        (this.SentryIntegration = ws),
        (this.sentryIntegration = (t) =>
          (function (t, i) {
            var e = ys(t, i);
            return { name: bs, processEvent: (t) => e(t) };
          })(this, t)),
        (this.__request_queue = []),
        (this.__loaded = !1),
        (this.analyticsDefaultEndpoint = "/e/"),
        (this.$s = !1),
        (this.xs = null),
        (this.ks = null),
        (this.Es = null),
        (this.featureFlags = new _o(this)),
        (this.toolbar = new Es(this)),
        (this.scrollManager = new zo(this)),
        (this.pageViewManager = new As(this)),
        (this.surveys = new Co(this)),
        (this.experiments = new ia(this)),
        (this.exceptions = new Vs(this)),
        (this.rateLimiter = new Fo(this)),
        (this.requestRouter = new Zo(this)),
        (this.consent = new ne(this)),
        (this.externalIntegrations = new sa(this)),
        (this.people = {
          set: (t, i, e) => {
            var r = R(t) ? { [t]: i } : t;
            (this.setPersonProperties(r), null == e || e({}));
          },
          set_once: (t, i, e) => {
            var r = R(t) ? { [t]: i } : t;
            (this.setPersonProperties(void 0, r), null == e || e({}));
          },
        }),
        this.on("eventCaptured", (t) =>
          q.info('send "' + (null == t ? void 0 : t.event) + '"', t),
        ));
    }
    init(t, i, e) {
      if (e && e !== aa) {
        var r,
          s = null !== (r = na[e]) && void 0 !== r ? r : new va();
        return (s._init(t, i, e), (na[e] = s), (na[aa][e] = s), s);
      }
      return this._init(t, i, e);
    }
    _init(i, e, r) {
      var s, n;
      if ((void 0 === e && (e = {}), P(i) || T(i)))
        return (
          q.critical(
            "PostHog was initialized without a token. This likely indicates a misconfiguration. Please check the first argument passed to posthog.init()",
          ),
          this
        );
      if (this.__loaded)
        return (
          q.warn(
            "You have already initialized PostHog! Re-initializing is a no-op",
          ),
          this
        );
      ((this.__loaded = !0),
        (this.config = {}),
        (this.Is = e),
        (this.Ps = []),
        e.person_profiles && (this.ks = e.person_profiles),
        this.set_config(Y({}, ha(e.defaults), ua(e), { name: r, token: i })),
        this.config.on_xhr_error &&
          q.error("on_xhr_error is deprecated. Use on_request_error instead"),
        (this.compression = e.disable_compression ? void 0 : xi.GZipJS));
      var o = this.Rs();
      ((this.persistence = new bo(this.config, o)),
        (this.sessionPersistence =
          "sessionStorage" === this.config.persistence ||
          "memory" === this.config.persistence
            ? this.persistence
            : new bo(
                f({}, this.config, { persistence: "sessionStorage" }),
                o,
              )));
      var a = f({}, this.persistence.props),
        l = f({}, this.sessionPersistence.props);
      (this.register({ $initialization_time: new Date().toISOString() }),
        (this.Ts = new jo((t) => this.Cs(t), this.config.request_queue_config)),
        (this.Ms = new No(this)),
        (this.__request_queue = []));
      var h =
        "always" === this.config.cookieless_mode ||
        ("on_reject" === this.config.cookieless_mode &&
          this.consent.isExplicitlyOptedOut());
      if (
        (h ||
          ((this.sessionManager = new Ho(this)),
          (this.sessionPropsManager = new Bo(
            this,
            this.sessionManager,
            this.persistence,
          ))),
        new Ps(this).startIfEnabledOrStop(),
        (this.siteApps = new Jo(this)),
        null == (s = this.siteApps) || s.init(),
        h ||
          ((this.sessionRecording = new gs(this)),
          this.sessionRecording.startIfEnabledOrStop()),
        this.config.disable_scroll_properties ||
          this.scrollManager.startMeasuringScrollPosition(),
        (this.autocapture = new ji(this)),
        this.autocapture.startIfEnabled(),
        this.surveys.loadIfEnabled(),
        (this.heatmaps = new Os(this)),
        this.heatmaps.startIfEnabled(),
        (this.webVitalsAutocapture = new Cs(this)),
        (this.exceptionObserver = new de(this)),
        this.exceptionObserver.startIfEnabled(),
        (this.deadClicksAutocapture = new he(this, le)),
        this.deadClicksAutocapture.startIfEnabled(),
        (this.historyAutocapture = new qe(this)),
        this.historyAutocapture.startIfEnabled(),
        (c.DEBUG = c.DEBUG || this.config.debug),
        c.DEBUG &&
          q.info("Starting in debug mode", {
            this: this,
            config: e,
            thisC: f({}, this.config),
            p: a,
            s: l,
          }),
        void 0 !== (null == (n = e.bootstrap) ? void 0 : n.distinctID))
      ) {
        var u,
          d,
          v = this.config.get_device_id(Hi()),
          p =
            null != (u = e.bootstrap) && u.isIdentifiedID
              ? v
              : e.bootstrap.distinctID;
        (this.persistence.set_property(
          Lt,
          null != (d = e.bootstrap) && d.isIdentifiedID
            ? "identified"
            : "anonymous",
        ),
          this.register({
            distinct_id: e.bootstrap.distinctID,
            $device_id: p,
          }));
      }
      if (this.Fs()) {
        var g,
          _,
          m = Object.keys(
            (null == (g = e.bootstrap) ? void 0 : g.featureFlags) || {},
          )
            .filter((t) => {
              var i;
              return !(
                null == (i = e.bootstrap) ||
                null == (i = i.featureFlags) ||
                !i[t]
              );
            })
            .reduce((t, i) => {
              var r;
              return (
                (t[i] =
                  (null == (r = e.bootstrap) || null == (r = r.featureFlags)
                    ? void 0
                    : r[i]) || !1),
                t
              );
            }, {}),
          b = Object.keys(
            (null == (_ = e.bootstrap) ? void 0 : _.featureFlagPayloads) || {},
          )
            .filter((t) => m[t])
            .reduce((t, i) => {
              var r, s;
              null != (r = e.bootstrap) &&
                null != (r = r.featureFlagPayloads) &&
                r[i] &&
                (t[i] =
                  null == (s = e.bootstrap) ||
                  null == (s = s.featureFlagPayloads)
                    ? void 0
                    : s[i]);
              return t;
            }, {});
        this.featureFlags.receivedFeatureFlags({
          featureFlags: m,
          featureFlagPayloads: b,
        });
      }
      if (h) this.register_once({ distinct_id: Gt, $device_id: null }, "");
      else if (!this.get_distinct_id()) {
        var y = this.config.get_device_id(Hi());
        (this.register_once({ distinct_id: y, $device_id: y }, ""),
          this.persistence.set_property(Lt, "anonymous"));
      }
      return (
        ot(
          t,
          "onpagehide" in self ? "pagehide" : "unload",
          this._handle_unload.bind(this),
          { passive: !1 },
        ),
        this.toolbar.maybeLoadToolbar(),
        e.segment ? ms(this, () => this.Os()) : this.Os(),
        k(this.config._onCapture) &&
          this.config._onCapture !== oa &&
          (q.warn("onCapture is deprecated. Please use `before_send` instead"),
          this.on("eventCaptured", (t) => this.config._onCapture(t.event, t))),
        this.config.ip &&
          q.warn(
            'The `ip` config option has NO EFFECT AT ALL and has been deprecated. Use a custom transformation or "Discard IP data" project setting instead. See https://posthog.com/tutorials/web-redact-properties#hiding-customer-ip-address for more information.',
          ),
        this
      );
    }
    Ce(t) {
      var i, e, r, s, n, a, l, h;
      if (!o || !o.body)
        return (
          q.info("document not ready yet, trying again in 500 milliseconds..."),
          void setTimeout(() => {
            this.Ce(t);
          }, 500)
        );
      ((this.compression = void 0),
        t.supportedCompression &&
          !this.config.disable_compression &&
          (this.compression = _(t.supportedCompression, xi.GZipJS)
            ? xi.GZipJS
            : _(t.supportedCompression, xi.Base64)
              ? xi.Base64
              : void 0),
        null != (i = t.analytics) &&
          i.endpoint &&
          (this.analyticsDefaultEndpoint = t.analytics.endpoint),
        this.set_config({
          person_profiles: this.ks ? this.ks : "identified_only",
        }),
        null == (e = this.siteApps) || e.onRemoteConfig(t),
        null == (r = this.sessionRecording) || r.onRemoteConfig(t),
        null == (s = this.autocapture) || s.onRemoteConfig(t),
        null == (n = this.heatmaps) || n.onRemoteConfig(t),
        this.surveys.onRemoteConfig(t),
        null == (a = this.webVitalsAutocapture) || a.onRemoteConfig(t),
        null == (l = this.exceptionObserver) || l.onRemoteConfig(t),
        this.exceptions.onRemoteConfig(t),
        null == (h = this.deadClicksAutocapture) || h.onRemoteConfig(t));
    }
    Os() {
      try {
        this.config.loaded(this);
      } catch (t) {
        q.critical("`loaded` function failed", t);
      }
      (this.As(),
        this.config.capture_pageview &&
          setTimeout(() => {
            this.consent.isOptedIn() && this.Ds();
          }, 1),
        new Ao(this).load(),
        this.featureFlags.flags());
    }
    As() {
      var t;
      this.is_capturing() &&
        this.config.request_batching &&
        (null == (t = this.Ts) || t.enable());
    }
    _dom_loaded() {
      (this.is_capturing() && V(this.__request_queue, (t) => this.Cs(t)),
        (this.__request_queue = []),
        this.As());
    }
    _handle_unload() {
      var t, i;
      this.config.request_batching
        ? (this.js() && this.capture("$pageleave"),
          null == (t = this.Ts) || t.unload(),
          null == (i = this.Ms) || i.unload())
        : this.js() &&
          this.capture("$pageleave", null, { transport: "sendBeacon" });
    }
    Te(t) {
      this.__loaded &&
        (la
          ? this.__request_queue.push(t)
          : this.rateLimiter.isServerRateLimited(t.batchKey) ||
            ((t.transport = t.transport || this.config.api_transport),
            (t.url = Ns(t.url, { ip: this.config.ip ? 1 : 0 })),
            (t.headers = f({}, this.config.request_headers)),
            (t.compression =
              "best-available" === t.compression
                ? this.compression
                : t.compression),
            (t.fetchOptions = t.fetchOptions || this.config.fetch_options),
            ((t) => {
              var i,
                e,
                r,
                s = f({}, t);
              ((s.timeout = s.timeout || 6e4),
                (s.url = Ns(s.url, {
                  _: new Date().getTime().toString(),
                  ver: c.LIB_VERSION,
                  compression: s.compression,
                })));
              var n = null !== (i = s.transport) && void 0 !== i ? i : "fetch",
                o =
                  null !==
                    (e =
                      null == (r = nt(Bs, (t) => t.transport === n))
                        ? void 0
                        : r.method) && void 0 !== e
                    ? e
                    : Bs[0].method;
              if (!o) throw new Error("No available transport method");
              o(s);
            })(
              f({}, t, {
                callback: (i) => {
                  var e, r;
                  (this.rateLimiter.checkForLimiting(i), i.statusCode >= 400) &&
                    (null == (e = (r = this.config).on_request_error) ||
                      e.call(r, i));
                  null == t.callback || t.callback(i);
                },
              }),
            )));
    }
    Cs(t) {
      this.Ms ? this.Ms.retriableRequest(t) : this.Te(t);
    }
    _execute_array(t) {
      var i,
        e = [],
        r = [],
        s = [];
      V(t, (t) => {
        t &&
          ((i = t[0]),
          x(i)
            ? s.push(t)
            : k(t)
              ? t.call(this)
              : x(t) && "alias" === i
                ? e.push(t)
                : x(t) && -1 !== i.indexOf("capture") && k(this[i])
                  ? s.push(t)
                  : r.push(t));
      });
      var n = function (t, i) {
        V(
          t,
          function (t) {
            if (x(t[0])) {
              var e = i;
              K(t, function (t) {
                e = e[t[0]].apply(e, t.slice(1));
              });
            } else this[t[0]].apply(this, t.slice(1));
          },
          i,
        );
      };
      (n(e, this), n(r, this), n(s, this));
    }
    Fs() {
      var t, i;
      return (
        ((null == (t = this.config.bootstrap) ? void 0 : t.featureFlags) &&
          Object.keys(
            null == (i = this.config.bootstrap) ? void 0 : i.featureFlags,
          ).length > 0) ||
        !1
      );
    }
    push(t) {
      this._execute_array([t]);
    }
    capture(t, i, e) {
      var r;
      if (
        this.__loaded &&
        this.persistence &&
        this.sessionPersistence &&
        this.Ts
      ) {
        if (this.is_capturing())
          if (!P(t) && R(t)) {
            if (this.config.opt_out_useragent_filter || !this._is_bot()) {
              var s =
                null != e && e.skip_client_rate_limiting
                  ? void 0
                  : this.rateLimiter.clientRateLimitContext();
              if (null == s || !s.isRateLimited) {
                (null != i &&
                  i.$current_url &&
                  !R(null == i ? void 0 : i.$current_url) &&
                  (q.error(
                    "Invalid `$current_url` property provided to `posthog.capture`. Input must be a string. Ignoring provided value.",
                  ),
                  null == i || delete i.$current_url),
                  this.sessionPersistence.update_search_keyword(),
                  this.config.save_campaign_params &&
                    this.sessionPersistence.update_campaign_params(),
                  this.config.save_referrer &&
                    this.sessionPersistence.update_referrer_info(),
                  (this.config.save_campaign_params ||
                    this.config.save_referrer) &&
                    this.persistence.set_initial_person_info());
                var n = new Date(),
                  o = (null == e ? void 0 : e.timestamp) || n,
                  a = Hi(),
                  l = {
                    uuid: a,
                    event: t,
                    properties: this.calculateEventProperties(t, i || {}, o, a),
                  };
                (s &&
                  (l.properties.$lib_rate_limit_remaining_tokens =
                    s.remainingTokens),
                  (null == e ? void 0 : e.$set) &&
                    (l.$set = null == e ? void 0 : e.$set));
                var h,
                  u = this.Ls(null == e ? void 0 : e.$set_once);
                if (
                  (u && (l.$set_once = u),
                  ((l = et(
                    l,
                    null != e && e._noTruncate
                      ? null
                      : this.config.properties_string_max_length,
                  )).timestamp = o),
                  P(null == e ? void 0 : e.timestamp) ||
                    ((l.properties.$event_time_override_provided = !0),
                    (l.properties.$event_time_override_system_time = n)),
                  t === $o.DISMISSED || t === $o.SENT)
                ) {
                  var d = null == i ? void 0 : i[xo.SURVEY_ID],
                    v = null == i ? void 0 : i[xo.SURVEY_ITERATION];
                  ((h = { id: d, current_iteration: v }),
                    localStorage.getItem(Po(h)) ||
                      localStorage.setItem(Po(h), "true"),
                    (l.$set = f({}, l.$set, {
                      [Io(
                        { id: d, current_iteration: v },
                        t === $o.SENT ? "responded" : "dismissed",
                      )]: !0,
                    })));
                }
                var c = f({}, l.properties.$set, l.$set);
                if (
                  (I(c) || this.setPersonPropertiesForFlags(c),
                  !M(this.config.before_send))
                ) {
                  var p = this.Ns(l);
                  if (!p) return;
                  l = p;
                }
                this.Ss.emit("eventCaptured", l);
                var g = {
                  method: "POST",
                  url:
                    null !== (r = null == e ? void 0 : e._url) && void 0 !== r
                      ? r
                      : this.requestRouter.endpointFor(
                          "api",
                          this.analyticsDefaultEndpoint,
                        ),
                  data: l,
                  compression: "best-available",
                  batchKey: null == e ? void 0 : e._batchKey,
                };
                return (
                  !this.config.request_batching ||
                  (e && (null == e || !e._batchKey)) ||
                  (null != e && e.send_instantly)
                    ? this.Cs(g)
                    : this.Ts.enqueue(g),
                  l
                );
              }
              q.critical(
                "This capture call is ignored due to client rate limiting.",
              );
            }
          } else q.error("No event name provided to posthog.capture");
      } else q.uninitializedWarning("posthog.capture");
    }
    Ye(t) {
      return this.on("eventCaptured", (i) => t(i.event, i));
    }
    calculateEventProperties(t, i, e, r, s) {
      if (
        ((e = e || new Date()), !this.persistence || !this.sessionPersistence)
      )
        return i;
      var n = s ? void 0 : this.persistence.remove_event_timer(t),
        a = f({}, i);
      if (
        ((a.token = this.config.token),
        (a.$config_defaults = this.config.defaults),
        ("always" == this.config.cookieless_mode ||
          ("on_reject" == this.config.cookieless_mode &&
            this.consent.isExplicitlyOptedOut())) &&
          (a.$cookieless_mode = !0),
        "$snapshot" === t)
      ) {
        var l = f(
          {},
          this.persistence.properties(),
          this.sessionPersistence.properties(),
        );
        return (
          (a.distinct_id = l.distinct_id),
          ((!R(a.distinct_id) && !F(a.distinct_id)) || T(a.distinct_id)) &&
            q.error(
              "Invalid distinct_id for replay event. This indicates a bug in your implementation",
            ),
          a
        );
      }
      var h,
        u = oo(
          this.config.mask_personal_data_properties,
          this.config.custom_personal_data_properties,
        );
      if (this.sessionManager) {
        var { sessionId: v, windowId: c } =
          this.sessionManager.checkAndGetSessionAndWindowId(s, e.getTime());
        ((a.$session_id = v), (a.$window_id = c));
      }
      this.sessionPropsManager &&
        Y(a, this.sessionPropsManager.getSessionProps());
      try {
        var p;
        (this.sessionRecording &&
          Y(a, this.sessionRecording.sdkDebugProperties),
          (a.$sdk_debug_retry_queue_size =
            null == (p = this.Ms) ? void 0 : p.length));
      } catch (t) {
        a.$sdk_debug_error_capturing_properties = String(t);
      }
      if (
        (this.requestRouter.region === Xo.CUSTOM &&
          (a.$lib_custom_api_host = this.config.api_host),
        (h =
          "$pageview" !== t || s
            ? "$pageleave" !== t || s
              ? this.pageViewManager.doEvent()
              : this.pageViewManager.doPageLeave(e)
            : this.pageViewManager.doPageView(e, r)),
        (a = Y(a, h)),
        "$pageview" === t && o && (a.title = o.title),
        !P(n))
      ) {
        var g = e.getTime() - n;
        a.$duration = parseFloat((g / 1e3).toFixed(3));
      }
      (d &&
        this.config.opt_out_useragent_filter &&
        (a.$browser_type = this._is_bot() ? "bot" : "browser"),
        ((a = Y(
          {},
          u,
          this.persistence.properties(),
          this.sessionPersistence.properties(),
          a,
        )).$is_identified = this._isIdentified()),
        x(this.config.property_denylist)
          ? K(this.config.property_denylist, function (t) {
              delete a[t];
            })
          : q.error(
              "Invalid value for property_denylist config: " +
                this.config.property_denylist +
                " or property_blacklist config: " +
                this.config.property_blacklist,
            ));
      var _ = this.config.sanitize_properties;
      _ &&
        (q.error("sanitize_properties is deprecated. Use before_send instead"),
        (a = _(a, t)));
      var m = this.zs();
      return (
        (a.$process_person_profile = m),
        m && !s && this.Us("_calculate_event_properties"),
        a
      );
    }
    Ls(t) {
      var i;
      if (!this.persistence || !this.zs()) return t;
      if (this.ws) return t;
      var e = this.persistence.get_initial_props(),
        r =
          null == (i = this.sessionPropsManager) ? void 0 : i.getSetOnceProps(),
        s = Y({}, e, r || {}, t || {}),
        n = this.config.sanitize_properties;
      return (
        n &&
          (q.error(
            "sanitize_properties is deprecated. Use before_send instead",
          ),
          (s = n(s, "$set_once"))),
        (this.ws = !0),
        I(s) ? void 0 : s
      );
    }
    register(t, i) {
      var e;
      null == (e = this.persistence) || e.register(t, i);
    }
    register_once(t, i, e) {
      var r;
      null == (r = this.persistence) || r.register_once(t, i, e);
    }
    register_for_session(t) {
      var i;
      null == (i = this.sessionPersistence) || i.register(t);
    }
    unregister(t) {
      var i;
      null == (i = this.persistence) || i.unregister(t);
    }
    unregister_for_session(t) {
      var i;
      null == (i = this.sessionPersistence) || i.unregister(t);
    }
    Bs(t, i) {
      this.register({ [t]: i });
    }
    getFeatureFlag(t, i) {
      return this.featureFlags.getFeatureFlag(t, i);
    }
    getFeatureFlagPayload(t) {
      var i = this.featureFlags.getFeatureFlagPayload(t);
      try {
        return JSON.parse(i);
      } catch (t) {
        return i;
      }
    }
    isFeatureEnabled(t, i) {
      return this.featureFlags.isFeatureEnabled(t, i);
    }
    reloadFeatureFlags() {
      this.featureFlags.reloadFeatureFlags();
    }
    updateEarlyAccessFeatureEnrollment(t, i, e) {
      this.featureFlags.updateEarlyAccessFeatureEnrollment(t, i, e);
    }
    getEarlyAccessFeatures(t, i, e) {
      return (
        void 0 === i && (i = !1),
        this.featureFlags.getEarlyAccessFeatures(t, i, e)
      );
    }
    on(t, i) {
      return this.Ss.on(t, i);
    }
    onFeatureFlags(t) {
      return this.featureFlags.onFeatureFlags(t);
    }
    onSurveysLoaded(t) {
      return this.surveys.onSurveysLoaded(t);
    }
    onSessionId(t) {
      var i, e;
      return null !==
        (i = null == (e = this.sessionManager) ? void 0 : e.onSessionId(t)) &&
        void 0 !== i
        ? i
        : () => {};
    }
    getSurveys(t, i) {
      (void 0 === i && (i = !1), this.surveys.getSurveys(t, i));
    }
    getActiveMatchingSurveys(t, i) {
      (void 0 === i && (i = !1), this.surveys.getActiveMatchingSurveys(t, i));
    }
    renderSurvey(t, i) {
      this.surveys.renderSurvey(t, i);
    }
    canRenderSurvey(t) {
      return this.surveys.canRenderSurvey(t);
    }
    canRenderSurveyAsync(t, i) {
      return (
        void 0 === i && (i = !1),
        this.surveys.canRenderSurveyAsync(t, i)
      );
    }
    identify(t, i, e) {
      if (!this.__loaded || !this.persistence)
        return q.uninitializedWarning("posthog.identify");
      if (
        (F(t) &&
          ((t = t.toString()),
          q.warn(
            "The first argument to posthog.identify was a number, but it should be a string. It has been converted to a string.",
          )),
        t)
      )
        if (["distinct_id", "distinctid"].includes(t.toLowerCase()))
          q.critical(
            'The string "' +
              t +
              '" was set in posthog.identify which indicates an error. This ID should be unique to the user and not a hardcoded string.',
          );
        else if (t !== Gt) {
          if (this.Us("posthog.identify")) {
            var r = this.get_distinct_id();
            if (
              (this.register({ $user_id: t }), !this.get_property("$device_id"))
            ) {
              var s = r;
              this.register_once(
                { $had_persisted_distinct_id: !0, $device_id: s },
                "",
              );
            }
            t !== r &&
              t !== this.get_property(lt) &&
              (this.unregister(lt), this.register({ distinct_id: t }));
            var n =
              "anonymous" ===
              (this.persistence.get_property(Lt) || "anonymous");
            (t !== r && n
              ? (this.persistence.set_property(Lt, "identified"),
                this.setPersonPropertiesForFlags(f({}, e || {}, i || {}), !1),
                this.capture(
                  "$identify",
                  { distinct_id: t, $anon_distinct_id: r },
                  { $set: i || {}, $set_once: e || {} },
                ),
                (this.Es = Hs(t, i, e)),
                this.featureFlags.setAnonymousDistinctId(r))
              : (i || e) && this.setPersonProperties(i, e),
              t !== r && (this.reloadFeatureFlags(), this.unregister(jt)));
          }
        } else
          q.critical(
            'The string "' +
              Gt +
              '" was set in posthog.identify which indicates an error. This ID is only used as a sentinel value.',
          );
      else q.error("Unique user id has not been set in posthog.identify");
    }
    setPersonProperties(t, i) {
      if ((t || i) && this.Us("posthog.setPersonProperties")) {
        var e = Hs(this.get_distinct_id(), t, i);
        this.Es !== e
          ? (this.setPersonPropertiesForFlags(f({}, i || {}, t || {})),
            this.capture("$set", { $set: t || {}, $set_once: i || {} }),
            (this.Es = e))
          : q.info(
              "A duplicate setPersonProperties call was made with the same properties. It has been ignored.",
            );
      }
    }
    group(t, i, e) {
      if (t && i) {
        if (this.Us("posthog.group")) {
          var r = this.getGroups();
          (r[t] !== i && this.resetGroupPropertiesForFlags(t),
            this.register({ $groups: f({}, r, { [t]: i }) }),
            e &&
              (this.capture("$groupidentify", {
                $group_type: t,
                $group_key: i,
                $group_set: e,
              }),
              this.setGroupPropertiesForFlags({ [t]: e })),
            r[t] === i || e || this.reloadFeatureFlags());
        }
      } else q.error("posthog.group requires a group type and group key");
    }
    resetGroups() {
      (this.register({ $groups: {} }),
        this.resetGroupPropertiesForFlags(),
        this.reloadFeatureFlags());
    }
    setPersonPropertiesForFlags(t, i) {
      (void 0 === i && (i = !0),
        this.featureFlags.setPersonPropertiesForFlags(t, i));
    }
    resetPersonPropertiesForFlags() {
      this.featureFlags.resetPersonPropertiesForFlags();
    }
    setGroupPropertiesForFlags(t, i) {
      (void 0 === i && (i = !0),
        this.Us("posthog.setGroupPropertiesForFlags") &&
          this.featureFlags.setGroupPropertiesForFlags(t, i));
    }
    resetGroupPropertiesForFlags(t) {
      this.featureFlags.resetGroupPropertiesForFlags(t);
    }
    reset(t) {
      var i, e, r, s;
      if ((q.info("reset"), !this.__loaded))
        return q.uninitializedWarning("posthog.reset");
      var n = this.get_property("$device_id");
      if (
        (this.consent.reset(),
        null == (i = this.persistence) || i.clear(),
        null == (e = this.sessionPersistence) || e.clear(),
        this.surveys.reset(),
        this.featureFlags.reset(),
        null == (r = this.persistence) || r.set_property(Lt, "anonymous"),
        null == (s = this.sessionManager) || s.resetSessionId(),
        (this.Es = null),
        "always" === this.config.cookieless_mode)
      )
        this.register_once({ distinct_id: Gt, $device_id: null }, "");
      else {
        var o = this.config.get_device_id(Hi());
        this.register_once({ distinct_id: o, $device_id: t ? o : n }, "");
      }
      this.register({ $last_posthog_reset: new Date().toISOString() }, 1);
    }
    get_distinct_id() {
      return this.get_property("distinct_id");
    }
    getGroups() {
      return this.get_property("$groups") || {};
    }
    get_session_id() {
      var t, i;
      return null !==
        (t =
          null == (i = this.sessionManager)
            ? void 0
            : i.checkAndGetSessionAndWindowId(!0).sessionId) && void 0 !== t
        ? t
        : "";
    }
    get_session_replay_url(t) {
      if (!this.sessionManager) return "";
      var { sessionId: i, sessionStartTimestamp: e } =
          this.sessionManager.checkAndGetSessionAndWindowId(!0),
        r = this.requestRouter.endpointFor(
          "ui",
          "/project/" + this.config.token + "/replay/" + i,
        );
      if (null != t && t.withTimestamp && e) {
        var s,
          n = null !== (s = t.timestampLookBack) && void 0 !== s ? s : 10;
        if (!e) return r;
        r +=
          "?t=" + Math.max(Math.floor((new Date().getTime() - e) / 1e3) - n, 0);
      }
      return r;
    }
    alias(t, i) {
      return t === this.get_property(at)
        ? (q.critical(
            "Attempting to create alias for existing People user - aborting.",
          ),
          -2)
        : this.Us("posthog.alias")
          ? (P(i) && (i = this.get_distinct_id()),
            t !== i
              ? (this.Bs(lt, t),
                this.capture("$create_alias", { alias: t, distinct_id: i }))
              : (q.warn(
                  "alias matches current distinct_id - skipping api call.",
                ),
                this.identify(t),
                -1))
          : void 0;
    }
    set_config(t) {
      var i = f({}, this.config);
      if (E(t)) {
        var e, r, s, n, o;
        Y(this.config, ua(t));
        var a = this.Rs();
        (null == (e = this.persistence) || e.update_config(this.config, i, a),
          (this.sessionPersistence =
            "sessionStorage" === this.config.persistence ||
            "memory" === this.config.persistence
              ? this.persistence
              : new bo(
                  f({}, this.config, { persistence: "sessionStorage" }),
                  a,
                )),
          Xi.G() && "true" === Xi.V("ph_debug") && (this.config.debug = !0),
          this.config.debug &&
            ((c.DEBUG = !0),
            q.info("set_config", {
              config: t,
              oldConfig: i,
              newConfig: f({}, this.config),
            })),
          null == (r = this.sessionRecording) || r.startIfEnabledOrStop(),
          null == (s = this.autocapture) || s.startIfEnabled(),
          null == (n = this.heatmaps) || n.startIfEnabled(),
          this.surveys.loadIfEnabled(),
          this.qs(),
          null == (o = this.externalIntegrations) || o.startIfEnabledOrStop());
      }
    }
    startSessionRecording(t) {
      var i = !0 === t,
        e = {
          sampling: i || !(null == t || !t.sampling),
          linked_flag: i || !(null == t || !t.linked_flag),
          url_trigger: i || !(null == t || !t.url_trigger),
          event_trigger: i || !(null == t || !t.event_trigger),
        };
      if (Object.values(e).some(Boolean)) {
        var r, s, n, o, a;
        if (
          (null == (r = this.sessionManager) ||
            r.checkAndGetSessionAndWindowId(),
          e.sampling)
        )
          null == (s = this.sessionRecording) || s.overrideSampling();
        if (e.linked_flag)
          null == (n = this.sessionRecording) || n.overrideLinkedFlag();
        if (e.url_trigger)
          null == (o = this.sessionRecording) || o.overrideTrigger("url");
        if (e.event_trigger)
          null == (a = this.sessionRecording) || a.overrideTrigger("event");
      }
      this.set_config({ disable_session_recording: !1 });
    }
    stopSessionRecording() {
      this.set_config({ disable_session_recording: !0 });
    }
    sessionRecordingStarted() {
      var t;
      return !(null == (t = this.sessionRecording) || !t.started);
    }
    captureException(t, i) {
      var e = new Error("PostHog syntheticException");
      return this.exceptions.sendExceptionEvent(
        f(
          {},
          Ue(
            ((t) => t instanceof Error)(t)
              ? { error: t, event: t.message }
              : { event: t },
            { syntheticException: e },
          ),
          i,
        ),
      );
    }
    loadToolbar(t) {
      return this.toolbar.loadToolbar(t);
    }
    get_property(t) {
      var i;
      return null == (i = this.persistence) ? void 0 : i.props[t];
    }
    getSessionProperty(t) {
      var i;
      return null == (i = this.sessionPersistence) ? void 0 : i.props[t];
    }
    toString() {
      var t,
        i = null !== (t = this.config.name) && void 0 !== t ? t : aa;
      return (i !== aa && (i = aa + "." + i), i);
    }
    _isIdentified() {
      var t, i;
      return (
        "identified" ===
          (null == (t = this.persistence) ? void 0 : t.get_property(Lt)) ||
        "identified" ===
          (null == (i = this.sessionPersistence) ? void 0 : i.get_property(Lt))
      );
    }
    zs() {
      var t, i;
      return !(
        "never" === this.config.person_profiles ||
        ("identified_only" === this.config.person_profiles &&
          !this._isIdentified() &&
          I(this.getGroups()) &&
          (null == (t = this.persistence) || null == (t = t.props) || !t[lt]) &&
          (null == (i = this.persistence) || null == (i = i.props) || !i[Ht]))
      );
    }
    js() {
      return (
        !0 === this.config.capture_pageleave ||
        ("if_capture_pageview" === this.config.capture_pageleave &&
          (!0 === this.config.capture_pageview ||
            "history_change" === this.config.capture_pageview))
      );
    }
    createPersonProfile() {
      this.zs() ||
        (this.Us("posthog.createPersonProfile") &&
          this.setPersonProperties({}, {}));
    }
    Us(t) {
      return "never" === this.config.person_profiles
        ? (q.error(
            t +
              ' was called, but process_person is set to "never". This call will be ignored.',
          ),
          !1)
        : (this.Bs(Ht, !0), !0);
    }
    Rs() {
      if ("always" === this.config.cookieless_mode) return !0;
      var t = this.consent.isOptedOut(),
        i =
          this.config.opt_out_persistence_by_default ||
          "on_reject" === this.config.cookieless_mode;
      return this.config.disable_persistence || (t && !!i);
    }
    qs() {
      var t,
        i,
        e,
        r,
        s = this.Rs();
      (null == (t = this.persistence) ? void 0 : t.je) !== s &&
        (null == (e = this.persistence) || e.set_disabled(s));
      (null == (i = this.sessionPersistence) ? void 0 : i.je) !== s &&
        (null == (r = this.sessionPersistence) || r.set_disabled(s));
      return s;
    }
    opt_in_capturing(t) {
      if ("always" !== this.config.cookieless_mode) {
        var i;
        if (
          ("on_reject" === this.config.cookieless_mode &&
            this.consent.isExplicitlyOptedOut() &&
            (this.reset(!0),
            (this.sessionManager = new Ho(this)),
            this.persistence &&
              (this.sessionPropsManager = new Bo(
                this,
                this.sessionManager,
                this.persistence,
              )),
            (this.sessionRecording = new gs(this)),
            this.sessionRecording.startIfEnabledOrStop()),
          this.consent.optInOut(!0),
          this.qs(),
          P(null == t ? void 0 : t.captureEventName) ||
            (null != t && t.captureEventName))
        )
          this.capture(
            null !== (i = null == t ? void 0 : t.captureEventName) &&
              void 0 !== i
              ? i
              : "$opt_in",
            null == t ? void 0 : t.captureProperties,
            { send_instantly: !0 },
          );
        this.config.capture_pageview && this.Ds();
      } else
        q.warn(
          'Consent opt in/out is not valid with cookieless_mode="always" and will be ignored',
        );
    }
    opt_out_capturing() {
      var t;
      "always" !== this.config.cookieless_mode
        ? ("on_reject" === this.config.cookieless_mode &&
            this.consent.isOptedIn() &&
            this.reset(!0),
          this.consent.optInOut(!1),
          this.qs(),
          "on_reject" === this.config.cookieless_mode &&
            (this.register({ distinct_id: Gt, $device_id: null }),
            (this.sessionManager = void 0),
            (this.sessionPropsManager = void 0),
            null == (t = this.sessionRecording) || t.stopRecording(),
            (this.sessionRecording = void 0),
            this.Ds()))
        : q.warn(
            'Consent opt in/out is not valid with cookieless_mode="always" and will be ignored',
          );
    }
    has_opted_in_capturing() {
      return this.consent.isOptedIn();
    }
    has_opted_out_capturing() {
      return this.consent.isOptedOut();
    }
    get_explicit_consent_status() {
      var t = this.consent.consent;
      return t === se.GRANTED
        ? "granted"
        : t === se.DENIED
          ? "denied"
          : "pending";
    }
    is_capturing() {
      return (
        "always" === this.config.cookieless_mode ||
        ("on_reject" === this.config.cookieless_mode
          ? this.consent.isExplicitlyOptedOut() || this.consent.isOptedIn()
          : !this.has_opted_out_capturing())
      );
    }
    clear_opt_in_out_capturing() {
      (this.consent.reset(), this.qs());
    }
    _is_bot() {
      return n ? Yo(n, this.config.custom_blocked_useragents) : void 0;
    }
    Ds() {
      o &&
        ("visible" === o.visibilityState
          ? this.$s ||
            ((this.$s = !0),
            this.capture(
              "$pageview",
              { title: o.title },
              { send_instantly: !0 },
            ),
            this.xs &&
              (o.removeEventListener("visibilitychange", this.xs),
              (this.xs = null)))
          : this.xs ||
            ((this.xs = this.Ds.bind(this)),
            ot(o, "visibilitychange", this.xs)));
    }
    debug(i) {
      !1 === i
        ? (null == t || t.console.log("You've disabled debug mode."),
          localStorage && localStorage.removeItem("ph_debug"),
          this.set_config({ debug: !1 }))
        : (null == t ||
            t.console.log(
              "You're now in debug mode. All calls to PostHog will be logged in your console.\nYou can disable this with `posthog.debug(false)`.",
            ),
          localStorage && localStorage.setItem("ph_debug", "true"),
          this.set_config({ debug: !0 }));
    }
    L() {
      var t,
        i,
        e,
        r,
        s,
        n,
        o,
        a = this.Is || {};
      return "advanced_disable_flags" in a
        ? !!a.advanced_disable_flags
        : !1 !== this.config.advanced_disable_flags
          ? !!this.config.advanced_disable_flags
          : !0 === this.config.advanced_disable_decide
            ? (q.warn(
                "Config field 'advanced_disable_decide' is deprecated. Please use 'advanced_disable_flags' instead. The old field will be removed in a future major version.",
              ),
              !0)
            : ((e = "advanced_disable_decide"),
              (r = !1),
              (s = q),
              (n = (i = "advanced_disable_flags") in (t = a) && !P(t[i])),
              (o = e in t && !P(t[e])),
              n
                ? t[i]
                : o
                  ? (s &&
                      s.warn(
                        "Config field '" +
                          e +
                          "' is deprecated. Please use '" +
                          i +
                          "' instead. The old field will be removed in a future major version.",
                      ),
                    t[e])
                  : r);
    }
    Ns(t) {
      if (M(this.config.before_send)) return t;
      var i = x(this.config.before_send)
          ? this.config.before_send
          : [this.config.before_send],
        e = t;
      for (var r of i) {
        if (((e = r(e)), M(e))) {
          var s = "Event '" + t.event + "' was rejected in beforeSend function";
          return (
            D(t.event)
              ? q.warn(s + ". This can cause unexpected behavior.")
              : q.info(s),
            null
          );
        }
        (e.properties && !I(e.properties)) ||
          q.warn(
            "Event '" +
              t.event +
              "' has no properties after beforeSend function, this is likely an error.",
          );
      }
      return e;
    }
    getPageViewId() {
      var t;
      return null == (t = this.pageViewManager.pe) ? void 0 : t.pageViewId;
    }
    captureTraceFeedback(t, i) {
      this.capture("$ai_feedback", {
        $ai_trace_id: String(t),
        $ai_feedback_text: i,
      });
    }
    captureTraceMetric(t, i, e) {
      this.capture("$ai_metric", {
        $ai_trace_id: String(t),
        $ai_metric_name: i,
        $ai_metric_value: String(e),
      });
    }
  }
  !(function (t, i) {
    for (var e = 0; e < i.length; e++)
      t.prototype[i[e]] = tt(t.prototype[i[e]]);
  })(va, ["identify"]);
  var ca, fa;
  ((ca = na[aa] = new va()),
    (fa = v.posthog) &&
      K(fa._i, function (t) {
        if (t && x(t)) {
          var i = ca.init(t[0], t[1], t[2]),
            e = fa[t[2]] || fa;
          i && (i._execute_array.call(i.people, e.people), i._execute_array(e));
        }
      }),
    (v.posthog = ca),
    (function () {
      function i() {
        i.done ||
          ((i.done = !0),
          (la = !1),
          K(na, function (t) {
            t._dom_loaded();
          }));
      }
      null != o && o.addEventListener
        ? "complete" === o.readyState
          ? i()
          : ot(o, "DOMContentLoaded", i, { capture: !1 })
        : t &&
          q.error(
            "Browser doesn't support `document.addEventListener` so PostHog couldn't be initialized",
          );
    })());
})();
//# sourceMappingURL=array.js.map
